// Authoritative factory simulation (build 0.3).
//  • The hall starts empty: supply terminal + a free fab bench.
//  • Machines are bought (delivered as kits) or crafted at the fab bench, then placed
//    on a 0.5 m grid. Conveyor sections carry items between machine ports.
//  • Machines run manually from a player's inventory, or automatically from a buffer
//    that input belts fill. Output goes to the tray (pick up) or out onto a belt.
//  • Goods that land in the sell corner slide through the wall chute into the outdoor
//    cage; a pickup van collects the cage and pays 80 % company / 20 % depositor.
//  • Government / private contracts pay a bonus on top of the fixed price.
// Pure JS: runs unchanged on a Node server. Clients send commands, render events.

import { ITEMS, MACHINES, CATALOG, EQUIPMENT, ECON, CONVEYOR, BUYERS, NODE_TYPES } from './items.js';
import { Inventory } from './Inventory.js';
import { FACTORY } from './layout.js';
import { PHASE_TIME, DUMP_INTERVAL, dumpDuration, truckPose, truckRear, TRUCK,
  VAN_TIME, VAN_LOAD_INTERVAL, vanLoadDuration, vanPose, vanDoor, blocksRoute } from './truck.js';
import { RaidSystem } from '../raid/RaidSystem.js';
import { TURRET, HEALTH } from '../raid/raidDefs.js';
import { MASK } from '../mapLayout.js';
import { hash01 } from '../math.js';
import { levelFor, levelGrant, perksAt, GOALS, LEVEL_UNLOCKS } from './progression.js';

const GRAV = 14;
const REACH = 3.2;
const EPS = 1e-4;
const scratch = [];

// ------------------------------------------------------------------ geometry
/** Rotate a local (x, z) by q quarter turns (same convention as three.js rotation.y). */
export function rotQ(q, x, z) {
  switch (q & 3) {
    case 1: return [z, -x];
    case 2: return [-x, -z];
    case 3: return [-z, x];
    default: return [x, z];
  }
}
export const snap = (v) => Math.round(v / FACTORY.grid) * FACTORY.grid;
/** Things placed on the 1 m belt grid: conveyors and the routing pieces. */
export const BELT_LIKE = new Set(['conveyor', ...NODE_TYPES]);
const keyOf = (x, z) => `${Math.round(x * 2)},${Math.round(z * 2)}`;
const overlap = (a, b) => a.x0 < b.x1 - EPS && a.x1 > b.x0 + EPS && a.z0 < b.z1 - EPS && a.z1 > b.z0 + EPS;

/** World footprint rectangle for a machine/belt type at (x, z, q). */
export function footprint(type, x, z, q) {
  const size = BELT_LIKE.has(type) ? CONVEYOR.size : MACHINES[type].size;
  const [w, d] = q & 1 ? [size[1], size[0]] : size;
  return { x0: x - w / 2, x1: x + w / 2, z0: z - d / 2, z1: z + d / 2 };
}

/** Machine geometry in world space: collider boxes, panel, tray, ports. */
export function machineGeometry(type, x, z, q) {
  const def = MACHINES[type];
  const W = (lx, lz) => { const [a, b] = rotQ(q, lx, lz); return [x + a, z + b]; };
  const boxes = def.colliders.map(([cx, cz, w, d, h]) => {
    const [wx, wz] = W(cx, cz);
    const [bw, bd] = q & 1 ? [d, w] : [w, d];
    return { x0: wx - bw / 2, x1: wx + bw / 2, z0: wz - bd / 2, z1: wz + bd / 2, h };
  });
  const [px, pz] = W(def.panel[0], def.panel[2]);
  const [tx, tz] = W(def.tray[0], def.tray[1]);
  const port = (p) => {
    const [cx, cz] = W(p.cell[0], p.cell[1]);
    const [dx, dz] = rotQ(q, p.dir[0], p.dir[1]);
    return { x: cx, z: cz, dx: Math.round(dx), dz: Math.round(dz) };
  };
  return {
    boxes, panel: [px, def.panel[1], pz], tray: [tx, def.tray[2], tz],
    in: def.ports && def.ports.in ? port(def.ports.in) : null, out: def.ports && def.ports.out ? port(def.ports.out) : null,
  };
}

const freshStats = () => ({
  shipped: 0, shippedValue: 0, madeValue: 0, produced: 0, delivered: 0, contracts: 0,
  orders: 0, crafted: 0, placed: 0, beltsLaid: 0, deposited: 0, vanTrips: 0, autoSet: 0, advanced: 0,
});

export class FactorySim {
  constructor(world, { seed = 1, funds = ECON.startFunds, fresh = true, replica = false } = {}) {
    this.world = world;
    this.seed = seed;
    this.time = 0;
    this.funds = funds;
    this.players = new Map();
    this.items = new Map();
    this.nextItemId = 1;
    this.machines = new Map();
    this.belts = new Map();
    this.beltKeys = new Map();
    this.nextMachineId = 1;
    this.truck = { phase: 'idle', t0: 0, manifest: [], dumped: 0, trips: 0 };
    this.pending = [];
    this.van = { phase: 'idle', t0: 0, manifest: [], loaded: 0, trips: 0 };
    this.cage = [];
    this.dock = []; // receiving dock bin (raw materials the truck tipped in)
    this._nodeBusy = new Set();
    this.contracts = { offers: [], active: [], nextId: 1, nextOfferAt: 0 };
    this.stats = freshStats();
    this.progress = { xp: 0, goals: [] };
    this._goalT = 0;
    this.events = [];
    this._rng = 0;
    this.replica = replica;
    this.raids = new RaidSystem(this, { replica });
    if (fresh) for (const s of FACTORY.starter) this._createMachine(s.type, s.x, s.z, s.q);
  }

  rand() { return hash01(this.seed * 7919 + 17, this._rng++); }
  emit(e) { this.events.push(e); }

  // ------------------------------------------------------------------ progression
  levelInfo() { return levelFor(this.progress.xp); }
  perks() { return perksAt(this.levelInfo().level); }
  saleMultiplier() { return 1 + this.perks().saleBonus; }

  _gainXp(amount) {
    if (!(amount > 0)) return;
    const before = levelFor(this.progress.xp).level;
    this.progress.xp += amount;
    const after = levelFor(this.progress.xp).level;
    for (let L = before + 1; L <= after; L++) {
      const grant = levelGrant(L);
      this.funds += grant;
      this.emit({ type: 'funds', funds: this.funds, delta: grant });
      this.emit({ type: 'levelUp', level: L, grant, unlocks: LEVEL_UNLOCKS[L] || [], saleBonus: perksAt(L).saleBonus });
    }
    this.emit({ type: 'xp', xp: this.progress.xp });
  }

  goalProgress(g) { return Math.min(g.target, g.value(this) || 0); }

  _checkGoals() {
    for (const g of GOALS) {
      if (this.progress.goals.includes(g.id)) continue;
      if ((g.value(this) || 0) < g.target) continue;
      this.progress.goals.push(g.id);
      this.funds += g.reward;
      this.emit({ type: 'funds', funds: this.funds, delta: g.reward });
      this.emit({ type: 'goalDone', goal: g.id, name: g.name, reward: g.reward });
    }
  }

  // ------------------------------------------------------------------ players
  addPlayer(id, saved = null) {
    const p = {
      id, inventory: saved && saved.inv ? Inventory.fromJSON(saved.inv) : new Inventory(24), pos: [0, 0, 0], wallet: (saved && saved.wallet) || 0,
      online: true, crouch: 0, hp: HEALTH.max, down: false, downT: 0, reviver: null, reviveT: 0, lastHit: -99,
    };
    this.players.set(id, p);
    return p;
  }

  _pay(value, ownerId) {
    const company = Math.round(value * ECON.companyShare);
    const personal = value - company;
    const p = this.players.get(ownerId);
    if (p) {
      p.wallet += personal;
      this.funds += company;
      this.emit({ type: 'wallet', player: p.id, wallet: p.wallet, delta: personal });
    } else {
      this.funds += value;
    }
    this.emit({ type: 'funds', funds: this.funds, delta: p ? company : value });
  }

  // ------------------------------------------------------------------ commands
  apply(playerId, cmd) {
    const p = this.players.get(playerId);
    if (!p) return { ok: false, error: 'Unknown player' };
    if (cmd.pos) p.pos = cmd.pos;
    switch (cmd.type) {
      case 'order': return this._order(p, cmd.items || {});
      case 'pickup': return this._pickup(p, cmd.itemId);
      case 'drop': return this._drop(p, cmd.slot, cmd.count ?? Infinity, cmd.at, cmd.vel);
      case 'run': return this._run(p, cmd.machine, cmd.recipe, cmd.times || 1);
      case 'scrap': return this._scrap(p, cmd.slot, cmd.count ?? Infinity);
      case 'use': return this._use(p, cmd.slot);
      case 'move': p.inventory.move(cmd.from, cmd.to); this.emit({ type: 'inventory', player: p.id }); return { ok: true };
      case 'place': return this._place(p, cmd.slot, cmd.x, cmd.z, cmd.q);
      case 'pack': return this._pack(p, cmd.id);
      case 'packBelt': return this._packBelt(p, cmd.id);
      case 'auto': return this._setAuto(p, cmd.machine, cmd.recipe);
      case 'output': return this._setOutput(p, cmd.machine, cmd.mode);
      case 'unload': return this._unload(p, cmd.machine);
      case 'deposit': return this._depositAll(p);
      case 'callVan': return this._callVan(p);
      case 'accept': return this._accept(p, cmd.contract);
      case 'shoot': return this.raids.playerShot(p, cmd.o, cmd.d, cmd.lag);
      case 'revive': return this.raids.revive(p, cmd.target, true);
      case 'reviveStop': return this.raids.revive(p, null, false);
      case 'loadTurret': return this._loadTurret(p, cmd.machine, cmd.count ?? 1);
      case 'unloadTurret': return this._unloadTurret(p, cmd.machine);
      case 'dockTake': return this._dockTake(p, cmd.index);
      case 'setFilter': return this._setFilter(p, cmd.id, cmd.item, cmd.side);
      default: return { ok: false, error: 'Unknown command' };
    }
  }

  quote(items) {
    let total = 0, units = 0;
    for (const [type, qty] of Object.entries(items)) {
      const def = ITEMS[type];
      const q = Math.floor(qty);
      if (!def || def.buy == null || !(q > 0)) continue;
      total += def.buy * q;
      units += q;
    }
    const fee = units && !this.perks().freeDelivery ? ECON.deliveryFee : 0;
    return { total: total + fee, units, fee };
  }

  _order(p, items) {
    const clean = {};
    for (const [type, qty] of Object.entries(items)) {
      const q = Math.min(200, Math.floor(qty));
      if ((CATALOG.includes(type) || EQUIPMENT.includes(type)) && q > 0) clean[type] = q;
    }
    const { total, units } = this.quote(clean);
    if (!units) return { ok: false, error: 'Nothing to order' };
    if (total > this.funds) return { ok: false, error: `Not enough company funds (need $${total.toLocaleString('en-US')})` };
    this.funds -= total;
    for (const [type, q] of Object.entries(clean)) {
      let left = q;
      while (left > 0) {
        const n = Math.min(left, ITEMS[type].stack);
        this.pending.push({ type, count: n, owner: p.id });
        left -= n;
      }
    }
    this.stats.orders++;
    if (this.truck.phase === 'idle') this._setTruck('loading');
    this.emit({ type: 'funds', funds: this.funds, delta: -total });
    this.emit({ type: 'ordered', units, total });
    return { ok: true, total };
  }

  _near(p, pos, reach = REACH) {
    const dx = p.pos[0] - pos[0], dz = p.pos[2] - pos[2];
    return dx * dx + dz * dz <= reach * reach;
  }

  _pickup(p, itemId) {
    const it = this.items.get(itemId);
    if (!it) return { ok: false, error: 'Gone' };
    if (!this._near(p, [it.x, it.y, it.z])) return { ok: false, error: 'Too far away' };
    const left = p.inventory.add(it.type, it.count);
    const taken = it.count - left;
    if (taken <= 0) return { ok: false, error: 'Inventory full' };
    if (left > 0) { it.count = left; this.emit({ type: 'itemCount', id: it.id, count: left }); }
    else this._removeItem(it.id);
    this.emit({ type: 'pickup', player: p.id, item: it.type, count: taken, x: it.x, y: it.y, z: it.z });
    this.emit({ type: 'inventory', player: p.id });
    return { ok: true, taken, full: left > 0 };
  }

  _drop(p, slot, count, at, vel) {
    const s = p.inventory.takeSlot(slot, count);
    if (!s) return { ok: false, error: 'Empty slot' };
    const pos = at || [p.pos[0], p.pos[1] + 1.2, p.pos[2]];
    this.spawnItem(s.type, s.count, pos, vel || [0, 1, 0], { owner: p.id });
    this.emit({ type: 'inventory', player: p.id });
    return { ok: true };
  }

  _scrap(p, slot, count) {
    const s = p.inventory.takeSlot(slot, count);
    if (!s) return { ok: false, error: 'Empty slot' };
    const value = Math.round(ITEMS[s.type].value * s.count * this.perks().scrapRate);
    this.funds += value;
    this.emit({ type: 'funds', funds: this.funds, delta: value });
    this.emit({ type: 'sold', via: 'scrap', item: s.type, count: s.count, value });
    this.emit({ type: 'inventory', player: p.id });
    return { ok: true, value };
  }

  _use(p, slot) {
    const s = p.inventory.slots[slot];
    if (!s) return { ok: false, error: 'Empty slot' };
    const use = ITEMS[s.type].use;
    if (!use) return { ok: false, error: `${ITEMS[s.type].name} can't be used` };
    p.inventory.takeSlot(slot, 1);
    this.emit({ type: 'use', player: p.id, item: s.type, effect: use });
    this.emit({ type: 'inventory', player: p.id });
    return { ok: true, effect: use };
  }

  // ------------------------------------------------------------------ building
  /** Can `type` go at (x, z, q)? Shared by the client ghost and the server check. */
  canPlace(type, x, z, q, { playerPos = null, ignore = null } = {}) {
    const fp = footprint(type, x, z, q);
    const F = FACTORY.floor;
    const inside = !(fp.x0 < F.x0 - EPS || fp.x1 > F.x1 + EPS || fp.z0 < F.z0 - EPS || fp.z1 > F.z1 + EPS);
    const defence = !BELT_LIKE.has(type) && MACHINES[type].defence;
    if (!inside) {
      // defences also go outside, anywhere in the fenced yard that the trucks don't need
      if (!defence) return { ok: false, why: 'Must be inside the factory hall' };
      const Y = FACTORY.yard;
      if (fp.x0 < Y.x0 || fp.x1 > Y.x1 || fp.z0 < Y.z0 || fp.z1 > Y.z1) return { ok: false, why: 'Must be inside the yard fence' };
      for (const r of FACTORY.yardReserved) if (overlap(fp, r)) return { ok: false, why: `Keep the ${r.why} clear` };
      if (blocksRoute(fp)) return { ok: false, why: 'Keep the truck and van route clear' };
    }
    for (const r of FACTORY.reserved) if (overlap(fp, r)) return { ok: false, why: `Keep the ${r.why} clear` };
    for (const m of this.machines.values()) {
      if (m.id === ignore) continue;
      if (overlap(fp, m.fp)) return { ok: false, why: `Blocked by ${m.def.name}` };
    }
    for (const b of this.belts.values()) if (b.id !== ignore && overlap(fp, b.fp)) return { ok: false, why: 'Blocked by a conveyor' };
    for (const c of this.world.query(fp.x0, fp.z0, fp.x1, fp.z1, MASK.ALL, scratch)) {
      if (c.dyn || c.min[1] > 2.5 || c.max[1] <= 0.05) continue;
      if (overlap(fp, { x0: c.min[0], x1: c.max[0], z0: c.min[2], z1: c.max[2] })) return { ok: false, why: inside ? 'Blocked by the building' : 'Something is in the way' };
    }
    if (playerPos) {
      const r = 0.34;
      const pb = { x0: playerPos[0] - r, x1: playerPos[0] + r, z0: playerPos[2] - r, z1: playerPos[2] + r };
      if (overlap(fp, pb)) return { ok: false, why: "You're standing in the way" };
    }
    return { ok: true };
  }

  _place(p, slot, x, z, q) {
    const s = p.inventory.slots[slot];
    if (!s) return { ok: false, error: 'Empty slot' };
    const type = ITEMS[s.type].place;
    if (!type) return { ok: false, error: `${ITEMS[s.type].name} can't be placed` };
    x = snap(x); z = snap(z); q = (q | 0) & 3;
    if (!this._near(p, [x, 0, z], 14)) return { ok: false, error: 'Too far away to build there' };
    const chk = this.canPlace(type, x, z, q, { playerPos: p.pos });
    if (!chk.ok) return { ok: false, error: chk.why };
    p.inventory.takeSlot(slot, 1);
    const belt = BELT_LIKE.has(type);
    const obj = belt ? this._createBelt(x, z, q, null, type === 'conveyor' ? 'belt' : type) : this._createMachine(type, x, z, q);
    if (type === 'conveyor') this.stats.beltsLaid++; else if (!belt && !MACHINES[type].defence) this.stats.placed++;
    this.emit({ type: 'inventory', player: p.id });
    this.emit({ type: 'placed', kind: type, id: obj.id, x, z, q });
    return { ok: true, id: obj.id, type };
  }

  _createMachine(type, x, z, q, id = null) {
    const def = MACHINES[type];
    const g = machineGeometry(type, x, z, q);
    const m = {
      id: id || `m${this.nextMachineId++}`, type, def, x, z, q, fp: footprint(type, x, z, q), geo: g,
      queue: [], current: null, auto: null, outMode: 'tray', buffer: {}, outBuffer: [], colliders: [],
    };
    const surface = def.defence === 'wall' ? 'concrete' : 'metal';
    for (const b of g.boxes) {
      const c = { min: [b.x0, 0, b.z0], max: [b.x1, b.h, b.z1], surface, mask: MASK.ALL, dyn: true, machine: m.id };
      if (def.climb) c.climb = def.climb; // raiders can climb over barricades
      m.colliders.push(this.world.addCollider(c));
    }
    if (def.leaf) {
      // gate leaf: stops raiders only; players (and bullets) pass through
      const [lx, lz, lw, ld, lh] = def.leaf;
      const [cx, cz] = rotQ(q, lx, lz);
      const [bw, bd] = q & 1 ? [ld, lw] : [lw, ld];
      m.leaf = this.world.addCollider({ min: [x + cx - bw / 2, 0, z + cz - bd / 2], max: [x + cx + bw / 2, lh, z + cz + bd / 2], surface: 'fence', mask: MASK.RAIDER, dyn: true, machine: m.id, gate: m.id });
      m.colliders.push(m.leaf);
    }
    if (def.defence === 'turret') { m.ammo = 0; this.raids.initTurret(m); }
    this.raids.nav.markDirty(m.fp.x0, m.fp.z0, m.fp.x1, m.fp.z1);
    this.machines.set(m.id, m);
    this.emit({ type: 'machinePlaced', id: m.id, machine: type, x, z, q });
    return m;
  }

  /** A 1 m belt tile: a plain conveyor (kind 'belt') or a routing piece (splitter / sorter / merger). */
  _createBelt(x, z, q, id = null, kind = 'belt', opts = {}) {
    const [dx, dz] = rotQ(q, 0, 1); // belts run toward local +Z (the placement arrow)
    const [lx, lz] = rotQ(q, 1, 0); // "left" when looking along the belt
    const b = {
      id: id || `b${this.nextMachineId++}`, kind: NODE_TYPES.includes(kind) ? kind : 'belt', x, z, q,
      dx: Math.round(dx), dz: Math.round(dz), lx: Math.round(lx), lz: Math.round(lz), fp: footprint('conveyor', x, z, q),
      filter: opts.filter && ITEMS[opts.filter] ? opts.filter : null, side: opts.side === 'right' ? 'right' : 'left', rr: 0, queue: [],
    };
    b.collider = this.world.addCollider({ min: [x - 0.5, 0, z - 0.5], max: [x + 0.5, CONVEYOR.top, z + 0.5], surface: 'metal', mask: MASK.ALL, dyn: true, belt: b.id });
    this.belts.set(b.id, b);
    this.beltKeys.set(keyOf(x, z), b);
    this.emit({ type: 'beltPlaced', id: b.id, x, z, q, kind: b.kind, filter: b.filter, side: b.side });
    return b;
  }

  _pack(p, id) {
    const m = this.machines.get(id);
    if (!m) return { ok: false, error: 'Nothing to pack up' };
    if (!this._near(p, m.geo.panel, 4)) return { ok: false, error: 'Too far from the machine' };
    if (m.current || m.queue.length || m.outBuffer.length) return { ok: false, error: 'Wait for the machine to finish first' };
    const kit = `kit_${m.type}`;
    if (p.inventory.space(kit) < 1) return { ok: false, error: 'No room in your inventory for the kit' };
    if (m.def.defence === 'turret' && m.ammo > 0) {
      // full boxes go back in your pockets (or on the floor); a part-used box is kept as rounds
      const boxes = Math.floor(m.ammo / TURRET.roundsPerBox);
      const left = boxes ? p.inventory.add('ammo_box', boxes) : 0;
      if (left > 0) this.spawnItem('ammo_box', left, [m.x, 1.3, m.z], [0, 1, 0], { owner: p.id });
      m.ammo = 0;
    }
    // hand back anything still sitting in the input buffer
    for (const [t, n] of Object.entries(m.buffer)) {
      const left = p.inventory.add(t, n);
      if (left > 0) this.spawnItem(t, left, [m.geo.tray[0], 1.4, m.geo.tray[2]], [0, 1, 0], { owner: p.id });
    }
    this.removeMachine(id);
    p.inventory.add(kit, 1);
    for (const it of this.items.values()) if (it.x > m.fp.x0 && it.x < m.fp.x1 && it.z > m.fp.z0 && it.z < m.fp.z1) { it.rest = false; it.belt = null; }
    this.emit({ type: 'inventory', player: p.id });
    return { ok: true, kit };
  }

  _packBelt(p, id) {
    const b = this.belts.get(id);
    if (!b) return { ok: false, error: 'Nothing to pick up' };
    if (!this._near(p, [b.x, 0, b.z])) return { ok: false, error: 'Too far away' };
    const kit = b.kind === 'belt' ? 'conveyor' : b.kind;
    if (p.inventory.space(kit) < 1) return { ok: false, error: 'Inventory full' };
    this.removeBelt(id);
    for (const it of this.items.values()) if (it.belt === id) { it.belt = null; it.rest = false; }
    p.inventory.add(kit, 1);
    this.emit({ type: 'inventory', player: p.id });
    return { ok: true };
  }

  /** Remove a machine and its colliders (pack-up, load, replicas). */
  removeMachine(id) {
    const m = this.machines.get(id);
    if (!m) return;
    for (const c of m.colliders) this.world.removeCollider(c);
    this.machines.delete(id);
    this.raids.nav.markDirty(m.fp.x0, m.fp.z0, m.fp.x1, m.fp.z1);
    this.raids.breached.delete(id);
    this.emit({ type: 'machineRemoved', id });
  }

  removeBelt(id) {
    const b = this.belts.get(id);
    if (!b) return;
    this.world.removeCollider(b.collider);
    this.belts.delete(id);
    if (this.beltKeys.get(keyOf(b.x, b.z)) === b) this.beltKeys.delete(keyOf(b.x, b.z));
    this.emit({ type: 'beltRemoved', id });
  }

  /** Take every machine/belt collider out of the shared World (switching sessions). */
  dispose() {
    for (const id of [...this.machines.keys()]) this.removeMachine(id);
    for (const id of [...this.belts.keys()]) this.removeBelt(id);
    this.items.clear();
    this.events.length = 0;
  }

  beltAt(x, z) {
    // tiles are 1 m on a 0.5 m grid: check the nearby grid centres
    for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
      const cx = snap(x) + i * 0.5, cz = snap(z) + j * 0.5;
      const b = this.beltKeys.get(keyOf(cx, cz));
      if (b && Math.abs(x - b.x) <= 0.5 && Math.abs(z - b.z) <= 0.5) return b;
    }
    return null;
  }

  // ------------------------------------------------------------------ machines
  _machineCheck(p, id, reach = REACH) {
    const m = this.machines.get(id);
    if (!m) return { error: 'Unknown machine' };
    if (!this._near(p, m.geo.panel, reach)) return { error: 'Too far from the machine' };
    return { m };
  }

  _run(p, id, recipeId, times) {
    const { m, error } = this._machineCheck(p, id);
    if (error) return { ok: false, error };
    const r = m.def.recipes.find((x) => x.id === recipeId);
    if (!r) return { ok: false, error: 'Unknown recipe' };
    times = Math.max(1, Math.min(times | 0, ECON.maxQueue - m.queue.length - (m.current ? 1 : 0)));
    if (times <= 0) return { ok: false, error: 'Queue is full' };
    let n = 0;
    while (n < times && p.inventory.hasAll(r.inputs)) { p.inventory.removeAll(r.inputs); n++; }
    if (!n) return { ok: false, error: 'Missing materials' };
    for (let i = 0; i < n; i++) m.queue.push({ recipe: r, owner: p.id });
    if (!m.current) this._startNext(m);
    this.emit({ type: 'inventory', player: p.id });
    this.emit({ type: 'machineState', id: m.id });
    return { ok: true, queued: n };
  }

  _setAuto(p, id, recipeId) {
    const { m, error } = this._machineCheck(p, id, 4);
    if (error) return { ok: false, error };
    if (recipeId && !m.def.recipes.find((r) => r.id === recipeId)) return { ok: false, error: 'Unknown recipe' };
    m.auto = recipeId || null;
    m.autoOwner = p.id;
    if (recipeId) this.stats.autoSet++;
    this.emit({ type: 'machineState', id: m.id });
    return { ok: true };
  }

  _setOutput(p, id, mode) {
    const { m, error } = this._machineCheck(p, id, 4);
    if (error) return { ok: false, error };
    m.outMode = mode === 'belt' ? 'belt' : 'tray';
    this.emit({ type: 'machineState', id: m.id });
    return { ok: true };
  }

  _unload(p, id) {
    const { m, error } = this._machineCheck(p, id, 4);
    if (error) return { ok: false, error };
    let moved = 0;
    for (const [t, n] of Object.entries(m.buffer)) {
      const left = p.inventory.add(t, n);
      moved += n - left;
      if (left > 0) m.buffer[t] = left; else delete m.buffer[t];
    }
    if (!moved) return { ok: false, error: 'Nothing in the input buffer' };
    this.emit({ type: 'inventory', player: p.id });
    this.emit({ type: 'machineState', id: m.id });
    return { ok: true, moved };
  }

  /** Does this machine take `type` into its belt-fed input buffer? */
  accepts(m, type, count = 1) {
    if (m.def.defence === 'turret') return type === 'ammo_box' && m.ammo + TURRET.roundsPerBox * count <= TURRET.capacity;
    if (!m.def.recipes.some((r) => r.inputs[type])) return false;
    return (m.buffer[type] || 0) + count <= ECON.bufferCap || !(m.buffer[type] > 0);
  }

  _startNext(m) {
    let job = m.queue.shift();
    if (!job && m.auto && m.outBuffer.length < 3) {
      const r = m.def.recipes.find((x) => x.id === m.auto);
      if (r && Object.entries(r.inputs).every(([t, n]) => (m.buffer[t] || 0) >= n)) {
        for (const [t, n] of Object.entries(r.inputs)) { m.buffer[t] -= n; if (!m.buffer[t]) delete m.buffer[t]; }
        job = { recipe: r, owner: m.autoOwner, auto: true };
      }
    }
    if (!job) {
      if (m.current) { m.current = null; this.emit({ type: 'machineIdle', id: m.id }); }
      return;
    }
    m.current = { recipe: job.recipe, start: this.time, end: this.time + job.recipe.time, owner: job.owner, auto: !!job.auto };
    this.emit({ type: 'machineStart', id: m.id, machine: m.type, recipe: job.recipe.id, duration: job.recipe.time, auto: !!job.auto });
  }

  machineProgress(id) {
    const m = this.machines.get(id);
    if (!m || !m.current) return 0;
    return Math.min(1, (this.time - m.current.start) / (m.current.end - m.current.start));
  }

  _stepMachines() {
    for (const m of this.machines.values()) {
      if (m.def.defence) continue;
      if (m.current && this.time >= m.current.end) {
        const outBelt = m.outMode === 'belt' ? this.beltAt(m.geo.out.x, m.geo.out.z) : null;
        let i = 0;
        for (const [type, n] of Object.entries(m.current.recipe.outputs)) {
          if (outBelt) m.outBuffer.push({ type, count: n, owner: m.current.owner });
          else this.spawnItem(type, n, [m.geo.tray[0] + (i % 2) * 0.12, m.geo.tray[1] + 0.6 + i * 0.25, m.geo.tray[2]], [0, 0.5, 0], { owner: m.current.owner });
          this.stats.produced += n;
          if (type === 'motor' || type === 'control_unit') this.stats.advanced += n;
          i++;
        }
        if (m.type === 'fabricator') this.stats.crafted++;
        this.emit({ type: 'machineDone', id: m.id, machine: m.type, recipe: m.current.recipe.id, toBelt: !!outBelt });
        const wasQueued = m.queue.length > 0 || m.auto;
        m.current = null;
        this._startNext(m);
        if (!m.current && !wasQueued) this.emit({ type: 'machineIdle', id: m.id });
        else if (!m.current) this.emit({ type: 'machineState', id: m.id });
      } else if (!m.current) {
        this._startNext(m);
      }
      // push finished goods out onto the output belt when there's room
      if (m.outBuffer.length) {
        const b = this.beltAt(m.geo.out.x, m.geo.out.z);
        if (!b || m.outMode !== 'belt') {
          const s = m.outBuffer.shift();
          this.spawnItem(s.type, s.count, [m.geo.tray[0], m.geo.tray[1] + 0.6, m.geo.tray[2]], [0, 0.5, 0], { owner: s.owner });
        } else if (this._putOnBelt(b, m.outBuffer[0], [m.geo.out.dx, m.geo.out.dz])) {
          m.outBuffer.shift();
        }
      }
    }
  }

  // ------------------------------------------------------------------ turrets
  _loadTurret(p, id, count) {
    const { m, error } = this._machineCheck(p, id, 3.4);
    if (error) return { ok: false, error };
    if (m.def.defence !== 'turret') return { ok: false, error: 'Not a turret' };
    const room = Math.floor((TURRET.capacity - m.ammo) / TURRET.roundsPerBox);
    if (room <= 0) return { ok: false, error: 'Turret is full' };
    const want = Math.min(room, count === 'all' ? Infinity : Math.max(1, count | 0), p.inventory.count('ammo_box'));
    if (!(want > 0)) return { ok: false, error: 'You have no ammo boxes' };
    p.inventory.remove('ammo_box', want);
    m.ammo += want * TURRET.roundsPerBox;
    this.emit({ type: 'inventory', player: p.id });
    this.emit({ type: 'turretLoaded', id: m.id, ammo: m.ammo, boxes: want });
    return { ok: true, boxes: want, ammo: m.ammo };
  }

  _unloadTurret(p, id) {
    const { m, error } = this._machineCheck(p, id, 3.4);
    if (error) return { ok: false, error };
    if (m.def.defence !== 'turret') return { ok: false, error: 'Not a turret' };
    const boxes = Math.min(Math.floor(m.ammo / TURRET.roundsPerBox), p.inventory.space('ammo_box'));
    if (boxes <= 0) return { ok: false, error: m.ammo ? 'No room for the ammo boxes' : 'Turret is empty' };
    p.inventory.add('ammo_box', boxes);
    m.ammo -= boxes * TURRET.roundsPerBox;
    this.emit({ type: 'inventory', player: p.id });
    this.emit({ type: 'turretLoaded', id: m.id, ammo: m.ammo, boxes: -boxes });
    return { ok: true, boxes };
  }

  /** Production machines (goals count these, not walls and turrets). */
  productionCount() {
    let n = 0;
    for (const m of this.machines.values()) if (!m.def.defence) n++;
    return n;
  }

  // ------------------------------------------------------------------ items
  spawnItem(type, count, pos, vel = [0, 0, 0], opts = {}) {
    const id = this.nextItemId++;
    const it = {
      id, type, count,
      x: pos[0], y: pos[1], z: pos[2],
      vx: vel[0], vy: vel[1], vz: vel[2],
      ry: hash01(this.seed, id) * Math.PI * 2,
      spin: opts.spin ?? (hash01(this.seed + 3, id) - 0.5) * 8,
      tumble: 0, tumbleV: opts.tumble ?? 0,
      rest: false, belt: null, suck: 0,
      owner: opts.owner || null,
      r: ITEMS[type].r,
    };
    this.items.set(id, it);
    this.emit({ type: 'itemSpawn', id, item: type, count, x: it.x, y: it.y, z: it.z, puff: !!opts.puff, eject: !!opts.eject });
    return it;
  }

  _removeItem(id) {
    if (this.items.delete(id)) this.emit({ type: 'itemRemove', id });
  }

  _machineAtPort(x, z) {
    for (const m of this.machines.values()) if (m.geo.in && Math.abs(m.geo.in.x - x) < 0.05 && Math.abs(m.geo.in.z - z) < 0.05) return m;
    return null;
  }

  // ------------------------------------------------------------------ belts + routing
  /** Direction an item moves on tile b (routing pieces send each item its own way). */
  _dirOf(b, it) { return b.kind === 'belt' ? [b.dx, b.dz] : [it.ndx ?? b.dx, it.ndz ?? b.dz]; }

  /** Is there somewhere for an item leaving tile b in direction d to go? */
  _outlet(b, d) {
    const nx = b.x + d[0], nz = b.z + d[1];
    if (this._machineAtPort(nx, nz)) return true;
    const nb = this.beltKeys.get(keyOf(nx, nz));
    if (nb) return !(nb.dx === -d[0] && nb.dz === -d[1] && nb.kind !== 'splitter' && nb.kind !== 'sorter'); // not a belt pointing back at us
    return this._inSellZone({ x: nx, z: nz });
  }

  /** Is the first slot of the tile in direction d from b clear? */
  _outletFree(b, d) {
    const nx = b.x + d[0], nz = b.z + d[1];
    const nb = this.beltKeys.get(keyOf(nx, nz));
    if (!nb) return true;
    if (nb.kind !== 'belt') return !this._nodeBusy.has(nb.id);
    const ex = nb.x - d[0] * 0.3, ez = nb.z - d[1] * 0.3;
    for (const it of this.items.values()) if (it.belt === nb.id && Math.abs(it.x - ex) < 0.5 && Math.abs(it.z - ez) < 0.5) return false;
    return true;
  }

  /** Where a routing piece sends an item that arrived moving in direction `from`. */
  _route(node, it, from) {
    const f = [node.dx, node.dz], l = [node.lx, node.lz], r = [-node.lx, -node.lz];
    const back = (d) => d[0] === -from[0] && d[1] === -from[1];
    if (node.kind === 'merger') return f;
    if (node.kind === 'sorter') {
      if (node.filter && it.type === node.filter) {
        const side = node.side === 'right' ? r : l;
        if (!back(side) && this._outlet(node, side)) return side;
      }
      return back(f) ? l : f;
    }
    // splitter: deal items round-robin to the outputs that lead somewhere, skipping full ones
    const cands = [f, l, r].filter((d) => !back(d) && this._outlet(node, d));
    if (!cands.length) return back(f) ? l : f;
    for (let k = 0; k < cands.length; k++) {
      const d = cands[(node.rr + k) % cands.length];
      if (this._outletFree(node, d)) { node.rr = (node.rr + k + 1) % cands.length; return d; }
    }
    const d = cands[node.rr % cands.length];
    node.rr = (node.rr + 1) % cands.length;
    return d;
  }

  /**
   * Try to move item `it` (travelling in direction `from`) onto routing piece `node`.
   * One item crosses a piece at a time; waiting items go in first come, first served.
   */
  _enterNode(node, it, from) {
    if (node.kind === 'merger' && from[0] === -node.dx && from[1] === -node.dz) return false; // can't feed a merger from its front
    const q = node.queue;
    // forget items that stopped waiting (picked up, rerouted …)
    while (q.length && (this.time - q[0].t > 0.25 || !this.items.has(q[0].id))) q.shift();
    const mine = q.find((e) => e.id === it.id);
    if (mine) mine.t = this.time;
    if (this._nodeBusy.has(node.id) || (q.length && q[0].id !== it.id)) {
      if (!mine) q.push({ id: it.id, t: this.time });
      return false;
    }
    if (q.length && q[0].id === it.id) q.shift();
    const [ex, ez] = this._route(node, it, from);
    it.belt = node.id; it.ndx = ex; it.ndz = ez; it.rest = true;
    this._nodeBusy.add(node.id);
    return true;
  }

  /** Machines and the receiving dock push a stack onto the belt tile at their output. */
  _putOnBelt(b, stack, from) {
    if (!stack) return false;
    const node = b.kind !== 'belt';
    const dx = node ? from[0] : b.dx, dz = node ? from[1] : b.dz;
    const ex = b.x - dx * 0.3, ez = b.z - dz * 0.3;
    if (node) { if (this._nodeBusy.has(b.id) || b.queue.length) return false; }
    else if ([...this.items.values()].some((it) => it.belt === b.id && Math.hypot(it.x - ex, it.z - ez) < 0.55)) return false;
    const it = this.spawnItem(stack.type, stack.count, [ex, CONVEYOR.top, ez], [0, 0, 0], { owner: stack.owner, puff: false, eject: true });
    it.rest = true;
    if (node) this._enterNode(b, it, from); else it.belt = b.id;
    return true;
  }

  _stepBelts(dt, beltItems) {
    this._nodeBusy.clear();
    for (const it of beltItems) { const b = this.belts.get(it.belt); if (b && b.kind !== 'belt') this._nodeBusy.add(b.id); }
    for (const it of beltItems) {
      const b = this.belts.get(it.belt);
      if (!b) { it.belt = null; it.rest = false; continue; }
      const [dx, dz] = this._dirOf(b, it);
      const S = b.kind === 'belt' ? CONVEYOR.speed : CONVEYOR.nodeSpeed;
      let along = (it.x - b.x) * dx + (it.z - b.z) * dz;
      let lat = (it.x - b.x) * -dz + (it.z - b.z) * dx;
      // queue behind the item in front
      let blocked = false;
      for (const o of beltItems) {
        if (o === it) continue;
        const ax = o.x - it.x, az = o.z - it.z;
        const ahead = ax * dx + az * dz;
        if (ahead > 0 && ahead < 0.5 && Math.abs(ax * -dz + az * dx) < 0.4) { blocked = true; break; }
      }
      if (!blocked) along += S * dt;
      lat -= lat * Math.min(1, dt * (b.kind === 'belt' ? 6 : 10));
      if (along > 0.5) {
        const nx = b.x + dx, nz = b.z + dz;
        const m = this._machineAtPort(nx, nz);
        const next = this.beltKeys.get(keyOf(nx, nz));
        const facing = next && next.kind === 'belt' && next.dx === -dx && next.dz === -dz; // belts pointing at each other
        if (m) {
          if (this.accepts(m, it.type, it.count)) {
            if (m.def.defence === 'turret') m.ammo += TURRET.roundsPerBox * it.count;
            else m.buffer[it.type] = (m.buffer[it.type] || 0) + it.count;
            this._removeItem(it.id);
            this.emit({ type: 'machineFed', id: m.id, item: it.type, count: it.count });
            this.emit({ type: 'machineState', id: m.id });
            continue;
          }
          along = 0.5; // hold at the port until there's room
        } else if (next && next.kind !== 'belt') {
          if (!this._enterNode(next, it, [dx, dz])) along = 0.5; // wait for the splitter / filter / merger
        } else if (next && facing) {
          along = 0.5; // two belts pointing at each other: goods stop at the join
        } else if (next) {
          it.belt = next.id;
        } else if (this._inSellZone({ x: nx, z: nz })) {
          // belt runs into the sell corner: straight down the chute
          this._deposit(it.type, it.count, it.owner, [it.x, it.y, it.z], it.id);
          continue;
        } else {
          // end of the line: shoot it off the belt
          it.belt = null; it.rest = false;
          it.vx = dx * S * 1.1; it.vz = dz * S * 1.1; it.vy = 1.2;
          it.x = b.x + dx * 0.5; it.z = b.z + dz * 0.5; it.y = CONVEYOR.top + 0.05;
          this.emit({ type: 'beltLaunch', id: it.id });
          continue;
        }
      }
      if (it.belt === b.id) {
        it.x = b.x + dx * along - dz * lat;
        it.z = b.z + dz * along + dx * lat;
      }
      it.y = CONVEYOR.top;
      const want = Math.atan2(dx, dz);
      let d = want - it.ry; d = Math.atan2(Math.sin(d), Math.cos(d));
      it.ry += d * Math.min(1, dt * 6);
    }
  }

  _setFilter(p, id, item, side) {
    const b = this.belts.get(id);
    if (!b || b.kind !== 'sorter') return { ok: false, error: 'Not an item filter' };
    if (!this._near(p, [b.x, 0, b.z], 4)) return { ok: false, error: 'Too far away' };
    if (item !== undefined) b.filter = item && ITEMS[item] ? item : null;
    if (side === 'left' || side === 'right') b.side = side;
    this.emit({ type: 'nodeState', id: b.id, filter: b.filter, side: b.side });
    return { ok: true };
  }

  // ------------------------------------------------------------------ receiving dock
  /** Add a stack to the dock bin (topping up same-type stacks). False if it's full. */
  _dockAdd(stack) {
    const cap = ITEMS[stack.type].stack || 20;
    let left = stack.count;
    for (const s of this.dock) {
      if (!left) break;
      if (s.type !== stack.type || s.owner !== (stack.owner || null) || s.count >= cap) continue;
      const n = Math.min(cap - s.count, left);
      s.count += n; left -= n;
    }
    while (left > 0 && this.dock.length < ECON.dockCap) { const n = Math.min(cap, left); this.dock.push({ type: stack.type, count: n, owner: stack.owner || null }); left -= n; }
    return left;
  }

  dockOutBelt() { const o = FACTORY.dock.out; return this.beltAt(o.x, o.z); }

  _stepDock() {
    if (!this.dock.length) return;
    const b = this.dockOutBelt();
    if (!b) return;
    const o = FACTORY.dock.out;
    if (this._putOnBelt(b, this.dock[0], [o.dx, o.dz])) {
      const s = this.dock.shift();
      this.emit({ type: 'dockOut', item: s.type, count: s.count, left: this.dock.length });
    }
  }

  _dockTake(p, index) {
    const D = FACTORY.dock;
    if (!this._near(p, D.panel, 4)) return { ok: false, error: 'Too far from the receiving dock' };
    const idx = index === undefined || index === null || index === 'all' ? null : index | 0;
    let moved = 0;
    for (let i = this.dock.length - 1; i >= 0; i--) {
      if (idx !== null && i !== idx) continue;
      const s = this.dock[i];
      const left = p.inventory.add(s.type, s.count);
      moved += s.count - left;
      if (left > 0) s.count = left; else this.dock.splice(i, 1);
    }
    if (!moved) return { ok: false, error: this.dock.length ? 'Inventory full' : 'The dock is empty' };
    this.emit({ type: 'inventory', player: p.id });
    this.emit({ type: 'dockTaken', left: this.dock.length });
    return { ok: true, moved };
  }

  _inSellZone(it) {
    const z = FACTORY.sell.zone;
    return it.x >= z.x0 - 0.01 && it.x <= z.x1 && it.z >= z.z0 - 0.01 && it.z <= z.z1;
  }

  _stepItems(dt) {
    const w = this.world;
    const beltItems = [];
    for (const it of this.items.values()) if (it.belt) beltItems.push(it);
    if (beltItems.length) this._stepBelts(dt, beltItems);

    for (const it of [...this.items.values()]) {
      if (it.belt) continue;
      if (it.rest) {
        if (this._inSellZone(it)) {
          it.suck += dt;
          if (it.suck > 0.35) this._deposit(it.type, it.count, it.owner, [it.x, it.y, it.z], it.id);
        }
        continue;
      }
      it.vy -= GRAV * dt;
      const drag = Math.exp(-0.25 * dt);
      it.vx *= drag; it.vz *= drag;
      const prevY = it.y;
      it.x += it.vx * dt; it.y += it.vy * dt; it.z += it.vz * dt;
      it.ry += it.spin * dt;
      it.tumble += it.tumbleV * dt;
      const r = it.r * 0.7;
      for (const c of w.query(it.x - r, it.z - r, it.x + r, it.z + r, MASK.PLAYER, scratch)) {
        if (it.y + 0.05 < c.min[1] || Math.max(it.y, prevY) > c.max[1] - 0.05) continue;
        const px1 = it.x + r - c.min[0], px2 = c.max[0] - (it.x - r);
        const pz1 = it.z + r - c.min[2], pz2 = c.max[2] - (it.z - r);
        const pen = Math.min(px1, px2, pz1, pz2);
        if (pen <= 0) continue;
        if (pen === px1) { it.x -= px1; it.vx = -Math.abs(it.vx) * 0.3; }
        else if (pen === px2) { it.x += px2; it.vx = Math.abs(it.vx) * 0.3; }
        else if (pen === pz1) { it.z -= pz1; it.vz = -Math.abs(it.vz) * 0.3; }
        else { it.z += pz2; it.vz = Math.abs(it.vz) * 0.3; }
      }
      const g = w.groundHeight(it.x, it.z, r * 0.5, Math.max(prevY, it.y) + 0.05, scratch);
      if (it.y <= g) {
        it.y = g;
        const iv = -it.vy;
        if (iv > 1.5) this.emit({ type: 'itemBounce', id: it.id, item: it.type, strength: Math.min(1, iv / 7), x: it.x, y: it.y, z: it.z });
        it.vy = iv * 0.28;
        it.vx *= 0.55; it.vz *= 0.55;
        it.spin *= 0.5; it.tumbleV *= 0.4;
        if (it.vy < 0.6) {
          it.rest = true;
          it.vx = it.vy = it.vz = 0;
          it.tumble = Math.round(it.tumble / Math.PI) * Math.PI;
          // landed on a belt? ride it
          const b = Math.abs(it.y - CONVEYOR.top) < 0.08 ? this.beltAt(it.x, it.z) : null;
          if (b) {
            it.tumble = 0;
            if (b.kind === 'belt') it.belt = b.id;
            else { const [ex, ez] = this._route(b, it, [b.dx, b.dz]); it.belt = b.id; it.ndx = ex; it.ndz = ez; }
          }
        }
      }
      if (it.y < -5) this._removeItem(it.id);
    }
  }

  // ------------------------------------------------------------------ selling
  _deposit(type, count, owner, pos, itemId = null) {
    if (itemId) this._removeItem(itemId);
    owner = owner || null;
    // top up an existing stack of the same item + owner before opening a new one
    const cap = ITEMS[type].stack || 20;
    let left = count;
    for (const s of this.cage) {
      if (!left) break;
      if (s.type !== type || s.owner !== owner || s.count >= cap) continue;
      const n = Math.min(cap - s.count, left);
      s.count += n;
      left -= n;
    }
    while (left > 0) { const n = Math.min(cap, left); this.cage.push({ type, count: n, owner }); left -= n; }
    this.stats.deposited += count;
    const value = this.cageValue();
    this.emit({ type: 'deposit', item: type, count, x: pos[0], y: pos[1], z: pos[2], cage: this.cage.length, value });
  }

  cageValue() { return this.cage.reduce((a, s) => a + ITEMS[s.type].value * s.count, 0); }

  _depositAll(p) {
    const hp = FACTORY.sell.hopper;
    if (!this._near(p, [hp.x - 1.5, 0, hp.z], 4.2)) return { ok: false, error: 'Too far from the sell corner' };
    let units = 0;
    for (let i = 0; i < p.inventory.size; i++) {
      const s = p.inventory.slots[i];
      if (!s || ITEMS[s.type].cat === 'raw' || ITEMS[s.type].cat === 'kit') continue;
      const t = p.inventory.takeSlot(i);
      this._deposit(t.type, t.count, p.id, [hp.x - 0.4, hp.h + 0.2, hp.z]);
      units += t.count;
    }
    if (!units) return { ok: false, error: 'No parts or products to sell' };
    this.emit({ type: 'inventory', player: p.id });
    return { ok: true, units };
  }

  _callVan(p) {
    if (this.van.phase !== 'idle') return { ok: false, error: 'The pickup van is already on its way' };
    if (!this.cage.length) return { ok: false, error: 'The pickup cage is empty' };
    this.van.caller = p.id;
    this._setVan('dispatch');
    return { ok: true };
  }

  _setVan(phase) {
    const V = this.van;
    V.phase = phase;
    V.t0 = this.time;
    if (phase === 'loading') { V.manifest = this.cage.splice(0, this.cage.length); V.loaded = 0; V.payout = 0; V.interval = this.perks().vanFast ? VAN_LOAD_INTERVAL / 2 : VAN_LOAD_INTERVAL; }
    this.emit({ type: 'vanPhase', phase, t0: this.time, manifest: phase === 'loading' ? V.manifest.length : undefined });
  }

  vanPose() { return vanPose(this.van, this.time); }

  _stepVan() {
    const V = this.van;
    const t = this.time - V.t0;
    const iv = V.interval || VAN_LOAD_INTERVAL;
    switch (V.phase) {
      case 'dispatch': if (t >= VAN_TIME.dispatch) this._setVan('inbound'); break;
      case 'inbound': if (t >= VAN_TIME.inbound) this._setVan('loading'); break;
      case 'loading': {
        while (V.loaded < V.manifest.length && t >= 0.8 + V.loaded * iv) this._loadVan(V.manifest[V.loaded++]);
        if (t >= vanLoadDuration(V.manifest.length, iv)) {
          this.stats.vanTrips++;
          this.emit({ type: 'vanPaid', total: V.payout, stacks: V.manifest.length, bonus: this.perks().saleBonus });
          this._setVan('reversing');
        }
        break;
      }
      case 'reversing': if (t >= VAN_TIME.reversing) this._setVan('outbound'); break;
      case 'outbound':
        if (t >= VAN_TIME.outbound) { V.trips++; this._setVan('idle'); }
        break;
    }
  }

  _loadVan(stack) {
    const def = ITEMS[stack.type];
    // Level bonus + XP only for goods the factory made — reselling bought raw stock or
    // kits must never turn a profit or farm levels.
    const made = def.cat === 'part' || def.cat === 'product';
    const value = Math.round(def.value * stack.count * (made ? this.saleMultiplier() : 1));
    this._pay(value, stack.owner);
    if (made) { this.stats.madeValue += value; this._gainXp(value); }
    this.van.payout += value;
    this.stats.shipped += stack.count;
    this.stats.shippedValue += value;
    const door = vanDoor(this.vanPose());
    const c = FACTORY.cage;
    this.emit({ type: 'vanLoad', item: stack.type, count: stack.count, value, from: [(c.x0 + c.x1) / 2, 0.6, (c.z0 + c.z1) / 2], to: [door.x, 1.1, door.z] });
    this._creditContracts(stack.type, stack.count);
  }

  // ------------------------------------------------------------------ contracts
  _tier() { return this.stats.shippedValue < 1500 ? 0 : this.stats.shippedValue < 6000 ? 1 : 2; }

  _newOffer() {
    const tier = this._tier();
    const pool = [['bracket', 24, 45], ['housing', 10, 20], ['harness', 3, 6], ['ammo_box', 4, 8]];
    if (tier >= 1) pool.push(['motor', 3, 6], ['motor', 3, 6]);
    if (tier >= 2) pool.push(['control_unit', 2, 5], ['control_unit', 2, 5]);
    const [item, lo, hi] = pool[Math.floor(this.rand() * pool.length)];
    const gov = this.rand() < 0.4;
    const names = gov ? BUYERS.government : BUYERS.private;
    const qty = lo + Math.floor(this.rand() * (hi - lo + 1));
    const bonus = gov ? 0.35 + this.rand() * 0.15 : 0.18 + this.rand() * 0.14;
    const minutes = gov ? 10 + this.rand() * 6 : 6 + this.rand() * 4;
    return {
      id: `c${this.contracts.nextId++}`, kind: gov ? 'government' : 'private', buyer: names[Math.floor(this.rand() * names.length)],
      item, qty, bonus: Math.round(bonus * 100) / 100, duration: Math.round(minutes * 60), offerExpires: this.time + 480, delivered: 0,
    };
  }

  contractBonus(c) { return Math.round(ITEMS[c.item].value * c.qty * c.bonus); }

  _accept(p, id) {
    const C = this.contracts;
    const i = C.offers.findIndex((o) => o.id === id);
    if (i < 0) return { ok: false, error: 'That offer is gone' };
    const slots = this.perks().contractSlots;
    if (C.active.length >= slots) return { ok: false, error: `You can run ${slots} contracts at a time` };
    const c = C.offers.splice(i, 1)[0];
    c.deadline = this.time + c.duration;
    c.owner = p.id;
    C.active.push(c);
    this.emit({ type: 'contracts' });
    return { ok: true, contract: c };
  }

  _creditContracts(type, count) {
    const C = this.contracts;
    for (const c of C.active) {
      if (c.item !== type || count <= 0) continue;
      const take = Math.min(count, c.qty - c.delivered);
      c.delivered += take;
      count -= take;
      if (c.delivered >= c.qty && !c.done) {
        c.done = true;
        const bonus = this.contractBonus(c);
        this._pay(bonus, c.owner);
        this._gainXp(bonus);
        this.stats.contracts++;
        this.emit({ type: 'contractDone', contract: c.id, buyer: c.buyer, bonus });
      }
    }
    C.active = C.active.filter((c) => !c.done);
    this.emit({ type: 'contracts' });
  }

  _stepContracts() {
    const C = this.contracts;
    let changed = false;
    for (const c of C.active) if (this.time > c.deadline) { c.failed = true; changed = true; this.emit({ type: 'contractFailed', contract: c.id, buyer: c.buyer }); }
    C.active = C.active.filter((c) => !c.failed);
    const before = C.offers.length;
    C.offers = C.offers.filter((o) => o.offerExpires > this.time);
    if (C.offers.length !== before) changed = true;
    if (this.time >= C.nextOfferAt && C.offers.length < 3) {
      C.offers.push(this._newOffer());
      C.nextOfferAt = this.time + (C.offers.length < 2 ? 5 : 45);
      changed = true;
    }
    if (changed) this.emit({ type: 'contracts' });
  }

  // ------------------------------------------------------------------ truck
  _setTruck(phase) {
    this.truck.phase = phase;
    this.truck.t0 = this.time;
    if (phase === 'dumping') { this.truck.manifest = this.pending.splice(0, this.pending.length); this.truck.dumped = 0; }
    this.emit({ type: 'truckPhase', phase, t0: this.time, manifest: phase === 'dumping' ? this.truck.manifest.length : undefined });
  }

  truckPose() { return truckPose(this.truck, this.time); }

  _stepTruck() {
    const T = this.truck;
    const t = this.time - T.t0;
    switch (T.phase) {
      case 'loading': if (t >= PHASE_TIME.loading) this._setTruck('inbound'); break;
      case 'inbound': if (t >= PHASE_TIME.inbound) this._setTruck('reversing'); break;
      case 'reversing': if (t >= PHASE_TIME.reversing) this._setTruck('opening'); break;
      case 'opening': if (t >= PHASE_TIME.opening) this._setTruck('dumping'); break;
      case 'dumping':
        while (T.dumped < T.manifest.length && t >= 0.2 + T.dumped * DUMP_INTERVAL) this._chuck(T.manifest[T.dumped++]);
        if (t >= dumpDuration(T.manifest.length)) this._setTruck('closing');
        break;
      case 'closing': if (t >= PHASE_TIME.closing) this._setTruck('outbound'); break;
      case 'outbound':
        if (t >= PHASE_TIME.outbound) { T.trips++; this._setTruck(this.pending.length ? 'loading' : 'idle'); }
        break;
    }
  }

  _chuck(stack) {
    const pose = this.truckPose();
    const rear = truckRear(pose);
    // raw materials go into the receiving dock (straight onto your belts); kits land on the bay
    if (ITEMS[stack.type].cat === 'raw' && this.dock.length < ECON.dockCap) {
      const before = this.dock.reduce((a, s) => a + s.count, 0);
      const left = this._dockAdd(stack);
      const moved = stack.count - left;
      if (moved > 0) {
        const h = FACTORY.dock.hopper;
        this.stats.delivered += moved;
        this.emit({ type: 'dockLoad', item: stack.type, count: moved, total: before + moved, from: [rear.x, TRUCK.bedHeight + 0.3, rear.z], to: [h.x, h.h + 0.3, h.z] });
      }
      if (left <= 0) return;
      stack = { ...stack, count: left };
    }
    const k = this.nextItemId;
    const spread = (hash01(this.seed + 11, k) - 0.5) * 1.1;
    const cs = Math.cos(spread), sn = Math.sin(spread);
    const bx = rear.bx * cs - rear.bz * sn, bz = rear.bx * sn + rear.bz * cs;
    const heavy = ITEMS[stack.type].cat === 'kit' && stack.type !== 'conveyor';
    const sp = (heavy ? 1.6 : 2.4) + hash01(this.seed + 12, k) * 2.2;
    this.spawnItem(stack.type, stack.count, [rear.x, TRUCK.bedHeight + 0.2, rear.z],
      [bx * sp, 3.6 + hash01(this.seed + 13, k) * 1.8, bz * sp],
      { puff: true, owner: stack.owner, tumble: (hash01(this.seed + 14, k) - 0.5) * (heavy ? 5 : 14), spin: (hash01(this.seed + 15, k) - 0.5) * 10 });
    this.stats.delivered += stack.count;
    this.emit({ type: 'chuck', x: rear.x, y: TRUCK.bedHeight + 0.2, z: rear.z });
  }

  // ------------------------------------------------------------------ save / load
  serialize() {
    const players = {};
    for (const [id, p] of this.players) players[id] = { inv: p.inventory.toJSON(), wallet: p.wallet };
    // Goods in transit are saved where they'd end up, so quitting never loses anything:
    // stacks the truck hasn't dropped yet go back in the order queue, and stacks the
    // van hasn't loaded (and so hasn't paid for) go back in the cage.
    const T = this.truck, V = this.van;
    const pending = [...(T.phase === 'dumping' ? T.manifest.slice(T.dumped) : []), ...this.pending];
    // … and anything raiders are running off with right now goes back in the cage too
    const cage = [...this.cage, ...(V.phase === 'loading' ? V.manifest.slice(V.loaded) : []), ...this.raids.carried()];
    const r2 = (n) => Math.round(n * 100) / 100;
    return {
      v: 3, funds: this.funds, stats: this.stats, progress: this.progress, cage, players, pending, raids: this.raids.serialize(),
      machines: [...this.machines.values()].map((m) => {
        const o = { type: m.type, x: m.x, z: m.z, q: m.q, auto: m.auto, outMode: m.outMode, buffer: m.buffer };
        if (m.def.defence === 'turret') o.ammo = m.ammo;
        return o;
      }),
      belts: [...this.belts.values()].map((b) => (b.kind === 'belt' ? { x: b.x, z: b.z, q: b.q } : { x: b.x, z: b.z, q: b.q, k: b.kind, f: b.filter, s: b.side })),
      dock: this.dock,
      items: [...this.items.values()].map((it) => [it.type, it.count, r2(it.x), r2(it.y), r2(it.z), it.owner || null]),
    };
  }

  /** Restore machines, belts, funds and the cage from serialize() output. */
  load(data) {
    if (!data || data.v !== 3) return false;
    for (const id of [...this.machines.keys()]) this.removeMachine(id);
    for (const id of [...this.belts.keys()]) this.removeBelt(id);
    this.beltKeys.clear();
    this.funds = Number.isFinite(data.funds) ? data.funds : this.funds;
    this.stats = Object.assign(freshStats(), data.stats || {});
    this.progress = { xp: Number(data.progress?.xp) || 0, goals: Array.isArray(data.progress?.goals) ? data.progress.goals.filter((g) => GOALS.some((x) => x.id === g)) : [] };
    this.cage = Array.isArray(data.cage) ? data.cage.filter((s) => ITEMS[s.type]) : [];
    for (const m of data.machines || []) {
      if (!MACHINES[m.type] || !this.canPlace(m.type, m.x, m.z, m.q).ok) continue;
      const inst = this._createMachine(m.type, m.x, m.z, m.q);
      inst.auto = m.auto || null;
      inst.outMode = m.outMode === 'belt' ? 'belt' : 'tray';
      inst.buffer = m.buffer || {};
      if (inst.def.defence === 'turret') inst.ammo = Math.max(0, Math.min(TURRET.capacity, m.ammo | 0));
    }
    for (const b of data.belts || []) {
      const kind = NODE_TYPES.includes(b.k) ? b.k : 'belt';
      if (this.canPlace(kind === 'belt' ? 'conveyor' : kind, b.x, b.z, b.q).ok) this._createBelt(b.x, b.z, b.q, null, kind, { filter: b.f, side: b.s });
    }
    this.dock = Array.isArray(data.dock) ? data.dock.filter((st) => st && ITEMS[st.type] && st.count > 0).slice(0, ECON.dockCap) : [];
    for (const id of [...this.items.keys()]) this._removeItem(id);
    for (const a of Array.isArray(data.items) ? data.items.slice(0, 2000) : []) {
      if (!Array.isArray(a) || !ITEMS[a[0]] || !(a[1] > 0)) continue;
      // items settle again from just above where they were (belts pick them back up)
      this.spawnItem(a[0], a[1] | 0, [a[2], a[3] + 0.05, a[4]], [0, 0, 0], { owner: a[5] || null, spin: 0 });
    }
    this.pending = Array.isArray(data.pending) ? data.pending.filter((st) => st && ITEMS[st.type] && st.count > 0) : [];
    if (this.pending.length && this.truck.phase === 'idle') this._setTruck('loading');
    this.raids.load(data.raids);
    return true;
  }

  /** Back to a brand-new factory (keeps connected players, empties their pockets). */
  reset() {
    this.load({ v: 3, funds: ECON.startFunds, stats: freshStats(), progress: { xp: 0, goals: [] }, cage: [], dock: [], machines: FACTORY.starter, belts: [] });
    this.emit({ type: 'xp', xp: 0 });
    for (const p of this.players.values()) { p.inventory = new Inventory(24); p.wallet = 0; this.emit({ type: 'inventory', player: p.id }); this.emit({ type: 'wallet', player: p.id, wallet: 0, delta: 0 }); }
    for (const id of [...this.items.keys()]) this._removeItem(id);
    this.contracts.active = [];
    this.contracts.offers = [];
    this.contracts.nextOfferAt = this.time + 5;
    // Cancel anything already paid for / already sold that's still in transit — otherwise
    // a delivery truck or pickup van finishes its trip after the reset and either hands
    // over a paid order for free, or pays out cage value a second time (a money dupe).
    this.pending = [];
    this.truck = { phase: 'idle', t0: this.time, manifest: [], dumped: 0, trips: 0 };
    this.van = { phase: 'idle', t0: this.time, manifest: [], loaded: 0, trips: 0 };
    this.emit({ type: 'truckPhase', phase: 'idle', t0: this.time });
    this.emit({ type: 'vanPhase', phase: 'idle', t0: this.time });
    this.raids.clear();
    this.emit({ type: 'raidReset' });
    this.emit({ type: 'funds', funds: this.funds, delta: 0 });
  }

  // ------------------------------------------------------------------ tick
  tick(dt) {
    this.time += dt;
    this._stepTruck();
    this._stepVan();
    this._stepMachines();
    this._stepDock();
    this._stepItems(dt);
    this._stepContracts();
    this.raids.tick(dt);
    this._goalT += dt;
    if (this._goalT >= 0.25) { this._goalT = 0; this._checkGoals(); }
    const ev = this.events;
    this.events = [];
    return ev;
  }
}
