// Navigation grid for raiders: 1 m cells over the yard and the hills around it, built
// from the same colliders players collide with. Cells are FREE, WALL (a barricade they
// can climb), FENCE (the chain-link perimeter — climbable but slow), GATE (security gate:
// mercs can breach it, scavengers can't pass) or BLOCK. A* with a binary heap on typed
// arrays; placing or removing anything only re-classifies the cells it touches.
import { MASK } from '../mapLayout.js';

export const FREE = 0, WALL = 1, FENCE = 2, GATE = 3, BLOCK = 4;
export const NAV = { x0: -72, z0: -64, w: 144, h: 128 };
const N = NAV.w * NAV.h;
const R = 0.49; // probe the whole cell so thin fences between cell centres still register
const STEP = 0.55; // obstacles this low are stepped over
const HEAD = 1.9; // obstacles starting this high are walked under
const CLIMB_COST = { [WALL]: 5, [FENCE]: 14 }; // per cell (a barrier covers 1–2 cells)
const BREACH_COST = 14;
const DX = [1, -1, 0, 0, 1, 1, -1, -1], DZ = [0, 0, 1, -1, 1, -1, 1, -1], DL = [1, 1, 1, 1, Math.SQRT2, Math.SQRT2, Math.SQRT2, Math.SQRT2];

export class NavGrid {
  constructor(world) {
    this.world = world;
    this.kind = new Uint8Array(N);
    this.cost = new Float32Array(N); // terrain cost multiplier (slopes)
    this.top = new Float32Array(N); // climb height of WALL/FENCE cells
    this.gate = new Array(N).fill(null); // gate machine id for GATE cells
    this.g = new Float32Array(N);
    this.parent = new Int32Array(N);
    this.seen = new Uint32Array(N);
    this.closed = new Uint32Array(N);
    this.stamp = 0;
    this.heapI = new Int32Array(1024);
    this.heapF = new Float32Array(1024);
    this.heapN = 0;
    this.dirty = [];
    this.built = false;
    this.scratch = [];
    this.version = 0; // bumps when anything changes → raiders re-plan
  }

  // ------------------------------------------------------------------ cells
  index(x, z) {
    const ix = Math.floor(x - NAV.x0), iz = Math.floor(z - NAV.z0);
    if (ix < 0 || iz < 0 || ix >= NAV.w || iz >= NAV.h) return -1;
    return iz * NAV.w + ix;
  }
  cx(i) { return NAV.x0 + (i % NAV.w) + 0.5; }
  cz(i) { return NAV.z0 + Math.floor(i / NAV.w) + 0.5; }
  kindAt(x, z) { this.ensure(); const i = this.index(x, z); return i < 0 ? BLOCK : this.kind[i]; }

  ensure() {
    if (!this.built) this.build();
    else if (this.dirty.length) this._flush();
  }

  build() {
    for (let i = 0; i < N; i++) this._classify(i);
    this.built = true;
    this.dirty.length = 0;
    this.version++;
  }

  /** Something changed inside this rectangle (world units). */
  markDirty(x0, z0, x1, z1) {
    if (!this.built) return;
    this.dirty.push([x0 - 1, z0 - 1, x1 + 1, z1 + 1]);
  }

  _flush() {
    for (const [x0, z0, x1, z1] of this.dirty) {
      const a0 = Math.max(0, Math.floor(x0 - NAV.x0)), a1 = Math.min(NAV.w - 1, Math.floor(x1 - NAV.x0));
      const b0 = Math.max(0, Math.floor(z0 - NAV.z0)), b1 = Math.min(NAV.h - 1, Math.floor(z1 - NAV.z0));
      for (let iz = b0; iz <= b1; iz++) for (let ix = a0; ix <= a1; ix++) this._classify(iz * NAV.w + ix);
    }
    this.dirty.length = 0;
    this.version++;
  }

  _classify(i) {
    const w = this.world;
    const x = this.cx(i), z = this.cz(i);
    const gy = w.heightAt(x, z);
    let k = FREE, top = 0, gate = null;
    for (const c of w.query(x - R, z - R, x + R, z + R, MASK.WALKERS, this.scratch)) {
      if (c.max[1] <= gy + STEP || c.min[1] >= gy + HEAD) continue;
      if (c.gate && !(c.mask & MASK.PLAYER)) { if (k < GATE) { k = GATE; gate = c.gate; } }
      else if (c.climb) { const kk = c.fence ? FENCE : WALL; if (k < kk) k = kk; top = Math.max(top, c.max[1]); }
      else { k = BLOCK; break; }
    }
    this.kind[i] = k;
    this.top[i] = top;
    this.gate[i] = gate;
    // hills cost more to cross than the flat yard
    const s = Math.abs(w.heightAt(x + 0.5, z) - w.heightAt(x - 0.5, z)) + Math.abs(w.heightAt(x, z + 0.5) - w.heightAt(x, z - 0.5));
    this.cost[i] = 1 + Math.min(4, s * 1.6);
  }

  /** Nearest cell of an allowed kind to (x, z), searching rings out to `maxR` cells. */
  nearestFree(x, z, maxR = 8) {
    this.ensure();
    const ix = Math.floor(x - NAV.x0), iz = Math.floor(z - NAV.z0);
    let best = -1, bestD = Infinity;
    for (let r = 0; r <= maxR; r++) {
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
        const jx = ix + dx, jz = iz + dz;
        if (jx < 0 || jz < 0 || jx >= NAV.w || jz >= NAV.h) continue;
        const j = jz * NAV.w + jx;
        if (this.kind[j] !== FREE) continue;
        const d = (this.cx(j) - x) ** 2 + (this.cz(j) - z) ** 2;
        if (d < bestD) { bestD = d; best = j; }
      }
      if (best >= 0) return best;
    }
    return -1;
  }

  // ------------------------------------------------------------------ A*
  _push(i, f) {
    if (this.heapN >= this.heapI.length) {
      const a = new Int32Array(this.heapI.length * 2); a.set(this.heapI); this.heapI = a;
      const b = new Float32Array(this.heapF.length * 2); b.set(this.heapF); this.heapF = b;
    }
    const H = this.heapI, F = this.heapF;
    let k = this.heapN++;
    while (k > 0) {
      const p = (k - 1) >> 1;
      if (F[p] <= f) break;
      H[k] = H[p]; F[k] = F[p]; k = p;
    }
    H[k] = i; F[k] = f;
  }

  _pop() {
    const H = this.heapI, F = this.heapF;
    const top = H[0];
    const n = --this.heapN;
    if (n > 0) {
      const li = H[n], lf = F[n];
      let k = 0;
      for (;;) {
        let c = 2 * k + 1;
        if (c >= n) break;
        if (c + 1 < n && F[c + 1] < F[c]) c++;
        if (F[c] >= lf) break;
        H[k] = H[c]; F[k] = F[c]; k = c;
      }
      H[k] = li; F[k] = lf;
    }
    return top;
  }

  _enter(j, breach) {
    const k = this.kind[j];
    if (k === FREE) return 0;
    if (k === WALL || k === FENCE) return CLIMB_COST[k];
    if (k === GATE) return breach ? BREACH_COST : -1;
    return -1;
  }

  /**
   * Cheapest route between two points. Returns cell indices (start … goal) or null.
   * `breach`: may go through security gates (mercs).
   */
  findPath(sx, sz, gx, gz, { breach = false, maxExpand = 14000 } = {}) {
    this.ensure();
    let s = this.index(sx, sz);
    if (s < 0 || this.kind[s] === BLOCK) s = this.nearestFree(sx, sz, 4);
    let t = this.index(gx, gz);
    if (t < 0 || this.kind[t] !== FREE) t = this.nearestFree(gx, gz, 6);
    if (s < 0 || t < 0) return null;
    if (s === t) return [s];
    const W = NAV.w;
    const stamp = ++this.stamp;
    const g = this.g, par = this.parent, seen = this.seen, closed = this.closed;
    const tx = t % W, tz = (t / W) | 0;
    const kind = this.kind, cost = this.cost;
    const S2 = Math.SQRT2 - 1;
    this.heapN = 0;
    g[s] = 0; par[s] = -1; seen[s] = stamp;
    this._push(s, 0);
    let expanded = 0;
    while (this.heapN) {
      const i = this._pop();
      if (closed[i] === stamp) continue;
      closed[i] = stamp;
      if (i === t) break;
      if (++expanded > maxExpand) return null;
      const ix = i % W, iz = (i / W) | 0;
      const gi = g[i], ci = cost[i];
      for (let d = 0; d < 8; d++) {
        const jx = ix + DX[d], jz = iz + DZ[d];
        if (jx < 0 || jz < 0 || jx >= W || jz >= NAV.h) continue;
        const j = jz * W + jx;
        if (closed[j] === stamp) continue;
        const kj = kind[j];
        let extra = 0;
        if (kj !== FREE) { extra = this._enter(j, breach); if (extra < 0) continue; }
        // no corner cutting past anything that isn't open ground
        if (d >= 4 && (kind[iz * W + jx] !== FREE || kind[jz * W + ix] !== FREE)) continue;
        const ng = gi + DL[d] * 0.5 * (ci + cost[j]) + extra;
        if (seen[j] === stamp && ng >= g[j]) continue;
        seen[j] = stamp; g[j] = ng; par[j] = i;
        const hx = jx > tx ? jx - tx : tx - jx, hz = jz > tz ? jz - tz : tz - jz;
        this._push(j, ng + (hx > hz ? hx + S2 * hz : hz + S2 * hx));
      }
    }
    if (closed[t] !== stamp) return null;
    const path = [];
    for (let i = t; i >= 0; i = par[i]) path.push(i);
    path.reverse();
    return path;
  }

  /** Straight walk from (ax,az) to (bx,bz) over open ground only? */
  lineClear(ax, az, bx, bz) {
    const d = Math.hypot(bx - ax, bz - az);
    const n = Math.max(1, Math.ceil(d / 0.4));
    for (let k = 1; k <= n; k++) {
      const u = k / n;
      const i = this.index(ax + (bx - ax) * u, az + (bz - az) * u);
      if (i < 0 || this.kind[i] !== FREE) return false;
      // stay a little away from corners: check the probe square's sides too
    }
    return true;
  }
}
