// Raid balancing tables (build 0.5). Everything the raid director, raiders, turrets and
// player health do is tuned here, so balancing never touches game code.

export const RAID = {
  minLevel: 2, // raids start once the company reaches this level
  firstDelay: [150, 240], // seconds from reaching the level to the first (small) raid
  cooldown: [15 * 60, 25 * 60], // calm time after a raid ends before the next one arrives
  warning: 90, // seconds of warning before raiders reach the fence
  imminent: 10, // second siren this long before arrival
  maxTime: 300, // a raid that drags on this long: everyone left retreats
  resumeDelay: 120, // loading a save that was mid-raid: the raid comes back after this
  maxAlive: 9, // raiders on the map at once (server CPU on the free plan)
  maxUnits: 14,
  cleanBonus: 60, // company payout per raider when nothing gets stolen
};

// Where raids come from: the fence gap they head for and where they spawn / escape to.
export const RAID_DIRS = {
  north: { label: 'north', spawn: [-27.5, -55], gap: [-27.5, -40], bearing: 0 },
  east: { label: 'east', spawn: [65, 12.5], gap: [50, 12.5], bearing: 90 },
  south: { label: 'south', spawn: [0, 55], gap: [0, 40], bearing: 180 },
  west: { label: 'west', spawn: [-65, -7.5], gap: [-50, -7.5], bearing: 270 },
};
export const DIR_KEYS = Object.keys(RAID_DIRS);

export const RAIDERS = {
  scav: {
    name: 'Scavenger', cost: 1, hp: 70, armor: { body: 1, head: 1 }, speed: 3.8, carry: 1, bounty: 20,
    weapon: { body: 8, head: 15, interval: 0.5, burst: 3, pause: 1.4, sigma: 0.05, range: 30, react: 0.9 },
    grab: 1.3, climb: 1.6,
  },
  merc: {
    name: 'Armoured merc', cost: 2, hp: 150, armor: { body: 0.55, head: 0.85 }, speed: 3.4, carry: 2, bounty: 50,
    weapon: { body: 9, head: 16, interval: 0.3, burst: 4, pause: 1.3, sigma: 0.035, range: 40, react: 0.6 },
    grab: 1.1, climb: 1.4, breach: 3.5, hunts: true,
  },
  drone: {
    name: 'Cargo drone', cost: 1.5, hp: 45, armor: { body: 1, head: 1 }, speed: 6.5, carry: 1, bounty: 30,
    grab: 1.0, cruise: 7, radius: 0.55,
  },
};
export const KIND_CODE = { scav: 0, merc: 1, drone: 2 };
export const KIND_BY_CODE = ['scav', 'merc', 'drone'];

export const TURRET = {
  range: 26,
  headY: 1.3,
  turnRate: 6, // rad/s
  pitchRate: 4,
  interval: 0.22,
  spread: 0.021, // rad
  damage: { body: 12, head: 24 },
  roundsPerBox: 30,
  capacity: 240,
  scan: 0.15,
};

export const HEALTH = {
  max: 100,
  regenDelay: 6,
  regenRate: 15, // hp/s
  bleedout: 10, // seconds downed before respawning at the terminal
  reviveTime: 3,
  reviveReach: 2.4,
  reviveHp: 50,
};

/** Unit mix for a raid of `budget` points. `rand` → [0,1). */
export function composeRaid(budget, { mercs, drones, rand }) {
  const out = [];
  let left = budget;
  while (left >= 1 && out.length < RAID.maxUnits) {
    const r = rand();
    let kind = 'scav';
    if (drones && r < 0.2 && left >= RAIDERS.drone.cost) kind = 'drone';
    else if (mercs && r < 0.5 && left >= RAIDERS.merc.cost) kind = 'merc';
    out.push(kind);
    left -= RAIDERS[kind].cost;
  }
  // scavengers lead the way in; mercs and drones follow
  const order = { scav: 0, merc: 1, drone: 2 };
  return out.sort((a, b) => order[a] - order[b]);
}
