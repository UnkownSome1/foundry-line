// Raids (build 0.5). Part of the authoritative FactorySim, so solo and the co-op server
// run exactly the same code:
//  • Director: off until company level 2, then calm (15–25 min) → 90 s warning → raid.
//    Size scales with the raid count, company level, goods at risk, players and turrets.
//  • Raiders (scavengers, armoured mercs, cargo drones) path over a nav grid to the pickup
//    cage and loose goods, grab them and run for the fence. Machines are never damaged.
//    Kill a raider and whatever they carried drops where they fell.
//  • Players have health here: raiders shoot at them; at 0 hp you're downed — a partner
//    holds E to revive you, otherwise you're back at the terminal after 10 s. Nothing lost.
//  • Sentry turrets (placed like machines) track and shoot raiders, using ammo boxes.
//  • Player shots at raiders arrive as `shoot` commands and are checked against where the
//    raiders were when the shooter saw them (lag compensation).
import { RAID, RAID_DIRS, DIR_KEYS, RAIDERS, TURRET, HEALTH, composeRaid } from './raidDefs.js';
import { NavGrid, FREE, WALL, FENCE, GATE } from './nav.js';
import { ITEMS } from '../factory/items.js';
import { FACTORY } from '../factory/layout.js';
import { MASK, HALL } from '../mapLayout.js';
import { rayVsCharacter } from '../hitscan.js';
import { WEAPONS } from '../weapons.js';
import { PLAYER } from '../constants.js';
import { pushFromVehicles } from '../vehiclePush.js';

const HIST = 48; // lag-compensation history (ticks) ≈ 0.8 s
const scratch = [];
const EYE = 1.45;
const r2 = (n) => Math.round(n * 100) / 100;
const angDiff = (a, b) => { let d = a - b; d = ((d + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI; return d; };
const approachAng = (a, b, step) => { const d = angDiff(b, a); return Math.abs(d) <= step ? b : a + Math.sign(d) * step; };
const inHall = (x, z) => Math.abs(x - HALL.x) < HALL.w / 2 && Math.abs(z - HALL.z) < HALL.d / 2;

/** Ray vs sphere → distance or null. */
function raySphere(ox, oy, oz, dx, dy, dz, cx, cy, cz, r, maxT) {
  const lx = cx - ox, ly = cy - oy, lz = cz - oz;
  const b = lx * dx + ly * dy + lz * dz;
  const c = lx * lx + ly * ly + lz * lz - r * r;
  const disc = b * b - c;
  if (disc < 0) return null;
  const t = b - Math.sqrt(disc);
  return t > 0 && t < maxT ? t : null;
}

export class RaidSystem {
  constructor(sim, { replica = false } = {}) {
    this.sim = sim;
    this.world = sim.world;
    this.replica = replica;
    this.nav = new NavGrid(sim.world);
    this.phase = 'off'; // off · calm · warning · active
    this.timer = 0; // seconds until the next raid arrives (calm / warning)
    this.no = 0; // raids so far in this company
    this.dir = null;
    this.plan = null;
    this.raiders = new Map();
    this.nextId = 1;
    this.stats = { raids: 0, repelled: 0, killed: 0, escaped: 0, stolenValue: 0, recoveredValue: 0 };
    this.cur = null; // tally of the raid in progress
    this.queue = []; // units still to spawn
    this.spawnT = 0;
    this.hold = false; // solo: frozen while the player is in a menu
    this.lastDir = null;
    this.breached = new Set();
    this.tick_ = 0;
  }

  emit(e) { this.sim.emit(e); }
  rand() { return this.sim.rand(); }
  get time() { return this.sim.time; }
  get active() { return this.phase === 'active'; }

  /** Players actually in the session (co-op guests who left stay in the save, not here). */
  online() {
    const out = [];
    for (const p of this.sim.players.values()) if (p.online !== false) out.push(p);
    return out;
  }

  // =================================================================== director
  tick(dt) {
    if (this.replica || this.hold) return;
    this.tick_++;
    this._director(dt);
    this._players(dt);
    if (this.raiders.size) this._raiders(dt);
    this._turrets(dt);
  }

  _director(dt) {
    const lvl = this.sim.levelInfo().level;
    switch (this.phase) {
      case 'off':
        if (lvl >= RAID.minLevel) {
          this.phase = 'calm';
          this.timer = RAID.firstDelay[0] + this.rand() * (RAID.firstDelay[1] - RAID.firstDelay[0]);
          this.emit({ type: 'raidIntro', eta: Math.round(this.timer) });
        }
        break;
      case 'calm':
        this.timer -= dt;
        if (this.timer <= RAID.warning) this._warn();
        break;
      case 'warning': {
        const before = this.timer;
        this.timer -= dt;
        if (before > RAID.imminent && this.timer <= RAID.imminent) this.emit({ type: 'raidImminent', dir: this.dir });
        if (this.timer <= 0) this._start();
        break;
      }
      case 'active': {
        this.cur.t += dt;
        this.spawnT -= dt;
        let alive = 0;
        for (const r of this.raiders.values()) if (r.alive) alive++;
        if (this.queue.length && this.spawnT <= 0 && alive < RAID.maxAlive) {
          const n = Math.min(this.queue.length, 2, RAID.maxAlive - alive);
          for (let i = 0; i < n; i++) this._spawn(this.queue.shift(), i);
          this.spawnT = 4 + this.rand() * 3;
        }
        if (this.cur.t > RAID.maxTime && !this.cur.retreat) {
          this.cur.retreat = true;
          this.queue.length = 0;
          for (const r of this.raiders.values()) if (r.alive && r.kind !== 'drone') this._setEscape(r);
          this.emit({ type: 'raidRetreat' });
        }
        if (!this.queue.length && ![...this.raiders.values()].some((r) => r.alive)) this._end();
        break;
      }
    }
  }

  /** Goods lying around that raiders might go for, and what they're worth. */
  goodsAtRisk() {
    let v = this.sim.cageValue();
    for (const it of this.sim.items.values()) if (it.rest && ITEMS[it.type].cat !== 'kit') v += ITEMS[it.type].value * it.count;
    return v;
  }

  _budget() {
    if (this.no === 0) return 2;
    const lvl = this.sim.levelInfo().level;
    const players = Math.max(1, this.online().length);
    let turrets = 0;
    for (const m of this.sim.machines.values()) if (m.def.defence === 'turret') turrets++;
    const risk = Math.max(0, Math.min(4, Math.log2(1 + this.goodsAtRisk() / 400)));
    return Math.min(RAID.maxUnits, 2.5 + 0.9 * Math.min(this.no, 12) + 0.35 * lvl + risk + 1.1 * (players - 1) + 0.35 * turrets);
  }

  _warn() {
    this.phase = 'warning';
    const opts = DIR_KEYS.filter((d) => d !== this.lastDir);
    this.dir = opts[Math.floor(this.rand() * opts.length)];
    const lvl = this.sim.levelInfo().level;
    const units = composeRaid(this._budget(), {
      mercs: this.no >= 2 || lvl >= 5, drones: this.no >= 3 || lvl >= 6, rand: () => this.rand(),
    });
    const kinds = { scav: 0, merc: 0, drone: 0 };
    for (const k of units) kinds[k]++;
    this.plan = { units, kinds, size: units.length <= 3 ? 'small' : units.length <= 7 ? 'medium' : 'large' };
    this.nav.ensure();
    this.emit({ type: 'raidWarning', dir: this.dir, eta: Math.round(this.timer), count: units.length, kinds, size: this.plan.size, no: this.no + 1 });
  }

  _start() {
    this.phase = 'active';
    this.timer = 0;
    this.no++;
    this.lastDir = this.dir;
    this.queue = this.plan.units.slice();
    this.spawnT = 0;
    this.cur = { t: 0, killed: 0, escaped: 0, stolenValue: 0, recoveredValue: 0, bounty: 0, count: this.queue.length, retreat: false };
    this.stats.raids++;
    this.emit({ type: 'raidStart', dir: this.dir, count: this.queue.length, no: this.no });
  }

  _end() {
    const c = this.cur;
    const repelled = c.escaped === 0;
    let bonus = 0;
    if (repelled && c.killed > 0) {
      bonus = RAID.cleanBonus * c.killed;
      this.sim.funds += bonus;
      this.emit({ type: 'funds', funds: this.sim.funds, delta: bonus });
      this.stats.repelled++;
    }
    this._repairGates();
    for (const [id, r] of this.raiders) if (!r.alive) { this.raiders.delete(id); this.emit({ type: 'raiderGone', id }); }
    this.phase = 'calm';
    this.timer = RAID.cooldown[0] + this.rand() * (RAID.cooldown[1] - RAID.cooldown[0]);
    this.emit({ type: 'raidEnd', killed: c.killed, escaped: c.escaped, stolen: c.stolenValue, recovered: c.recoveredValue, bonus, repelled, bounty: c.bounty });
    this.cur = null;
    this.plan = null;
  }

  // =================================================================== raiders
  _spawn(kind, k) {
    const D = RAID_DIRS[this.dir];
    const def = RAIDERS[kind];
    // spread arrivals sideways along the approach
    const [sx, sz] = D.spawn;
    const px = -(D.gap[1] - sz), pz = D.gap[0] - sx;
    const pl = Math.hypot(px, pz) || 1;
    const off = (this.rand() - 0.5) * 9 + (k ? 2.5 : -2.5);
    let x = sx + (px / pl) * off, z = sz + (pz / pl) * off;
    let y;
    if (kind === 'drone') {
      x += (sx - D.gap[0]) * 0.15; z += (sz - D.gap[1]) * 0.15;
      y = this.world.heightAt(x, z) + def.cruise + 3;
    } else {
      const c = this.nav.nearestFree(x, z, 10);
      if (c >= 0) { x = this.nav.cx(c); z = this.nav.cz(c); }
      y = this.world.heightAt(x, z);
    }
    const r = {
      id: this.nextId++, kind, def, x, y, z, vx: 0, vy: 0, vz: 0, px: x, py: y, pz: z,
      yaw: Math.atan2(-(D.gap[0] - x), -(D.gap[1] - z)), pitch: 0, pyaw: 0,
      hp: def.hp, alive: true, state: kind === 'drone' ? 'fly' : 'enter', carry: [], target: null,
      path: null, pi: 0, goal: null, navVer: -1, repath: 0, mode: 'move', modeT: 0,
      foe: null, seeT: 0, senseT: this.rand() * 0.25, fireT: 0, burstLeft: def.weapon ? def.weapon.burst : 0,
      climb: null, breach: null, grabT: 0, roamT: 0, deadT: 0, stuckT: 0, stuckX: x, stuckZ: z, stuckN: 0, aware: 0,
      hist: { t: new Float64Array(HIST), x: new Float32Array(HIST), y: new Float32Array(HIST), z: new Float32Array(HIST), i: 0, n: 0 },
    };
    r.pyaw = r.yaw;
    this.raiders.set(r.id, r);
    this.emit({ type: 'raiderSpawn', id: r.id, kind, x: r2(x), y: r2(y), z: r2(z) });
    return r;
  }

  _raiders(dt) {
    for (const [id, r] of this.raiders) {
      r.px = r.x; r.py = r.y; r.pz = r.z; r.pyaw = r.yaw;
      if (!r.alive) {
        r.deadT += dt;
        if (r.kind === 'drone' && r.y > this.world.heightAt(r.x, r.z) + 0.3) {
          r.vy -= 14 * dt;
          r.x += r.vx * dt; r.z += r.vz * dt; r.y += r.vy * dt;
          r.vx *= 0.99; r.vz *= 0.99;
          const g = this.world.groundHeight(r.x, r.z, 0.3, r.y + 0.5);
          if (r.y <= g) { r.y = g; r.vx = r.vz = 0; this.emit({ type: 'droneCrash', id: r.id, x: r2(r.x), y: r2(r.y), z: r2(r.z) }); this._dropLoot(r); }
        }
        if (r.deadT > 7) { this.raiders.delete(id); this.emit({ type: 'raiderGone', id }); }
        continue;
      }
      if (r.dummy) { /* test target: stands still */ }
      else if (r.kind === 'drone') this._drone(r, dt);
      else this._walker(r, dt);
      // lag-compensation history
      const h = r.hist;
      h.t[h.i] = this.time; h.x[h.i] = r.x; h.y[h.i] = r.y; h.z[h.i] = r.z;
      h.i = (h.i + 1) % HIST; h.n = Math.min(HIST, h.n + 1);
    }
  }

  /** Where raider `r` was at time `t` (within the last ~0.8 s). */
  rewind(r, t) {
    const h = r.hist;
    if (!h.n || t >= this.time - 1e-6) return [r.x, r.y, r.z];
    let newer = -1;
    for (let k = 1; k <= h.n; k++) {
      const i = (h.i - k + HIST) % HIST;
      if (h.t[i] <= t) {
        if (newer < 0) return [h.x[i], h.y[i], h.z[i]];
        const u = (t - h.t[i]) / Math.max(1e-6, h.t[newer] - h.t[i]);
        return [h.x[i] + (h.x[newer] - h.x[i]) * u, h.y[i] + (h.y[newer] - h.y[i]) * u, h.z[i] + (h.z[newer] - h.z[i]) * u];
      }
      newer = i;
    }
    const o = (h.i - h.n + HIST) % HIST;
    return [h.x[o], h.y[o], h.z[o]];
  }

  // ------------------------------------------------------------------ loot
  _claimed(key, except) {
    for (const o of this.raiders.values()) if (o !== except && o.alive && o.target && o.target.key === key) return true;
    return false;
  }

  _pickTarget(r) {
    const sim = this.sim;
    const drone = r.kind === 'drone';
    let best = null, bestS = 0;
    const c = FACTORY.cage;
    const cx = (c.x0 + c.x1) / 2 + 0.6, cz = (c.z0 + c.z1) / 2;
    for (const s of sim.cage) {
      if (this._claimed(s, r)) continue;
      const v = ITEMS[s.type].value * s.count;
      const d = Math.hypot(cx - r.x, cz - r.z);
      const sc = (v + 40) / (1 + d / 25);
      if (sc > bestS) { bestS = sc; best = { kind: 'cage', key: s, x: cx, y: 0, z: cz }; }
    }
    for (const it of sim.items.values()) {
      if (!it.rest || it.belt) continue;
      if (drone && (inHall(it.x, it.z) || it.y > 2.5)) continue;
      if (this._claimed(it.id, r)) continue;
      const v = ITEMS[it.type].value * it.count * (ITEMS[it.type].cat === 'kit' ? 0.6 : 1);
      const d = Math.hypot(it.x - r.x, it.z - r.z);
      const sc = (v + 10) / (1 + d / 25);
      if (sc > bestS) { bestS = sc; best = { kind: 'item', key: it.id, x: it.x, y: it.y, z: it.z }; }
    }
    return best;
  }

  _targetValid(r) {
    const t = r.target;
    if (!t) return false;
    if (t.kind === 'cage') return this.sim.cage.includes(t.key);
    if (t.kind === 'item') { const it = this.sim.items.get(t.key); if (!it) return false; t.x = it.x; t.y = it.y; t.z = it.z; return true; }
    return t.kind === 'roam' || t.kind === 'foe';
  }

  _grab(r) {
    const sim = this.sim, t = r.target;
    let stack = null;
    if (t.kind === 'cage') {
      const i = sim.cage.indexOf(t.key);
      if (i >= 0) { stack = sim.cage.splice(i, 1)[0]; this.emit({ type: 'cageTaken', cage: sim.cage.length, value: sim.cageValue() }); }
    } else if (t.kind === 'item') {
      const it = sim.items.get(t.key);
      if (it && Math.hypot(it.x - r.x, it.z - r.z) < 2.6) { stack = { type: it.type, count: it.count, owner: it.owner || null }; sim._removeItem(it.id); }
    }
    r.target = null;
    r.path = null;
    if (!stack) return;
    r.carry.push(stack);
    this.emit({ type: 'raiderLoot', id: r.id, item: stack.type, count: stack.count, from: t.kind, value: ITEMS[stack.type].value * stack.count });
  }

  _dropLoot(r) {
    if (!r.carry.length) return;
    for (const s of r.carry) {
      const a = this.rand() * Math.PI * 2;
      this.sim.spawnItem(s.type, s.count, [r.x, r.y + (r.kind === 'drone' ? 0.3 : 1.1), r.z], [Math.cos(a) * 1.5, 2.2, Math.sin(a) * 1.5], { owner: s.owner, puff: true, tumble: 6 });
      if (this.cur) this.cur.recoveredValue += ITEMS[s.type].value * s.count;
      this.stats.recoveredValue += ITEMS[s.type].value * s.count;
    }
    r.carry = [];
  }

  _setEscape(r) {
    r.state = 'escape';
    r.target = null;
    r.path = null;
    r.mode = 'move';
    r.foe = null;
    r.breach = null;
  }

  _escaped(r) {
    let value = 0;
    for (const s of r.carry) value += ITEMS[s.type].value * s.count;
    if (this.cur) { this.cur.escaped += r.carry.length ? 1 : 0; this.cur.stolenValue += value; }
    if (r.carry.length) { this.stats.escaped++; this.stats.stolenValue += value; }
    this.emit({ type: 'raiderEscaped', id: r.id, value, items: r.carry.map((s) => [s.type, s.count]) });
    r.carry = [];
    this.raiders.delete(r.id);
  }

  // ------------------------------------------------------------------ walkers
  _walker(r, dt) {
    const def = r.def;
    // --- what am I doing?
    if (r.state === 'enter') {
      if (r.target && r.target.kind === 'roam') {
        // nothing worth taking: prowl toward the players, keep checking for loot, give up after a while
        r.roamT += dt;
        r.retarget = (r.retarget || 0) - dt;
        if (r.retarget <= 0) {
          r.retarget = 3;
          const t = this._pickTarget(r);
          if (t) { r.target = t; r.path = null; } else this._roam(r);
        }
        if (r.roamT > 45) this._setEscape(r);
      } else if (!this._targetValid(r)) {
        r.target = this._pickTarget(r);
        r.path = null;
        if (!r.target) this._roam(r);
      }
    }
    // --- senses + gun
    r.senseT -= dt;
    if (r.senseT <= 0) { r.senseT = 0.25; this._sense(r); }
    this._aimAndFire(r, dt);

    // --- movement
    if (r.climb) { this._stepClimb(r, dt); return; }
    if (r.breach) { this._stepBreach(r, dt); return; }
    let goal = null;
    if (r.state === 'escape') goal = RAID_DIRS[this.dir || 'north'].spawn;
    else if (def.hunts && r.foe && !r.carry.length) {
      const f = this.sim.players.get(r.foe);
      if (f && Math.hypot(f.pos[0] - r.x, f.pos[2] - r.z) > 11) goal = [f.pos[0], f.pos[2]];
    }
    if (!goal && r.target) goal = [r.target.x, r.target.z];

    // grabbing?
    if (r.state === 'enter' && r.target && r.target.kind !== 'roam' && !(def.hunts && r.foe)) {
      const d = Math.hypot(r.target.x - r.x, r.target.z - r.z);
      if (d < (r.target.kind === 'cage' ? 1.6 : 1.2)) {
        r.grabT += dt;
        r.mode = 'hold';
        if (r.grabT >= def.grab) {
          r.grabT = 0;
          this._grab(r);
          if (r.carry.length >= def.carry) this._setEscape(r);
          else {
            const next = this._pickTarget(r);
            if (next && Math.hypot(next.x - r.x, next.z - r.z) < 14) r.target = next; else this._setEscape(r);
          }
        }
        this._brake(r, dt);
        return;
      }
    }
    r.grabT = 0;
    if (r.state === 'escape') {
      const e = RAID_DIRS[this.dir || 'north'].spawn;
      if (Math.hypot(e[0] - r.x, e[1] - r.z) < 3) { this._escaped(r); return; }
    }
    if (r.mode === 'hold' || !goal) { this._brake(r, dt); return; }
    this._follow(r, goal, dt);
  }

  _roam(r) {
    const foe = this._nearestPlayer(r, 200);
    const hx = foe ? foe.pos[0] : HALL.x, hz = foe ? foe.pos[2] : HALL.z + 8;
    r.target = { kind: 'roam', key: null, x: hx, y: 0, z: hz };
  }

  _brake(r, dt) {
    const k = Math.exp(-10 * dt);
    r.vx *= k; r.vz *= k;
    this._integrate(r, dt);
  }

  _plan(r, goal) {
    r.path = this.nav.findPath(r.x, r.z, goal[0], goal[1], { breach: !!r.def.breach });
    r.pi = 0;
    r.goal = goal;
    r.navVer = this.nav.version;
    r.repath = 5 + this.rand() * 2;
  }

  _follow(r, goal, dt) {
    const nav = this.nav;
    nav.ensure();
    r.repath -= dt;
    const moved = !r.goal || Math.hypot(goal[0] - r.goal[0], goal[1] - r.goal[1]) > 2.5;
    if (!r.path || moved || r.repath <= 0 || (r.navVer !== nav.version && r.repath < 4.5)) this._plan(r, goal);
    const P = r.path;
    let tx = goal[0], tz = goal[1];
    if (P && P.length > 1) {
      // where am I on the path?
      const cur = nav.index(r.x, r.z);
      for (let k = Math.min(P.length - 1, r.pi + 14); k >= r.pi; k--) if (P[k] === cur) { r.pi = k; break; }
      // barrier ahead?
      const next = P[r.pi + 1];
      if (next !== undefined && nav.kind[next] !== FREE) {
        const cx = nav.cx(P[r.pi]), cz = nav.cz(P[r.pi]);
        if (Math.hypot(cx - r.x, cz - r.z) < 0.75 || nav.kind[cur] !== FREE) { this._startCrossing(r, P, r.pi + 1); return; }
        tx = cx; tz = cz;
      } else {
        // steer for the furthest path cell we can walk to in a straight line
        let aim = Math.min(P.length - 1, r.pi + 1);
        for (let k = r.pi + 1; k < Math.min(P.length, r.pi + 12); k++) {
          if (nav.kind[P[k]] !== FREE) break;
          if (nav.lineClear(r.x, r.z, nav.cx(P[k]), nav.cz(P[k]))) aim = k; else break;
        }
        if (aim >= P.length - 1 && Math.hypot(goal[0] - nav.cx(P[aim]), goal[1] - nav.cz(P[aim])) < 1.6) { tx = goal[0]; tz = goal[1]; }
        else { tx = nav.cx(P[aim]); tz = nav.cz(P[aim]); }
      }
    }
    const dx = tx - r.x, dz = tz - r.z;
    const d = Math.hypot(dx, dz);
    let wx = d > 0.05 ? dx / d : 0, wz = d > 0.05 ? dz / d : 0;
    // keep a little apart from each other
    for (const o of this.raiders.values()) {
      if (o === r || !o.alive || o.kind === 'drone') continue;
      const ox = r.x - o.x, oz = r.z - o.z, od = Math.hypot(ox, oz);
      if (od < 0.9 && od > 1e-3) { wx += (ox / od) * (0.9 - od) * 1.5; wz += (oz / od) * (0.9 - od) * 1.5; }
    }
    const wl = Math.hypot(wx, wz) || 1;
    const speed = r.def.speed * (r.carry.length ? 0.8 : 1) * (r.foe && r.def.hunts ? 0.85 : 1) * Math.min(1, d / 0.6 + 0.3);
    const k = 1 - Math.exp(-10 * dt);
    r.vx += ((wx / wl) * speed - r.vx) * k;
    r.vz += ((wz / wl) * speed - r.vz) * k;
    this._integrate(r, dt);
    // stuck?
    r.stuckT += dt;
    if (r.stuckT > 1.5) {
      const m = Math.hypot(r.x - r.stuckX, r.z - r.stuckZ);
      if (m < 0.4) {
        r.stuckN++;
        r.path = null;
        if (r.stuckN >= 3) {
          const c = nav.nearestFree(r.x + (this.rand() - 0.5) * 2, r.z + (this.rand() - 0.5) * 2, 4);
          if (c >= 0) { r.x = nav.cx(c); r.z = nav.cz(c); }
          r.stuckN = 0;
        }
      } else r.stuckN = 0;
      r.stuckT = 0; r.stuckX = r.x; r.stuckZ = r.z;
    }
  }

  /** Walk / collide / stick to the ground. */
  _integrate(r, dt) {
    r.x += r.vx * dt;
    r.z += r.vz * dt;
    const R = 0.3;
    for (const c of this.world.query(r.x - R, r.z - R, r.x + R, r.z + R, MASK.WALKERS, scratch)) {
      if (c.max[1] <= r.y + 0.55 || c.min[1] >= r.y + 1.7) continue;
      const px1 = r.x + R - c.min[0], px2 = c.max[0] - (r.x - R);
      const pz1 = r.z + R - c.min[2], pz2 = c.max[2] - (r.z - R);
      const pen = Math.min(px1, px2, pz1, pz2);
      if (pen <= 0) continue;
      if (pen === px1) r.x -= px1; else if (pen === px2) r.x += px2; else if (pen === pz1) r.z -= pz1; else r.z += pz2;
    }
    pushFromVehicles(r, this.sim);
    r.y = this.world.groundHeight(r.x, r.z, 0.2, r.y + 0.6, scratch);
    const sp = Math.hypot(r.vx, r.vz);
    if (!r.foe && sp > 0.4) r.yaw = approachAng(r.yaw, Math.atan2(-r.vx, -r.vz), dt * 8);
  }

  // ------------------------------------------------------------------ barriers
  _startCrossing(r, P, j) {
    const nav = this.nav;
    const k0 = nav.kind[P[j]];
    if (k0 === GATE) {
      const gate = nav.gate[P[j]];
      if (!r.def.breach || !gate) { r.path = null; return; }
      r.breach = { t: 0, gate, x: nav.cx(P[j]), z: nav.cz(P[j]) };
      r.vx = r.vz = 0;
      r.yaw = Math.atan2(-(r.breach.x - r.x), -(r.breach.z - r.z));
      this.emit({ type: 'gateBreach', id: r.id, gate });
      return;
    }
    let e = j, top = 0, fence = false;
    while (e < P.length && nav.kind[P[e]] !== FREE) {
      top = Math.max(top, nav.top[P[e]]);
      if (nav.kind[P[e]] === FENCE) fence = true;
      e++;
    }
    if (e >= P.length) { r.path = null; return; }
    const tx = nav.cx(P[e]), tz = nav.cz(P[e]);
    const dur = r.def.climb * (fence ? 1.5 : 1) * (r.carry.length ? 1.25 : 1);
    r.climb = { t: 0, dur, x0: r.x, z0: r.z, y0: r.y, x1: tx, z1: tz, top: Math.max(top, r.y + 1) };
    r.yaw = Math.atan2(-(tx - r.x), -(tz - r.z));
    r.vx = r.vz = 0;
    r.pi = e;
    this.emit({ type: 'raiderClimb', id: r.id, fence, dur: r2(dur) });
  }

  _stepClimb(r, dt) {
    const c = r.climb;
    c.t += dt;
    const u = Math.min(1, c.t / c.dur);
    // up the near side (40 %), over (20 %), down the far side (40 %)
    const h = u < 0.4 ? u / 0.4 : u < 0.6 ? 1 : 1 - (u - 0.6) / 0.4;
    const along = u < 0.4 ? u * 0.25 : u < 0.6 ? 0.1 + (u - 0.4) * 4 : 0.9 + (u - 0.6) * 0.25;
    r.x = c.x0 + (c.x1 - c.x0) * Math.min(1, along);
    r.z = c.z0 + (c.z1 - c.z0) * Math.min(1, along);
    const g = this.world.heightAt(r.x, r.z);
    r.y = g + (c.top + 0.05 - g) * Math.sin(h * Math.PI / 2);
    if (u >= 1) {
      r.climb = null;
      r.x = c.x1; r.z = c.z1;
      r.y = this.world.groundHeight(r.x, r.z, 0.2, r.y + 0.6, scratch);
    }
  }

  _stepBreach(r, dt) {
    const b = r.breach;
    b.t += dt;
    if (b.t >= r.def.breach) {
      r.breach = null;
      this.breachGate(b.gate);
    }
  }

  /** A merc's charge blows a security gate open until the raid ends. */
  breachGate(id) {
    const m = this.sim.machines.get(id);
    if (!m || !m.leaf || this.breached.has(id)) return;
    this.breached.add(id);
    m.leaf.mask = 0;
    m.breached = true;
    this.nav.markDirty(m.fp.x0, m.fp.z0, m.fp.x1, m.fp.z1);
    this.emit({ type: 'gateBreached', gate: id, x: m.x, z: m.z });
  }

  _repairGates() {
    for (const id of this.breached) {
      const m = this.sim.machines.get(id);
      if (!m || !m.leaf) continue;
      m.leaf.mask = MASK.RAIDER;
      m.breached = false;
      this.nav.markDirty(m.fp.x0, m.fp.z0, m.fp.x1, m.fp.z1);
      this.emit({ type: 'gateRepaired', gate: id });
    }
    this.breached.clear();
  }

  // ------------------------------------------------------------------ combat
  _nearestPlayer(r, range) {
    let best = null, bd = range;
    for (const p of this.online()) {
      if (p.down) continue;
      const d = Math.hypot(p.pos[0] - r.x, p.pos[2] - r.z);
      if (d < bd) { bd = d; best = p; }
    }
    return best;
  }

  _canSee(ox, oy, oz, p) {
    const s = 1 - 0.33 * (p.crouch || 0);
    for (const hy of [1.55 * s, 1.1 * s]) {
      const tx = p.pos[0] - ox, ty = p.pos[1] + hy - oy, tz = p.pos[2] - oz;
      const d = Math.hypot(tx, ty, tz);
      if (d < 0.01) return hy;
      const hit = this.world.raycast(ox, oy, oz, tx / d, ty / d, tz / d, d - 0.2, MASK.BULLET);
      if (!hit) return hy;
    }
    return 0;
  }

  _sense(r) {
    const W = r.def.weapon;
    if (!W || r.climb || r.breach || (r.carry.length && r.kind === 'scav')) { r.foe = null; return; }
    let best = null, bd = W.range, aimY = 0;
    const ox = r.x, oy = r.y + EYE, oz = r.z;
    const fx = -Math.sin(r.yaw), fz = -Math.cos(r.yaw);
    for (const p of this.online()) {
      if (p.down) continue;
      const dx = p.pos[0] - ox, dz = p.pos[2] - oz;
      const d = Math.hypot(dx, dz);
      if (d > bd) continue;
      // notice players in front of them, close by, or once they've been shot at
      const facing = (dx * fx + dz * fz) / (d || 1);
      if (d > 12 && facing < 0.2 && r.aware <= 0 && r.foe !== p.id) continue;
      const y = this._canSee(ox, oy, oz, p);
      if (!y) continue;
      best = p; bd = d; aimY = y;
    }
    r.aware -= 0.25;
    const id = best ? best.id : null;
    if (id !== r.foe) { r.foe = id; r.seeT = 0; }
    r.aimY = aimY;
    if (best && r.state === 'enter' && r.def.hunts) r.mode = 'move';
  }

  _aimAndFire(r, dt) {
    const W = r.def.weapon;
    if (!W) return;
    const f = r.foe ? this.sim.players.get(r.foe) : null;
    if (!f || f.down) { r.foe = null; r.mode = 'move'; r.pitch *= Math.exp(-4 * dt); return; }
    const ox = r.x, oy = r.y + EYE, oz = r.z;
    const tx = f.pos[0] - ox, ty = f.pos[1] + (r.aimY || 1.1) - oy, tz = f.pos[2] - oz;
    r.yaw = approachAng(r.yaw, Math.atan2(-tx, -tz), dt * 7);
    r.pitch += (Math.atan2(ty, Math.hypot(tx, tz)) - r.pitch) * Math.min(1, dt * 8);
    r.seeT += dt;
    // scavengers stand to shoot a burst, then move on a bit; mercs hold once they're close
    r.modeT -= dt;
    if (r.def.hunts) r.mode = Math.hypot(tx, tz) < 11 || r.carry.length ? (r.carry.length ? 'move' : 'hold') : 'move';
    else if (r.modeT <= 0) {
      r.mode = r.mode === 'hold' ? 'move' : 'hold';
      r.modeT = r.mode === 'hold' ? 2.5 + this.rand() * 2 : 1.2 + this.rand() * 1.6;
    }
    if (r.seeT < W.react || Math.abs(angDiff(Math.atan2(-tx, -tz), r.yaw)) > 0.35) return;
    r.fireT -= dt;
    if (r.fireT > 0) return;
    this._raiderShot(r, f);
    r.burstLeft--;
    if (r.burstLeft <= 0) { r.burstLeft = W.burst; r.fireT = W.pause * (0.8 + this.rand() * 0.4); }
    else r.fireT = W.interval * (0.85 + this.rand() * 0.3);
  }

  _raiderShot(r, target) {
    const W = r.def.weapon;
    const ox = r.x, oy = r.y + EYE, oz = r.z;
    const s = 1 - 0.33 * (target.crouch || 0);
    const aimY = r.aimY || 1.1 * s;
    let dx = target.pos[0] - ox, dy = target.pos[1] + aimY - oy, dz = target.pos[2] - oz;
    const L = Math.hypot(dx, dy, dz) || 1;
    dx /= L; dy /= L; dz /= L;
    // aim error: roughly gaussian, worse on the move
    const moving = Math.hypot(r.vx, r.vz) > 0.8;
    const sig = W.sigma * (moving ? 1.5 : 1) * (r.seeT < W.react + 0.6 ? 1.3 : 1);
    const g = () => (this.rand() + this.rand() + this.rand() - 1.5) * 1.4;
    const ey = g() * sig, ep = g() * sig;
    // perturb in the shot's own frame
    const yaw = Math.atan2(-dx, -dz) + ey, pitch = Math.asin(Math.max(-1, Math.min(1, dy))) + ep;
    dx = -Math.sin(yaw) * Math.cos(pitch); dy = Math.sin(pitch); dz = -Math.cos(yaw) * Math.cos(pitch);
    const range = W.range + 10;
    const hw = this.world.raycast(ox, oy, oz, dx, dy, dz, range, MASK.BULLET);
    let tMax = hw ? hw.t : range;
    let hit = null, part = null;
    for (const p of this.online()) {
      if (p.down) continue;
      const h = rayVsCharacter(ox, oy, oz, dx, dy, dz, p.pos[0], p.pos[1], p.pos[2], p.crouch || 0, tMax);
      if (h && h.t < tMax) { tMax = h.t; hit = p; part = h.part; }
    }
    const end = [r2(ox + dx * tMax), r2(oy + dy * tMax), r2(oz + dz * tMax)];
    const dmg = hit ? (part === 'head' ? W.head : W.body) : 0;
    this.emit({
      type: 'raiderFire', id: r.id, o: [r2(ox), r2(oy), r2(oz)], p: end,
      s: hit ? 'flesh' : hw ? hw.surface : null, n: !hit && hw ? hw.normal : null, hit: hit ? hit.id : null, head: part === 'head' ? 1 : 0,
    });
    if (hit) this.damagePlayer(hit, dmg, r);
  }

  /** A player's shot (command from their client). Checked against rewound raiders. */
  playerShot(p, o, d, lag = 0) {
    if (p.down) return { ok: false, error: 'Downed' };
    if (this.time - (p.lastShot ?? -9) < 0.09) return { ok: false, error: 'Too fast' };
    p.lastShot = this.time;
    if (!Array.isArray(o) || !Array.isArray(d) || o.length < 3 || d.length < 3) return { ok: false, error: 'Bad shot' };
    const [ox, oy, oz] = o.map(Number);
    let [dx, dy, dz] = d.map(Number);
    if (![ox, oy, oz, dx, dy, dz].every(Number.isFinite)) return { ok: false, error: 'Bad shot' };
    // must come from (about) the shooter's own eyes
    if (Math.hypot(ox - p.pos[0], oy - (p.pos[1] + 1.4), oz - p.pos[2]) > 1.8) return { ok: false, error: 'Bad origin' };
    const L = Math.hypot(dx, dy, dz);
    if (L < 1e-6) return { ok: false, error: 'Bad shot' };
    dx /= L; dy /= L; dz /= L;
    const t = this.time - Math.max(0, Math.min(0.35, Number(lag) || 0));
    const def = WEAPONS.p9;
    const hw = this.world.raycast(ox, oy, oz, dx, dy, dz, def.range, MASK.BULLET);
    let tMax = hw ? hw.t : def.range, best = null, part = null;
    for (const r of this.raiders.values()) {
      if (!r.alive) continue;
      const [x, y, z] = this.rewind(r, t);
      if (r.kind === 'drone') {
        const h = raySphere(ox, oy, oz, dx, dy, dz, x, y, z, r.def.radius, tMax);
        if (h !== null) { tMax = h; best = r; part = 'body'; }
      } else {
        const h = rayVsCharacter(ox, oy, oz, dx, dy, dz, x, y, z, 0, tMax);
        if (h && h.t < tMax) { tMax = h.t; best = r; part = h.part; }
      }
    }
    if (!best) return { ok: true, hit: null };
    const D = def.damage;
    const f = tMax <= D.falloffStart ? 1 : tMax >= D.falloffEnd ? D.falloffMin : 1 - (1 - D.falloffMin) * ((tMax - D.falloffStart) / (D.falloffEnd - D.falloffStart));
    const dmg = Math.round((part === 'head' ? D.head : D.body) * f);
    const res = this.damageRaider(best, dmg, part, p.id, [dx, dz]);
    return { ok: true, hit: best.id, part, dmg: res.dmg, killed: res.killed, t: r2(tMax) };
  }

  damageRaider(r, raw, part, by, dir = [0, 0]) {
    if (!r.alive) return { dmg: 0, killed: false };
    const dmg = Math.max(1, Math.round(raw * (r.def.armor[part] ?? 1)));
    r.hp -= dmg;
    r.aware = 4; // they know where it came from now
    if (!r.foe && typeof by === 'string' && this.sim.players.has(by)) { r.foe = by; r.seeT = r.def.weapon ? r.def.weapon.react * 0.5 : 0; }
    this.emit({ type: 'raiderHit', id: r.id, hp: Math.max(0, r.hp), dmg, part, by, dir: [r2(dir[0]), r2(dir[1])] });
    if (r.hp > 0) return { dmg, killed: false };
    r.alive = false;
    r.hp = 0;
    r.climb = null;
    r.breach = null;
    r.deadT = 0;
    const bounty = r.def.bounty;
    const pl = typeof by === 'string' ? this.sim.players.get(by) : null;
    if (pl) {
      pl.wallet += bounty;
      this.emit({ type: 'wallet', player: pl.id, wallet: pl.wallet, delta: bounty });
    } else {
      this.sim.funds += bounty;
      this.emit({ type: 'funds', funds: this.sim.funds, delta: bounty });
    }
    this.stats.killed++;
    if (this.cur) { this.cur.killed++; this.cur.bounty += bounty; }
    if (r.kind === 'drone') { r.vy = 0; } else this._dropLoot(r);
    this.emit({ type: 'raiderDown', id: r.id, kind: r.kind, by, part, bounty, x: r2(r.x), y: r2(r.y), z: r2(r.z) });
    return { dmg, killed: true };
  }

  // ------------------------------------------------------------------ drones
  _drone(r, dt) {
    const def = r.def;
    const cruise = def.cruise;
    let tx = r.x, tz = r.z, ty = r.y;
    const ground = this.world.heightAt(r.x, r.z);
    const high = Math.max(ground + cruise, 10.2);
    if (r.state === 'fly' || r.state === 'descend' || r.state === 'grab') {
      if (!this._targetValid(r)) {
        r.target = this._pickTarget(r);
        if (!r.target) { r.roamT += dt; if (r.roamT > 20) r.state = 'flee'; }
        else if (r.state !== 'fly') r.state = 'fly';
      }
    }
    switch (r.state) {
      case 'fly': {
        if (!r.target) { tx = HALL.x + Math.cos(this.time * 0.3 + r.id) * 20; tz = HALL.z + 20 + Math.sin(this.time * 0.3 + r.id) * 14; ty = high; break; }
        tx = r.target.x; tz = r.target.z; ty = high;
        if (Math.hypot(tx - r.x, tz - r.z) < 1.2) r.state = 'descend';
        break;
      }
      case 'descend':
        tx = r.target.x; tz = r.target.z; ty = r.target.y + 1.3;
        if (r.y - ty < 0.25) { r.state = 'grab'; r.grabT = 0; }
        break;
      case 'grab':
        tx = r.target.x; tz = r.target.z; ty = r.target.y + 1.3;
        r.grabT += dt;
        if (r.grabT >= def.grab) { this._grab(r); r.state = r.carry.length ? 'ascend' : 'fly'; }
        break;
      case 'ascend':
        ty = high + 1;
        if (r.y >= high) r.state = 'flee';
        break;
      case 'flee':
      case 'escape': {
        const e = RAID_DIRS[this.dir || 'north'].spawn;
        tx = e[0]; tz = e[1]; ty = high + 2;
        if (Math.hypot(e[0] - r.x, e[1] - r.z) < 4) { this._escaped(r); return; }
        break;
      }
    }
    // fly: horizontal steering + tall-obstacle avoidance, vertical separately
    let dx = tx - r.x, dz = tz - r.z;
    const d = Math.hypot(dx, dz);
    const vertical = r.state === 'descend' || r.state === 'grab' || r.state === 'ascend';
    const sp = vertical ? 1.5 : def.speed * (r.carry.length ? 0.72 : 1) * Math.min(1, d / 3 + 0.2);
    let wx = d > 0.05 ? (dx / d) * sp : 0, wz = d > 0.05 ? (dz / d) * sp : 0;
    for (const c of this.world.query(r.x - 3, r.z - 3, r.x + 3, r.z + 3, MASK.BULLET, scratch)) {
      if (c.max[1] < r.y - 0.5 || c.min[1] > r.y + 0.5) continue;
      const cx = Math.max(c.min[0], Math.min(r.x, c.max[0])), cz = Math.max(c.min[2], Math.min(r.z, c.max[2]));
      const ox = r.x - cx, oz = r.z - cz, od = Math.hypot(ox, oz);
      if (od < 3 && od > 1e-3) { wx += (ox / od) * (3 - od) * 2; wz += (oz / od) * (3 - od) * 2; }
    }
    const k = 1 - Math.exp(-3 * dt);
    r.vx += (wx - r.vx) * k; r.vz += (wz - r.vz) * k;
    const vy = Math.max(-3, Math.min(3, (ty - r.y) * 2));
    r.vy += (vy - r.vy) * (1 - Math.exp(-4 * dt));
    r.x += r.vx * dt; r.z += r.vz * dt; r.y += r.vy * dt;
    r.y = Math.max(r.y, ground + 0.6);
    const hs = Math.hypot(r.vx, r.vz);
    if (hs > 0.3) r.yaw = approachAng(r.yaw, Math.atan2(-r.vx, -r.vz), dt * 3);
    r.pitch = Math.min(0.35, hs * 0.05);
  }

  // =================================================================== players
  damagePlayer(p, dmg, src) {
    if (p.down || !(dmg > 0)) return;
    p.hp = Math.max(0, (p.hp ?? HEALTH.max) - dmg);
    p.lastHit = this.time;
    this.emit({ type: 'playerHit', player: p.id, hp: p.hp, dmg, from: src ? [r2(src.x), r2(src.z)] : null });
    if (p.hp <= 0) {
      p.down = true;
      p.downT = 0;
      p.reviver = null;
      p.reviveT = 0;
      this.emit({ type: 'playerDown', player: p.id });
    }
  }

  _players(dt) {
    for (const p of this.sim.players.values()) {
      if (p.hp === undefined) p.hp = HEALTH.max;
      if (!p.down) {
        if (p.hp < HEALTH.max && this.time - (p.lastHit ?? -99) > HEALTH.regenDelay) p.hp = Math.min(HEALTH.max, p.hp + HEALTH.regenRate * dt);
        continue;
      }
      // downed: a partner holding E brings you back, otherwise you respawn at the terminal
      const rv = p.reviver ? this.sim.players.get(p.reviver) : null;
      if (rv && !rv.down && rv.online !== false && Math.hypot(rv.pos[0] - p.pos[0], rv.pos[2] - p.pos[2]) <= HEALTH.reviveReach + 0.4) {
        p.reviveT += dt;
        if (p.reviveT >= HEALTH.reviveTime) {
          p.down = false;
          p.hp = HEALTH.reviveHp;
          p.lastHit = this.time;
          p.reviver = null;
          p.reviveT = 0;
          this.emit({ type: 'playerRevived', player: p.id, by: rv.id });
        }
        continue;
      }
      if (p.reviver) { p.reviver = null; p.reviveT = 0; }
      p.downT += dt;
      if (p.downT >= HEALTH.bleedout) this.respawn(p);
    }
  }

  respawn(p) {
    const R = FACTORY.respawn;
    p.down = false;
    p.hp = HEALTH.max;
    p.reviver = null;
    p.reviveT = 0;
    p.downT = 0;
    p.lastHit = -99;
    p.pos = [R.x, 0, R.z];
    this.emit({ type: 'respawn', player: p.id, x: R.x, y: 0, z: R.z, yaw: R.yaw });
  }

  revive(p, targetId, on = true) {
    if (!on) {
      for (const o of this.sim.players.values()) if (o.reviver === p.id) { o.reviver = null; o.reviveT = 0; }
      return { ok: true };
    }
    const t = this.sim.players.get(targetId);
    if (!t || !t.down) return { ok: false, error: 'Nobody to revive' };
    if (p.down) return { ok: false, error: "You're down yourself" };
    if (Math.hypot(t.pos[0] - p.pos[0], t.pos[2] - p.pos[2]) > HEALTH.reviveReach + 0.4) return { ok: false, error: 'Get closer' };
    if (t.reviver !== p.id) { t.reviver = p.id; t.reviveT = 0; }
    this.emit({ type: 'reviveStart', player: t.id, by: p.id });
    return { ok: true };
  }

  // =================================================================== turrets
  _turrets(dt) {
    for (const m of this.sim.machines.values()) {
      if (m.def.defence !== 'turret') continue;
      if (m.tYaw === undefined) this.initTurret(m);
      const hx = m.x, hy = TURRET.headY, hz = m.z;
      m.scanT -= dt;
      if (m.scanT <= 0) {
        m.scanT = TURRET.scan;
        m.target = this._turretTarget(m, hx, hy, hz);
      }
      const r = m.target ? this.raiders.get(m.target) : null;
      if (!r || !r.alive) { m.target = null; m.firing = false; continue; }
      const ty = r.kind === 'drone' ? r.y : r.y + 1.1;
      const dx = r.x - hx, dy = ty - hy, dz = r.z - hz;
      const wantYaw = Math.atan2(-dx, -dz), wantPitch = Math.atan2(dy, Math.hypot(dx, dz));
      m.tYaw = approachAng(m.tYaw, wantYaw, TURRET.turnRate * dt);
      m.tPitch += Math.max(-TURRET.pitchRate * dt, Math.min(TURRET.pitchRate * dt, wantPitch - m.tPitch));
      const aligned = Math.abs(angDiff(wantYaw, m.tYaw)) < 0.07 && Math.abs(wantPitch - m.tPitch) < 0.09;
      m.fireT -= dt;
      m.firing = aligned && m.ammo > 0;
      if (!m.firing || m.fireT > 0) continue;
      m.fireT = TURRET.interval;
      this._turretShot(m, hx, hy, hz);
    }
  }

  initTurret(m) {
    m.tYaw = Math.PI + (m.q & 3) * (Math.PI / 2); // facing away from its feed port (local +Z)
    m.tPitch = 0;
    m.ammo = m.ammo || 0;
    m.scanT = 0;
    m.fireT = 0;
    m.target = null;
    m.kills = m.kills || 0;
  }

  _turretTarget(m, hx, hy, hz) {
    const cands = [];
    for (const r of this.raiders.values()) {
      if (!r.alive) continue;
      const ty = r.kind === 'drone' ? r.y : r.y + 1.1;
      const d = Math.hypot(r.x - hx, ty - hy, r.z - hz);
      if (d > TURRET.range) continue;
      cands.push({ r, d, s: d - (r.carry.length ? 6 : 0) - (r.kind === 'drone' ? 4 : 0) - (r.id === m.target ? 3 : 0), ty });
    }
    cands.sort((a, b) => a.s - b.s);
    for (const c of cands.slice(0, 3)) {
      const dx = c.r.x - hx, dy = c.ty - hy, dz = c.r.z - hz;
      const hit = this.world.raycast(hx, hy, hz, dx / c.d, dy / c.d, dz / c.d, c.d - 0.3, MASK.BULLET);
      if (!hit) return c.r.id;
    }
    return null;
  }

  _turretShot(m, hx, hy, hz) {
    m.ammo--;
    const cp = Math.cos(m.tPitch);
    let dx = -Math.sin(m.tYaw) * cp, dy = Math.sin(m.tPitch), dz = -Math.cos(m.tYaw) * cp;
    const g = () => (this.rand() + this.rand() - 1) * TURRET.spread;
    const yaw = m.tYaw + g(), pitch = m.tPitch + g();
    dx = -Math.sin(yaw) * Math.cos(pitch); dy = Math.sin(pitch); dz = -Math.cos(yaw) * Math.cos(pitch);
    const ox = hx + dx * 0.55, oy = hy + dy * 0.55, oz = hz + dz * 0.55;
    const hw = this.world.raycast(ox, oy, oz, dx, dy, dz, TURRET.range + 8, MASK.BULLET);
    let tMax = hw ? hw.t : TURRET.range + 8, best = null, part = null;
    for (const r of this.raiders.values()) {
      if (!r.alive) continue;
      if (r.kind === 'drone') {
        const h = raySphere(ox, oy, oz, dx, dy, dz, r.x, r.y, r.z, r.def.radius, tMax);
        if (h !== null) { tMax = h; best = r; part = 'body'; }
      } else {
        const h = rayVsCharacter(ox, oy, oz, dx, dy, dz, r.x, r.y, r.z, 0, tMax);
        if (h && h.t < tMax) { tMax = h.t; best = r; part = h.part; }
      }
    }
    this.emit({
      type: 'turretFire', id: m.id, p: [r2(ox + dx * tMax), r2(oy + dy * tMax), r2(oz + dz * tMax)],
      s: best ? (best.kind === 'drone' ? 'metal' : 'flesh') : hw ? hw.surface : null, n: !best && hw ? hw.normal : null, hit: best ? best.id : null,
    });
    if (best) {
      const res = this.damageRaider(best, part === 'head' ? TURRET.damage.head : TURRET.damage.body, part, `turret:${m.id}`, [dx, dz]);
      if (res.killed) m.kills = (m.kills || 0) + 1;
    }
    if (m.ammo <= 0) this.emit({ type: 'turretEmpty', id: m.id });
  }

  // =================================================================== save / reset
  /** Stacks raiders are carrying right now (saved back into the cage). */
  carried() {
    const out = [];
    for (const r of this.raiders.values()) for (const s of r.carry) out.push({ ...s });
    return out;
  }

  serialize() {
    const midRaid = this.phase === 'warning' || this.phase === 'active';
    return {
      phase: this.phase === 'off' ? 'off' : 'calm',
      timer: Math.round(midRaid ? RAID.resumeDelay : this.timer),
      no: this.no, lastDir: this.lastDir, stats: { ...this.stats },
    };
  }

  load(d) {
    this.clear();
    if (!d || typeof d !== 'object') return;
    this.phase = d.phase === 'calm' ? 'calm' : 'off';
    this.timer = Math.max(RAID.warning + 20, Math.min(RAID.cooldown[1], Number(d.timer) || RAID.resumeDelay));
    this.no = Math.max(0, d.no | 0);
    this.lastDir = DIR_KEYS.includes(d.lastDir) ? d.lastDir : null;
    Object.assign(this.stats, d.stats || {});
  }

  /** Remove every raider (no loot dropped) and reset the director. */
  clear() {
    for (const id of this.raiders.keys()) this.emit({ type: 'raiderGone', id });
    this.raiders.clear();
    this._repairGates();
    this.phase = 'off';
    this.timer = 0;
    this.queue = [];
    this.cur = null;
    this.plan = null;
    this.dir = null;
    this.no = 0;
    this.stats = { raids: 0, repelled: 0, killed: 0, escaped: 0, stolenValue: 0, recoveredValue: 0 };
    for (const p of this.sim.players.values()) { p.hp = HEALTH.max; p.down = false; p.reviver = null; p.reviveT = 0; }
  }

  /** For the HUD (solo reads it directly; online it comes in the slow state). */
  status() {
    return {
      phase: this.phase, timer: Math.max(0, this.timer), dir: this.dir, no: this.no,
      plan: this.plan ? { count: this.plan.units.length, kinds: this.plan.kinds, size: this.plan.size } : null,
      cur: this.cur ? { killed: this.cur.killed, escaped: this.cur.escaped, stolen: this.cur.stolenValue, count: this.cur.count, left: this.queue.length + [...this.raiders.values()].filter((r) => r.alive).length } : null,
      stats: this.stats,
    };
  }

  /** Debug / test hook: skip the calm so a raid starts in `sec` seconds. */
  forceRaid(sec = RAID.warning) {
    if (this.phase === 'active') return;
    if (this.phase === 'off') this.phase = 'calm';
    this.timer = sec;
    if (sec <= RAID.warning && this.phase !== 'warning') this._warn();
  }

  // Flags for the wire / renderer: climbing 1 · carrying 2 · dead 4 · aiming 8 · breaching 16
  flags(r) {
    return (r.climb ? 1 : 0) | (r.carry.length ? 2 : 0) | (r.alive ? 0 : 4) | (r.foe ? 8 : 0) | (r.breach ? 16 : 0);
  }
}

export { HEALTH, TURRET, RAID, PLAYER };
