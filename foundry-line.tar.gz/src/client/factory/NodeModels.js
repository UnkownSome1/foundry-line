// Belt routing pieces (splitter / item filter / merger) and the receiving dock.
// Nodes are 1 m tiles in their own frame: items flow toward local +Z, "left" is local +X.
import * as THREE from 'three';
import { materials } from '../gfx/materials.js';
import { chamferBox, cyl } from '../gfx/geometry.js';
import * as T from '../gfx/textures.js';
import { CONVEYOR, ITEMS } from '../../shared/factory/items.js';

const BOX = (w, h, d) => new THREE.BoxGeometry(w, h, d);
const top = CONVEYOR.top;
let NM = null;
function mats() {
  if (NM) return NM;
  const std = (color, o = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.6, ...o });
  NM = {
    frame: std(0x3a3f44, { metalness: 0.6, roughness: 0.5 }),
    deck: std(0x26282a, { roughness: 0.85 }),
    orange: std(0xe8731c, { roughness: 0.5, flatShading: true }),
    teal: std(0x1f8a8a, { roughness: 0.5, flatShading: true }),
    purple: std(0x6a4bb0, { roughness: 0.5, flatShading: true }),
    arrow: new THREE.MeshBasicMaterial({ color: 0xf2b01e }),
    arrowDim: new THREE.MeshBasicMaterial({ color: 0x8a6a1a }),
    scan: new THREE.MeshStandardMaterial({ color: 0x0c2a3a, emissive: 0x2fb5ff, emissiveIntensity: 1.4 }),
    glass: new THREE.MeshStandardMaterial({ color: 0xcfe6ee, roughness: 0.05, transparent: true, opacity: 0.3, depthWrite: false }),
  };
  return NM;
}

function add(parent, geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, cast = true) {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  m.castShadow = cast;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

const ARROW = (() => {
  const s = new THREE.Shape([new THREE.Vector2(-0.07, -0.12), new THREE.Vector2(0.07, -0.12), new THREE.Vector2(0.07, 0.02), new THREE.Vector2(0.14, 0.02), new THREE.Vector2(0, 0.16), new THREE.Vector2(-0.14, 0.02), new THREE.Vector2(-0.07, 0.02)]);
  return new THREE.ShapeGeometry(s).rotateX(-Math.PI / 2);
})();

/** Flat arrow on the deck pointing along local direction (dx, dz). */
function arrow(parent, dx, dz, dist, mat) {
  const a = add(parent, ARROW, mat, dx * dist, top + 0.012, dz * dist, 0, 0, 0, false);
  a.rotation.y = Math.atan2(dx, dz) + Math.PI; // the shape points −Z after rotateX
  return a;
}

function base(g, ring) {
  const M = mats();
  add(g, BOX(0.96, 0.05, 0.96), M.deck, 0, top - 0.02, 0);
  add(g, BOX(0.96, top - 0.05, 0.96), M.frame, 0, (top - 0.05) / 2, 0);
  // coloured collar so each piece reads at a glance
  for (const [x, z, w, d] of [[0, -0.47, 0.96, 0.04], [0, 0.47, 0.96, 0.04], [-0.47, 0, 0.04, 0.96], [0.47, 0, 0.04, 0.96]]) add(g, BOX(w, 0.08, d), ring, x, top + 0.02, z);
}

/** Label plate for the item filter (canvas texture you can redraw). */
function filterPlate() {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 96;
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const draw = (item, side) => {
    const x = c.getContext('2d');
    x.fillStyle = '#10181e'; x.fillRect(0, 0, 256, 96);
    x.fillStyle = '#2fb5ff'; x.fillRect(0, 0, 256, 6);
    x.fillStyle = '#ede8df';
    x.font = '700 30px "Barlow Condensed", Impact, sans-serif';
    x.textAlign = 'center';
    x.fillText(item ? ITEMS[item].name.toUpperCase() : 'NO FILTER SET', 128, 44, 240);
    x.font = '500 18px "IBM Plex Mono", monospace';
    x.fillStyle = '#f2b01e';
    x.fillText(item ? `→ ${side === 'right' ? 'RIGHT' : 'LEFT'} · REST STRAIGHT` : 'PRESS E TO SET', 128, 78, 240);
    tex.needsUpdate = true;
  };
  return { tex, draw };
}

/**
 * @param kind 'splitter' | 'sorter' | 'merger'
 * @returns {{root:THREE.Group, setFilter?(item, side):void, anim?(dt, t):void}}
 */
export function buildNode(kind, { ghost = null } = {}) {
  const M = mats();
  const root = new THREE.Group();
  root.name = `node-${kind}`;
  const out = { root };
  if (kind === 'splitter') {
    base(root, M.orange);
    // wedge divider + three outlets
    add(root, chamferBox(0.16, 0.2, 0.34, 0.03), M.orange, 0, top + 0.1, 0.12);
    add(root, BOX(0.5, 0.2, 0.05), M.orange, 0, top + 0.1, -0.12, 0, 0, 0);
    for (const [dx, dz] of [[0, 1], [1, 0], [-1, 0]]) arrow(root, dx, dz, 0.3, M.arrow);
    arrow(root, 0, 1, -0.25, M.arrowDim);
    const hub = add(root, cyl(0.07, 0.07, 0.06, 8), M.frame, 0, top + 0.23, -0.02);
    out.anim = (dt) => { hub.rotation.y += dt * 4; };
  } else if (kind === 'sorter') {
    base(root, M.teal);
    // scanner arch with a light bar
    for (const sx of [-0.44, 0.44]) add(root, BOX(0.06, 0.62, 0.12), M.teal, sx, top + 0.31, -0.2);
    add(root, BOX(0.94, 0.08, 0.14), M.teal, 0, top + 0.64, -0.2);
    const bar = add(root, BOX(0.8, 0.03, 0.04), M.scan, 0, top + 0.59, -0.2, 0, 0, 0, false);
    const plate = filterPlate();
    const pm = new THREE.MeshStandardMaterial({ map: plate.tex, emissive: 0xffffff, emissiveMap: plate.tex, emissiveIntensity: 0.5, roughness: 0.5 });
    add(root, BOX(0.6, 0.22, 0.02), pm, 0, top + 0.82, -0.2);
    add(root, BOX(0.6, 0.22, 0.02), pm, 0, top + 0.82, -0.22, 0, Math.PI, 0);
    add(root, BOX(0.04, 0.12, 0.04), M.teal, 0, top + 0.72, -0.2);
    arrow(root, 0, 1, 0.3, M.arrow);
    const sideArrow = arrow(root, 1, 0, 0.3, M.arrow);
    // a guide flap that swings toward the side matching items leave by
    const flap = new THREE.Group(); flap.position.set(0, top + 0.07, 0.05); root.add(flap);
    add(flap, BOX(0.03, 0.12, 0.34), M.frame, 0, 0, 0.12);
    let side = 'left', flapT = 0;
    out.setFilter = (item, s) => {
      side = s === 'right' ? 'right' : 'left';
      plate.draw(item, side);
      sideArrow.position.x = side === 'right' ? -0.3 : 0.3;
      sideArrow.rotation.y = Math.atan2(side === 'right' ? -1 : 1, 0) + Math.PI;
      sideArrow.visible = !!item;
    };
    out.setFilter(null, 'left');
    out.anim = (dt, t) => {
      bar.material.emissiveIntensity = 1 + Math.sin(t * 6) * 0.5;
      flapT += ((side === 'right' ? -0.5 : 0.5) - flapT) * Math.min(1, dt * 4);
      flap.rotation.y = flapT;
    };
  } else {
    base(root, M.purple);
    // funnel guides from both sides into the front
    for (const s of [-1, 1]) add(root, BOX(0.05, 0.16, 0.42), M.purple, s * 0.3, top + 0.08, 0.2, 0, s * 0.5, 0);
    // out the front (bright); in from the back and both sides (dim, pointing inward)
    for (const [dx, dz, d] of [[0, 1, 0.3], [0, 1, -0.25], [1, 0, -0.3], [-1, 0, -0.3]]) arrow(root, dx, dz, d, d > 0 ? M.arrow : M.arrowDim);
  }
  if (ghost) root.traverse((o) => { if (o.isMesh) { o.material = ghost; o.castShadow = false; o.receiveShadow = false; } });
  return out;
}

/** Receiving dock: unit inside the south wall + hopper outside, bin contents shown as crates. */
export function buildDock(D) {
  const M = materials(), N = mats();
  const std = (color, o = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.6, ...o });
  const g = new THREE.Group();
  const u = D.unit, h = D.hopper;
  // inside unit: steel bin on legs with a roller bed pushing north onto your belt
  const unit = new THREE.Group(); unit.position.set(u.x, 0, u.z); g.add(unit);
  add(unit, chamferBox(u.w, 0.08, u.d, 0.02), M.steelDark, 0, u.h, 0);
  for (const [x, z] of [[-0.92, -0.42], [0.92, -0.42], [-0.92, 0.42], [0.92, 0.42]]) add(unit, BOX(0.08, u.h, 0.08), M.steelDark, x, u.h / 2, z);
  add(unit, BOX(u.w, 0.5, 0.05), M.steelYellow, 0, u.h + 0.25, 0.45);
  for (const sx of [-1, 1]) add(unit, BOX(0.05, 0.5, u.d), M.steelYellow, sx * (u.w / 2 - 0.02), u.h + 0.25, 0);
  add(unit, BOX(u.w, 0.18, 0.05), M.hazard, 0, u.h + 0.1, -0.47);
  // output chute sloping down to belt height at the output cell
  add(unit, BOX(0.8, 0.04, 0.9), M.steelGalv, 0, (u.h + top) / 2 + 0.05, -0.75, -0.62, 0, 0);
  for (const sx of [-0.42, 0.42]) add(unit, BOX(0.04, 0.16, 0.9), M.steelGalv, sx, (u.h + top) / 2 + 0.12, -0.75, -0.62, 0, 0);
  const sign = new THREE.MeshStandardMaterial({ map: T.textPlate([{ text: 'RECEIVING DOCK', size: 42 }, { text: 'TRUCK DELIVERIES → PUT A BELT ON THE ARROW', size: 18, color: '#f2b01e' }], { w: 512, h: 128, bg: '#1d2328', fg: '#ede8df' }), roughness: 0.5 });
  add(g, BOX(2.0, 0.5, 0.04), sign, u.x, 2.3, -4.23, 0, Math.PI, 0);
  // wall chute openings
  add(g, new THREE.PlaneGeometry(1.4, 0.7), N.deck, u.x, 1.45, -4.215, 0, Math.PI, 0, false);
  add(g, new THREE.PlaneGeometry(1.4, 0.7), N.deck, u.x, 1.45, -3.785, 0, 0, 0, false);
  // outside hopper: funnel on a frame
  const hop = new THREE.Group(); hop.position.set(h.x, 0, h.z); g.add(hop);
  add(hop, chamferBox(h.w, h.h - 0.35, h.d, 0.04), M.steelGalv, 0, (h.h - 0.35) / 2, 0);
  for (const [x, z, w, d, rx, rz] of [[-h.w / 2, 0, 0.06, h.d, 0, 0.45], [h.w / 2, 0, 0.06, h.d, 0, -0.45], [0, h.d / 2, h.w, 0.06, 0.45, 0], [0, -h.d / 2 + 0.05, h.w, 0.06, -0.2, 0]]) add(hop, BOX(w, 0.5, d), M.steelYellow, x, h.h - 0.05, z, rx, 0, rz);
  add(hop, BOX(h.w - 0.25, 0.02, h.d - 0.25), N.deck, 0, h.h - 0.34, 0, 0, 0, 0, false);
  add(hop, BOX(h.w + 0.02, 0.12, h.d + 0.02), M.hazard, 0, h.h - 0.4, 0);
  const lab = new THREE.MeshStandardMaterial({ map: T.textPlate([{ text: 'DOCK', size: 70 }, { text: 'RAW MATERIALS IN', size: 24, color: '#f2b01e' }], { w: 256, h: 128, bg: '#1d2328', fg: '#ede8df' }), roughness: 0.5 });
  add(hop, BOX(0.8, 0.4, 0.02), lab, 0, 0.5, h.d / 2 + 0.02);
  // output marker (amber arrow) on the belt cell
  const mk = add(g, ARROW.clone().scale(1.8, 1, 1.8), N.arrow, D.out.x, 0.012, D.out.z + 0.1, 0, Math.atan2(D.out.dx, D.out.dz) + Math.PI, 0, false);
  // bin contents
  const bin = new THREE.Group(); bin.position.set(u.x, u.h + 0.05, u.z); g.add(bin);
  const crate = std(0x7a5f3c, { roughness: 0.85, flatShading: true });
  const crates = [];
  for (let i = 0; i < 8; i++) {
    const c = add(bin, chamferBox(0.36, 0.26, 0.34, 0.03), crate, -0.72 + (i % 4) * 0.48, 0.13 + Math.floor(i / 4) * 0.27, (i % 2 ? 0.08 : -0.08));
    c.visible = false;
    crates.push(c);
  }
  return {
    root: g, marker: mk,
    setCount: (n) => { crates.forEach((c, i) => { c.visible = i < n; }); },
  };
}
