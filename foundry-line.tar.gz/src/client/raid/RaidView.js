// Draws raids: raiders (scavengers / armoured mercs as rigged characters, cargo drones),
// their shots, hits, deaths, climbs and breaches, turret fire, loot sacks, and the siren.
// Fed with interpolated raider states every frame (solo: from the local sim, co-op: from
// server snapshots) plus the raid events the sim emits.
import * as THREE from 'three';
import { Character } from '../models/Character.js';
import { materials } from '../gfx/materials.js';
import { chamferBox, cyl } from '../gfx/geometry.js';
import { HALL } from '../../shared/mapLayout.js';
import { RAIDERS } from '../../shared/raid/raidDefs.js';
import { ITEMS } from '../../shared/factory/items.js';

const V = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const tmp = V(), tmp2 = V();
const RAIDER_RED = 0xc0392b;

// ------------------------------------------------------------------ drone model
class Drone {
  constructor() {
    const M = materials();
    const body = new THREE.MeshStandardMaterial({ color: 0x2d3136, roughness: 0.45, metalness: 0.6, flatShading: true });
    const orange = new THREE.MeshStandardMaterial({ color: 0xd9531e, roughness: 0.5, flatShading: true });
    this.root = new THREE.Group();
    this.tilt = new THREE.Group();
    this.root.add(this.tilt);
    const add = (geo, mat, x, y, z, parent = this.tilt) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m; };
    add(chamferBox(0.46, 0.14, 0.52, 0.04), body, 0, 0, 0);
    add(chamferBox(0.3, 0.06, 0.36, 0.02), orange, 0, 0.09, 0);
    add(cyl(0.05, 0.05, 0.04, 8), M.steelDark, 0, -0.1, -0.2);
    this.led = add(new THREE.SphereGeometry(0.03, 6, 4), new THREE.MeshStandardMaterial({ color: 0x400000, emissive: 0xff2a14, emissiveIntensity: 2 }), 0, 0.02, -0.27);
    this.rotors = [];
    for (let i = 0; i < 4; i++) {
      const a = Math.PI / 4 + i * Math.PI / 2;
      const x = Math.cos(a) * 0.42, z = Math.sin(a) * 0.42;
      const arm = add(new THREE.BoxGeometry(0.44, 0.04, 0.05), body, x / 2, 0.02, z / 2);
      arm.rotation.y = -a;
      add(cyl(0.05, 0.06, 0.09, 8), M.steelDark, x, 0.05, z);
      const rotor = new THREE.Group();
      rotor.position.set(x, 0.11, z);
      this.tilt.add(rotor);
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.008, 0.04), M.steelDark);
      rotor.add(blade);
      const disc = new THREE.Mesh(new THREE.CircleGeometry(0.2, 16).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0x9aa0a6, transparent: true, opacity: 0.18, depthWrite: false }));
      rotor.add(disc);
      this.rotors.push(rotor);
    }
    // claw + cargo
    for (const s of [-1, 1]) add(new THREE.BoxGeometry(0.03, 0.22, 0.03), M.steelGalv, s * 0.1, -0.2, 0).rotation.z = s * 0.25;
    this.cargo = add(chamferBox(0.36, 0.26, 0.3, 0.03), new THREE.MeshStandardMaterial({ color: 0x8a7350, roughness: 0.9 }), 0, -0.38, 0);
    this.cargo.visible = false;
    this.spin = 0;
    this.dead = false;
    this.tumble = V();
  }

  update(dt, s, time) {
    this.root.position.set(s.x, s.y, s.z);
    this.root.rotation.y = s.yaw;
    const sp = Math.hypot(s.vx, s.vz);
    if (s.dead) {
      if (!this.dead) { this.dead = true; this.tumble.set((Math.random() - 0.5) * 8, (Math.random() - 0.5) * 6, (Math.random() - 0.5) * 8); }
      this.tilt.rotation.x += this.tumble.x * dt;
      this.tilt.rotation.z += this.tumble.z * dt;
      this.tumble.multiplyScalar(Math.exp(-dt * 0.6));
      this.led.material.emissiveIntensity = 0;
    } else {
      this.tilt.rotation.x = -Math.min(0.35, sp * 0.05);
      this.tilt.rotation.z = Math.sin(time * 2.3 + s.id) * 0.04;
      this.led.material.emissiveIntensity = Math.sin(time * 9) > 0.2 ? 2.4 : 0.2;
    }
    this.spin += dt * (s.dead ? 6 : 60);
    for (let i = 0; i < 4; i++) this.rotors[i].rotation.y = this.spin * (i % 2 ? 1 : -1);
    this.cargo.visible = !!s.carrying;
  }
}

// ------------------------------------------------------------------ raid view
export class RaidView {
  constructor(game) {
    this.g = game;
    this.views = new Map(); // raider id → {kind, obj, char|drone, dead, deadT, seen}
    this.pool = { scav: [], merc: [] };
    this.predicted = new Map(); // raider id → time we showed our own predicted hit
    this.lastWarnToast = 0;
    this.turretEmptyT = new Map();
  }

  // ---------------------------------------------------------------- raiders
  _make(s) {
    if (s.kind === 'drone') {
      const d = new Drone();
      this.g.scene.add(d.root);
      const snd = this.g.audio.drone();
      return { kind: 'drone', obj: d.root, drone: d, snd };
    }
    const style = s.kind === 'merc' ? 'merc' : 'scav';
    let char = this.pool[style].pop();
    if (!char) {
      char = new Character({ name: RAIDERS[s.kind].name, team: RAIDER_RED, style });
      char.tag.visible = false;
      if (style === 'merc') char.root.scale.setScalar(1.05);
      char.onMagDrop = null;
    } else {
      char.revive();
      char.setCarry(null);
    }
    char.root.visible = true;
    char.root.position.set(s.x, s.y, s.z);
    this.g.scene.add(char.root);
    return { kind: s.kind, obj: char.root, char };
  }

  _release(v) {
    this.g.scene.remove(v.obj);
    if (v.snd) v.snd.stop();
    if (v.char) { v.char.root.visible = false; v.char.root.position.y = 0; this.pool[v.char.style].push(v.char); }
  }

  /** Build a few characters ahead of time so the first wave doesn't hitch. */
  prewarm(kinds) {
    const want = { scav: Math.min(4, kinds.scav || 0), merc: Math.min(3, kinds.merc || 0) };
    for (const style of ['scav', 'merc']) {
      while (this.pool[style].length < want[style]) {
        const c = new Character({ name: style, team: RAIDER_RED, style });
        c.tag.visible = false;
        if (style === 'merc') c.root.scale.setScalar(1.05);
        c.root.visible = false;
        this.pool[style].push(c);
      }
    }
  }

  clear() {
    for (const v of this.views.values()) this._release(v);
    this.views.clear();
  }

  update(dt, states, time) {
    const seen = new Set();
    for (const s of states) {
      seen.add(s.id);
      let v = this.views.get(s.id);
      if (!v) { v = this._make(s); this.views.set(s.id, v); }
      v.state = s;
      if (v.drone) {
        v.drone.update(dt, s, time);
        if (v.snd) v.snd.set(tmp.set(s.x, s.y, s.z), !s.dead, s.carrying ? 1 : 0);
        if (s.dead && v.snd) { v.snd.stop(); v.snd = null; }
        continue;
      }
      const c = v.char;
      if (s.dead && !v.dead) { v.dead = true; v.deadT = 0; c.kill(); c.setCarry(null); }
      if (v.dead) {
        v.deadT += dt;
        // bodies sink away after a few seconds
        c.root.position.set(s.x, s.y - Math.max(0, v.deadT - 4) * 0.35, s.z);
        c.update(dt, { vx: 0, vz: 0, yaw: s.yaw, pitch: 0, grounded: true, crouch: 0, sprint: false, ready: 0 });
        continue;
      }
      c.root.position.set(s.x, s.y, s.z);
      const sp = Math.hypot(s.vx, s.vz);
      c.update(dt, {
        vx: s.vx, vz: s.vz, yaw: s.yaw, pitch: s.pitch, grounded: !s.climbing,
        crouch: s.breaching ? 1 : 0, sprint: sp > 3.3 && !s.aiming && !s.carrying, ready: s.aiming ? 1 : s.climbing ? 0 : 0.35,
      });
      c.setCarry(s.carrying ? s.carry || 'x' : null);
    }
    for (const [id, v] of this.views) if (!seen.has(id)) { this._release(v); this.views.delete(id); }
  }

  /** Muzzle position of raider `id` (world), or null when we can't see it. */
  muzzle(id) {
    const v = this.views.get(id);
    if (!v || !v.char || !v.obj.visible) return null;
    v.char.root.updateMatrixWorld(true);
    return v.char.pistol.muzzle.getWorldPosition(V());
  }

  /** Our own shot looked like it hit this raider (so the server's echo doesn't double up). */
  notePredicted(id) { this.predicted.set(id, this.g.time); }

  // ---------------------------------------------------------------- events
  onEvent(e) {
    const g = this.g, fx = g.effects, audio = g.audio;
    const me = g.playerId;
    switch (e.type) {
      case 'raiderFire': {
        const from = this.muzzle(e.id) || V(...e.o);
        const to = V(...e.p);
        const v = this.views.get(e.id);
        if (v && v.char) v.char.fire();
        fx.tpMuzzleFlash(from.clone());
        fx.tracer(from, to, 0xff8a5a, 260);
        audio.raiderShot(from, from.distanceTo(g.camera.position), v && v.kind === 'merc');
        const delay = Math.min(150, from.distanceTo(to) / 3.2);
        if (e.hit !== me) {
          if (e.s) setTimeout(() => { fx.impact(e.p, e.n || [0, 1, 0], e.s, { decal: e.s !== 'flesh' }); audio.impact(to, e.s); }, delay);
          // near miss past our head?
          const eye = g.eyePosition(V());
          const d = tmp.subVectors(to, from);
          const L = d.length();
          if (L > 0.1) {
            d.divideScalar(L);
            const t = Math.max(0, Math.min(L, tmp2.subVectors(eye, from).dot(d)));
            const closest = from.clone().addScaledVector(d, t);
            if (closest.distanceTo(eye) < 1.6 && t > 2) audio.whiz(closest);
          }
        }
        break;
      }
      case 'turretFire': {
        const from = g.factoryView.turretFired(e.id);
        const m = g.factory.machines.get(e.id);
        const o = from || (m ? V(m.x, 1.7, m.z) : null);
        if (!o) break;
        const to = V(...e.p);
        fx.tracer(o, to, 0xffe08a, 380);
        audio.turretShot(o);
        if (e.s) setTimeout(() => { fx.impact(e.p, e.n || [0, 1, 0], e.s, { decal: e.s !== 'flesh' && e.s !== 'metal' }); }, Math.min(80, o.distanceTo(to) / 4));
        break;
      }
      case 'raiderHit': {
        const v = this.views.get(e.id);
        if (v && v.char) v.char.hit(e.dir[0], e.dir[1], e.part === 'head' ? 1.4 : 1);
        if (e.by !== me || !(g.time - (this.predicted.get(e.id) ?? -9) < 0.6)) {
          if (v && e.by !== me && typeof e.by === 'string' && !e.by.startsWith('turret')) {
            const s = v.state;
            if (s) fx.impact([s.x, s.y + (e.part === 'head' ? 1.6 : 1.15), s.z], [-e.dir[0], 0, -e.dir[1]], v.kind === 'drone' ? 'metal' : 'flesh', { decal: false });
          }
        }
        if (e.by === me && !(g.time - (this.predicted.get(e.id) ?? -9) < 0.6)) g.hud.hitmarker(e.part === 'head' ? 'head' : 'body', e.dmg);
        break;
      }
      case 'raiderDown': {
        const who = e.by === me ? 'You' : typeof e.by === 'string' && e.by.startsWith('turret') ? 'Sentry' : g.nameOf(e.by);
        const kind = RAIDERS[e.kind].name;
        g.hud.feed(`${who}  ▸  ${kind}${e.part === 'head' ? '  (headshot)' : ''}  ·  +$${e.bounty}`, e.by === me ? 'kill' : '');
        if (e.by === me) { g.hud.hitmarker('kill', e.bounty ? `+$${e.bounty}` : ''); audio.hitMarker(true); g.career.kills = (g.career.kills || 0) + 1; }
        if (e.kind === 'drone') { const v = this.views.get(e.id); if (v && v.snd) { v.snd.stop(); v.snd = null; } }
        break;
      }
      case 'droneCrash': fx.explosion(V(e.x, e.y + 0.3, e.z), 0.6); audio.explosion(V(e.x, e.y, e.z), 0.6); break;
      case 'raiderClimb': { const v = this.views.get(e.id); if (v && v.state) audio.climb(V(v.state.x, v.state.y + 1, v.state.z), e.fence); break; }
      case 'gateBreach': {
        const m = g.factory.machines.get(e.gate);
        if (m) audio.breachBeep(V(m.x, 1, m.z));
        g.hud.toast('A merc is setting a charge on your security gate!', 'warn');
        break;
      }
      case 'gateBreached': {
        const p = V(e.x, 1, e.z);
        fx.explosion(p, 1);
        audio.explosion(p, 1);
        g.hud.toast('Security gate blown open — it repairs itself after the raid', 'warn');
        break;
      }
      case 'raiderLoot': {
        const v = this.views.get(e.id);
        if (v && v.state) fx.lowPolyPuff(V(v.state.x, v.state.y + 0.9, v.state.z), 0.45, { count: 5 });
        if (g.time - this.lastWarnToast > 2.5) {
          this.lastWarnToast = g.time;
          g.hud.toast(`Raiders are taking ${e.count}× ${ITEMS[e.item].name}${e.from === 'cage' ? ' from the pickup cage' : ''}! Stop them before they reach the fence`, 'warn');
        }
        break;
      }
      case 'raiderEscaped':
        if (e.value > 0) g.hud.toast(`A raider got away with $${e.value.toLocaleString('en-US')} of goods`, 'warn');
        break;
      case 'turretEmpty': {
        const last = this.turretEmptyT.get(e.id) ?? -99;
        if (g.time - last > 20) { this.turretEmptyT.set(e.id, g.time); g.hud.toast('A sentry turret is out of ammo — load ammo boxes into it (E)', 'warn'); }
        break;
      }
      case 'turretLoaded': { const m = g.factory.machines.get(e.id); if (m && e.boxes > 0) audio.ammoRefill(); break; }
      case 'raidWarning':
        this.prewarm(e.kinds || {});
        audio.siren(V(HALL.x, HALL.h + 1, HALL.z + HALL.d / 2));
        break;
      case 'raidImminent': audio.siren(V(HALL.x, HALL.h + 1, HALL.z + HALL.d / 2), 4); break;
      case 'raidReset': this.clear(); break;
    }
  }
}
