// Raid HUD: warning / raid status bar under the compass, raid direction on the compass,
// damage-direction wedges, low-health vignette, the downed screen, revive progress and
// world markers (raiders carrying goods, downed partners, where a raid is coming from).
import * as THREE from 'three';
import { RAID_DIRS, HEALTH } from '../../shared/raid/raidDefs.js';

const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const mmss = (s) => { s = Math.max(0, Math.ceil(s)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
const money = (n) => '$' + Math.round(n).toLocaleString('en-US');
const tmp = new THREE.Vector3();

export class RaidHUD {
  constructor() {
    const hud = document.getElementById('hud');
    const el = (id, tag = 'div', parent = hud) => { const e = document.createElement(tag); e.id = id; parent.appendChild(e); return e; };
    this.bar = el('raidbar');
    this.vignette = el('vignette');
    this.dmgdir = el('dmgdir');
    this.downed = el('downed');
    this.revring = el('revring');
    this.markers = el('markers');
    this.strip = document.getElementById('compass-strip');
    this.compassMarks = [0, 1].map(() => { const m = document.createElement('b'); m.className = 'raidmark'; m.hidden = true; this.strip.appendChild(m); return m; });
    this.wedges = [];
    this.pool = [];
    this.cache = {};
    this.flashT = 9;
  }

  set(key, el, prop, val) {
    if (this.cache[key] === val) return;
    this.cache[key] = val;
    el[prop] = val;
  }

  /** Someone shot us from (fx, fz). */
  damage(fx, fz, px, pz, amount) {
    const ang = Math.atan2(fx - px, fz - pz); // world bearing of the shooter
    let w = this.wedges.find((x) => Math.abs(x.ang - ang) < 0.3);
    if (!w) {
      const e = document.createElement('i');
      this.dmgdir.appendChild(e);
      w = { e, ang, t: 0 };
      this.wedges.push(w);
      if (this.wedges.length > 5) { const old = this.wedges.shift(); old.e.remove(); }
    }
    w.ang = ang; w.t = 0; w.power = Math.min(1, 0.45 + amount / 30);
    this.flashT = 0;
  }

  update(dt, c) {
    // ---------------- raid status bar + compass marker
    const R = c.raid;
    let html = '', tone = '';
    if (R.phase === 'warning') {
      const D = RAID_DIRS[R.dir] || RAID_DIRS.north;
      const k = R.plan && R.plan.kinds ? R.plan.kinds : null;
      const extra = k ? [k.merc ? `${k.merc} armoured` : '', k.drone ? `${k.drone} drone${k.drone > 1 ? 's' : ''}` : ''].filter(Boolean).join(' · ') : '';
      html = `<b>⚠ Raid inbound</b><span>from the <em>${D.label.toUpperCase()}</em> · ${R.plan ? `${R.plan.count} raiders${extra ? ` (${extra})` : ''}` : ''}</span><strong>${mmss(R.eta)}</strong>`;
      tone = R.eta <= 10 ? 'warn hot' : 'warn';
    } else if (R.phase === 'active' && R.cur) {
      const carriers = c.carriers || 0;
      html = `<b>Raid in progress</b><span>${R.cur.left} raider${R.cur.left === 1 ? '' : 's'} left${carriers ? ` · <em>${carriers} carrying goods</em>` : ''}${R.cur.stolen ? ` · ${money(R.cur.stolen)} stolen` : ''}</span>`;
      tone = 'active';
    }
    this.set('bar', this.bar, 'innerHTML', html);
    this.bar.className = tone;
    const showMark = R.phase === 'warning' || R.phase === 'active';
    const bearing = RAID_DIRS[R.dir] ? RAID_DIRS[R.dir].bearing : 0;
    this.compassMarks.forEach((m, i) => {
      m.hidden = !showMark;
      if (showMark) m.style.left = `${(bearing + i * 360 + 180) * 4}px`;
    });

    // ---------------- damage wedges + vignette
    const camYaw = c.yaw;
    for (let i = this.wedges.length - 1; i >= 0; i--) {
      const w = this.wedges[i];
      w.t += dt;
      if (w.t > 1.3) { w.e.remove(); this.wedges.splice(i, 1); continue; }
      // screen angle: 0 = straight ahead (top), clockwise
      const rel = -(w.ang - (camYaw + Math.PI));
      w.e.style.transform = `rotate(${rel}rad)`;
      w.e.style.opacity = String(w.power * Math.min(1, (1.3 - w.t) / 0.5));
    }
    this.flashT += dt;
    const hp = c.me ? c.me.hp : HEALTH.max;
    const low = Math.max(0, 1 - hp / HEALTH.max);
    const vig = Math.min(1, Math.pow(low, 1.4) * 0.9 + Math.max(0, 0.35 - this.flashT) * 1.2);
    this.vignette.style.opacity = c.me && c.me.down ? '1' : vig.toFixed(3);
    this.vignette.classList.toggle('down', !!(c.me && c.me.down));

    // ---------------- downed
    const down = !!(c.me && c.me.down);
    document.body.classList.toggle('downed', down);
    if (down) {
      const me = c.me;
      const rev = me.reviver ? c.nameOf(me.reviver) : null;
      const left = Math.max(0, HEALTH.bleedout - (me.downT || 0));
      const sub = rev ? `${esc(rev)} is reviving you…` : c.coop ? `Your partner can revive you (hold <kbd>E</kbd>) · back at the terminal in ${Math.ceil(left)} s` : `Back on your feet at the supply terminal in ${Math.ceil(left)} s — nothing lost`;
      const prog = rev ? Math.min(1, (me.reviveT || 0) / HEALTH.reviveTime) : 1 - left / HEALTH.bleedout;
      this.set('down', this.downed, 'innerHTML', `<b>You're down</b><span>${sub}</span><i style="--p:${(prog * 100).toFixed(1)}%" class="${rev ? 'rev' : ''}"></i>`);
    }
    this.downed.classList.toggle('show', down);

    // ---------------- revive progress (you reviving someone)
    if (c.reviving) {
      this.revring.style.setProperty('--p', `${(c.reviving.progress * 100).toFixed(1)}%`);
      this.revring.dataset.label = `Reviving ${c.reviving.name}`;
    }
    this.revring.classList.toggle('show', !!c.reviving);

    // ---------------- world markers
    this._markers(c.markers || [], c.camera);
  }

  _markers(list, cam) {
    const W = innerWidth, H = innerHeight;
    let n = 0;
    for (const mk of list) {
      let e = this.pool[n];
      if (!e) { e = document.createElement('div'); e.className = 'wmark'; this.markers.appendChild(e); this.pool.push(e); }
      n++;
      tmp.set(mk.x, mk.y, mk.z).project(cam);
      const behind = tmp.z > 1;
      let x = (tmp.x * 0.5 + 0.5) * W, y = (-tmp.y * 0.5 + 0.5) * H;
      if (behind) { x = W - x; y = H - y; }
      const m = 36;
      const off = behind || x < m || x > W - m || y < m || y > H - m;
      if (off) {
        // clamp to the screen edge, pointing toward it
        const cx = W / 2, cy = H / 2;
        let dx = x - cx, dy = y - cy;
        if (behind && Math.abs(dy) < 1) dy = 1;
        const s = Math.min((W / 2 - m) / Math.abs(dx || 1e-6), (H / 2 - m) / Math.abs(dy || 1e-6));
        x = cx + dx * s; y = cy + dy * s;
        e.style.setProperty('--rot', `${Math.atan2(dy, dx) + Math.PI / 2}rad`);
      }
      e.className = `wmark ${mk.kind}${off ? ' off' : ''}`;
      e.style.transform = `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px)`;
      const txt = `${mk.label || ''}${mk.dist != null ? ` <small>${Math.round(mk.dist)} m</small>` : ''}`;
      if (e._t !== txt) { e._t = txt; e.innerHTML = `<i></i><span>${txt}</span>`; }
      e.hidden = false;
    }
    for (let i = n; i < this.pool.length; i++) this.pool[i].hidden = true;
  }
}
