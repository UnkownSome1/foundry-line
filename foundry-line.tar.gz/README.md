# Foundry Line — build 0.5 (raids, defences + belt logistics)

Co-op factory shooter: three.js browser client + a dependency-free Node game server.

## What's new in 0.5
- **Raids** from company level 2: random, 15–25 minutes apart, with a **90 s warning**
  (siren, radio call, countdown bar, compass marker for the side they come from).
  Scavengers first, then armoured mercs and cargo drones as raids grow. They path over a
  nav grid to the pickup cage and loose goods, grab them and run for the fence; kill a
  carrier and the goods drop. Machines are never damaged.
- **Defences** (fab bench or terminal): **sentry turrets** (ammo boxes, by hand or on a belt),
  **barricade walls** raiders must climb, **security gates** that open for your crew only
  (mercs can blow one open; it repairs itself after the raid). Placeable in the hall or
  anywhere in the yard except the truck/van routes.
- **Health, downs and revives:** partner holds E to revive you; otherwise you're back at the
  supply terminal after 10 s with everything you had. Bounties per raider, a rebate when
  nothing gets stolen, three security goals.
- **Receiving dock:** the delivery truck tips raw materials into a dock hopper by the south
  door; put a conveyor on the dock's arrow inside and deliveries roll straight onto it.
- **Belt logistics:** **splitter** (deals items to front/left/right in turn, skipping full
  outputs), **item filter** (one item type to the side you choose, the rest straight on),
  **merger** (joins belts, first come first served).
- Co-op: raiders, health, turrets and routing pieces are all server-authoritative; your shots
  at raiders are checked against where they were on your screen (lag compensation).

## Earlier builds
- **0.4** two-player co-op server (host's save, 4-letter codes, client prediction), main menu
  with save slots/profile/settings/career, company levels + goals.
- **0.3** build-your-own factory: machine kits, 0.5 m grid placement, conveyors, sell corner
  → pickup cage → van, contracts.

## Run it
- **Online (co-op):** see [DEPLOY.md](DEPLOY.md) — GitHub + Render's free plan, no build.
- **Locally:** `node server/server.js` → open `http://localhost:8080` (Node 20+).
- `index.html` alone (e.g. the claude.ai artifact) runs solo; co-op needs the server.

## Controls
WASD move · Shift sprint · C crouch · Space jump · LMB fire · RMB aim · R reload ·
E interact / pick up (hold E on a downed partner to revive) · Tab or I inventory ·
B build (R rotate, LMB place, B next kit, Q cancel) · F inspect · V third person · H help · Esc menu.

## Layout
- `src/shared/` — pure JS, no DOM or three.js; the server runs it unchanged.
  - `World.js`, `mapLayout.js`, `PlayerMovement.js` (bunny-hop capped), `vehiclePush.js`
  - `WeaponState.js`, `weapons.js` (recoil + kick tuning), `hitscan.js`
  - `factory/FactorySim.js` authoritative factory; `factory/items.js` all balancing;
    `factory/progression.js` levels, perks, goals; `factory/truck.js`, `factory/layout.js`, `factory/Inventory.js`
  - `net/protocol.js` wire format, snapshot/replica encoders shared by server and client
  - `raid/raidDefs.js` raid + turret + health tuning; `raid/nav.js` nav grid + A*;
    `raid/RaidSystem.js` director, raiders, drones, turrets, player health, lag-compensated shots
- `server/` — `server.js` (static files + rooms, 60 Hz), `Room.js` (one co-op session),
  `ws.js` (RFC 6455 WebSocket, no dependencies)
- `src/client/` — rendering, animation, audio, UI
  - `main.js` game loop, sessions, prediction/reconciliation, menu camera
  - `net/Session.js` LocalSession / NetSession; `net/RemotePlayers.js`
  - `ui/Menu.js` main + pause menu; `ui/Panels.js` inventory/terminal/machine panels; `ui/HUD.js`
  - `Storage.js` company slots, settings, career (localStorage, all guarded)
  - `factory/*` machine/item/vehicle models, `NodeModels.js` (splitter/filter/merger + receiving dock), build mode, factory view
  - `raid/RaidView.js` raiders, drones, tracers, siren; `raid/RaidHUD.js` warning bar, damage direction, downed screen, markers
  - `models/*`, `fp/*`, `fx/*`, `world/*`, `gfx/*`
- `render.yaml` Render Blueprint · `DEPLOY.md` setup guide

## Tests
`npm test` runs:
- `test/shared.test.mjs` — world, movement (incl. bunny-hop cap), weapons, hitboxes
- `test/factory.test.mjs` — factory loop, placement, belts, van 80/20, contracts,
  reset exploit, progression rules, saves with goods in transit
- `test/raid.test.mjs` — raid director timing, stealing, lag-compensated kills, turrets,
  placement rules, walls/gates + nav, health (down/revive/respawn), saves mid-raid, CPU
- `test/logistics.test.mjs` — dock → belt → chute, splitter, item filter, merger, saves, replicas
- `test/net.test.mjs` — starts the server (with `FOUNDRY_DEBUG=1` test hooks); host + guest over
  WebSocket: joining, prediction vs server, speed-hack guard, commands, cheat guards, a raid
  (warning relay, raiders in snapshots, lag-compensated kill, downed/respawn), save hand-back

Also: `node test/load.mjs` (server CPU/bandwidth, incl. a big raid), `python3 test/coop.py` and
`python3 test/coop_raid.py` (two headless browsers), `python3 test/raid_shots.py` and
`python3 test/logistics_shots.py` (solo walkthrough screenshots).
