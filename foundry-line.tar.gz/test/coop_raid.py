# Two headless browsers fight a raid together through the real Node server (build 0.5):
# host starts a session, guest joins, a raid is forced (debug hook), the guest shoots a
# raider (server-validated, lag-compensated), the host is downed and the guest revives them.
import asyncio, subprocess, os, time, json
from playwright.async_api import async_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SP = os.environ.get("FOUNDRY_SHOTS", os.path.join(ROOT, "test-output"))
os.makedirs(SP, exist_ok=True)
PORT = 8879
ARGS = ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]
NOAUDIO = "(()=>{const g=__game; g.audio.start=()=>{}; g.manual=true; window.G=g; return 'ready'})()"

async def main():
    env = dict(os.environ, PORT=str(PORT), FOUNDRY_LOCAL_THREE="1", FOUNDRY_DEBUG="1")
    srv = subprocess.Popen(["node", "server/server.js"], cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    time.sleep(1.0)
    logs = {"host": [], "guest": []}
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(args=ARGS)
            host = await (await b.new_context(viewport={"width": 1100, "height": 620})).new_page()
            guest = await (await b.new_context(viewport={"width": 1100, "height": 620})).new_page()
            for name, pg in (("host", host), ("guest", guest)):
                pg.on("console", lambda m, n=name: logs[n].append(f"[{m.type}] {m.text}"))
                pg.on("pageerror", lambda e, n=name: logs[n].append(f"[pageerror] {e}"))
                await pg.goto(f"http://localhost:{PORT}/")
                await pg.wait_for_function("window.__game !== undefined", timeout=60000)
                await pg.evaluate(NOAUDIO)
                await pg.wait_for_function("__game.serverInfo !== null", timeout=10000)
            print("server:", await host.evaluate("JSON.stringify(G.serverInfo)"))

            await host.evaluate("""(async()=>{ const g=G; g.settings.name='Ethan'; g.settings.color=0x2fb5c9; g.saveSettings();
                const m=g.saves.create('Ross Industries', 0x2fb5c9); g.deploy=()=>{};
                const d=new (g.session.constructor)(g.world, null); const data=d.serialize(); data.funds=5000; data.progress={xp:400,goals:[]}; d.dispose(); g.saves.write(m.id, data);
                await g.hostCoop(m.id); g.debugStart(); return g.session.code })()""")
            code = await host.evaluate("G.session.code")
            await guest.evaluate("(()=>{ const g=G; g.settings.name='Gus'; g.settings.color=0xff6b1a; g.saveSettings(); g.deploy=()=>{}; return 1 })()")
            await guest.evaluate(f"(async()=>{{ await G.joinCoop('{code}'); G.debugStart(); return 1 }})()")
            print("session", code, "guest id", await guest.evaluate("G.session.playerId"))

            async def run(pg, secs, js_each=""):
                await pg.evaluate(f"""(async()=>{{ const g=G; const end=performance.now()+{secs*1000};
                    while(performance.now()<end){{ {js_each} g.step(1/30,false); await new Promise(r=>setTimeout(r,16)); }} return 1 }})()""")
            async def both(secs, h="", g=""):
                await asyncio.gather(run(host, secs, h), run(guest, secs, g))

            # both face south-east toward the yard; raid comes from the south (big one)
            for pg in (host, guest):
                await pg.evaluate("(()=>{ G.yaw = Math.PI; G.pitch = -0.02; return 1 })()")
            await both(0.6)
            # a mid-sized raid (as if it were the 4th), arriving in 20 s
            await host.evaluate("(()=>{ G.session.send({ t: 'debug', k: 'raid', sec: 20, no: 3 }); return 1 })()")
            await both(1.5)
            info = await guest.evaluate("JSON.stringify(G.raidInfo())")
            print("guest raid info:", info)
            await guest.evaluate("G.step(1/60)")
            await guest.screenshot(path=f"{SP}/co_raid_01_warning_guest.png")

            # during the warning: host goes down, the guest (1.5 m away) holds E on them
            await host.evaluate("(()=>{ G.session.send({ t: 'debug', k: 'hurt', n: 500 }); return 1 })()")
            await both(1.0)
            print("host down (host view):", await host.evaluate("G.isDown"), "| guest sees host down:", await guest.evaluate("!!G.factory.players.get('local')?.down"))
            hp = json.loads(await guest.evaluate("JSON.stringify(G.session.remoteStates().map(r=>({x:r.x,z:r.z})))"))
            gp = json.loads(await guest.evaluate("JSON.stringify({x:G.player.x,z:G.player.z})"))
            print("host at", hp, "guest at", gp)
            if hp:
                await guest.evaluate(f"(()=>{{ const g=G; const dx={hp[0]['x']}-g.player.x, dz={hp[0]['z']}-g.player.z; g.yaw=Math.atan2(-dx,-dz); g.pitch=-0.75; return 1 }})()")
            await both(0.3)
            await guest.evaluate("G.step(1/60)")
            await guest.screenshot(path=f"{SP}/co_raid_04_guest_sees_host_down.png")
            print("guest focus:", await guest.evaluate("JSON.stringify(G.focus && {kind:G.focus.kind,id:G.focus.id})"))
            await guest.evaluate("(()=>{ window.EV=[]; const f=G.onFactoryEvent.bind(G); G.onFactoryEvent=(e)=>{ if(/revive|Revive|playerDown|playerHit|respawn/.test(e.type)) EV.push(e.type+':'+(e.player||'')+':'+(e.hp??'')); f(e); }; G.input.keys.add('KeyE'); G.input.pressed.add('KeyE'); return 1 })()")
            await both(1.4)
            print("mid-revive (guest view of host):", await guest.evaluate("JSON.stringify((({reviver, reviveT, down, downT})=>({reviver, reviveT, down, downT}))(G.factory.players.get('local')))"), "reviveTarget", await guest.evaluate("G.reviveTarget"))
            await guest.evaluate("G.step(1/60)")
            await guest.screenshot(path=f"{SP}/co_raid_05_reviving.png")
            await host.evaluate("G.step(1/60)")
            await host.screenshot(path=f"{SP}/co_raid_06_host_being_revived.png")
            await both(2.2)
            await guest.evaluate("(()=>{ G.input.keys.delete('KeyE'); return 1 })()")
            await both(0.5)
            print("after revive — host down:", await host.evaluate("G.isDown"), "hp", await host.evaluate("G.me.hp"), "events:", await guest.evaluate("EV.join(' ')"))
            await both(1.0)

            # wait for contact
            await both(20)
            await both(10)
            n = await guest.evaluate("G.session.raiderStates().filter(r=>!r.dead).length")
            print("raiders visible to guest:", n)
            # guest aims at the nearest raider and fires a few shots
            aim = """const rs = g.session.raiderStates().filter(r=>!r.dead && r.kind!=='drone');
                if (rs.length) { const p = g.player; rs.sort((a,b)=>Math.hypot(a.x-p.x,a.z-p.z)-Math.hypot(b.x-p.x,b.z-p.z)); const r = rs[0];
                const dx=r.x-p.x, dy=r.y+1.2-(p.y+1.62), dz=r.z-p.z; g.yaw=Math.atan2(-dx,-dz); g.pitch=Math.atan2(dy,Math.hypot(dx,dz)); g.input.mouse.right=true; }"""
            hits0 = await guest.evaluate("G.career.hits")
            for i in range(6):
                await run(guest, 0.25, aim)
                await guest.evaluate("(()=>{ G.input.mouse.left = true; G.step(1/30,false); G.input.mouse.left = false; return 1 })()")
                await run(host, 0.05)
            await both(0.4, "", aim)
            await guest.evaluate("G.step(1/60)")
            await guest.screenshot(path=f"{SP}/co_raid_02_guest_shooting.png")
            await guest.evaluate("(()=>{ G.input.mouse.right=false; return 1 })()")
            print("guest predicted hits:", await guest.evaluate("G.career.hits") - hits0)
            await host.evaluate("G.step(1/60)")
            await host.screenshot(path=f"{SP}/co_raid_03_host_view.png")

            print("stats (host):", await host.evaluate("JSON.stringify(G.raidInfo())"))
            await host.evaluate("(()=>{G.quitToMenu(); return 1})()")
            await both(1.5)
            meta = json.loads(await host.evaluate("JSON.stringify(G.saves.list()[0])"))
            data = json.loads(await host.evaluate(f"JSON.stringify(G.saves.load('{meta['id']}').raids)"))
            print("host save raids:", data)
            await b.close()
    finally:
        srv.terminate()
        out = srv.stdout.read() if srv.stdout else ""
        print("--- server log ---\n" + out[-1200:])
        for n, l in logs.items():
            errs = [x for x in l if ("error" in x.lower() or "pageerror" in x) and "ERR_TUNNEL" not in x and "fonts" not in x]
            print(f"--- {n} errors ({len(errs)}) ---")
            for x in errs[:15]: print(x)

asyncio.run(main())
