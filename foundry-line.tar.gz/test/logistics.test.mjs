// Node tests for belt logistics (build 0.5): receiving dock → belts, splitter, item filter,
// merger, saves, and a few layouts that used to misbehave.
import assert from 'node:assert/strict';
import { World } from '../src/shared/World.js';
import { FactorySim } from '../src/shared/factory/FactorySim.js';
import { FACTORY } from '../src/shared/factory/layout.js';
import { CONVEYOR } from '../src/shared/factory/items.js';
import { encodeFull, applyFull, applyEvent, encodeSlow, applySlow } from '../src/shared/net/protocol.js';

const DT = 1 / 60;
const mk = () => {
  const sim = new FactorySim(new World(), { seed: 9, funds: 5000 });
  const p = sim.addPlayer('local');
  p.pos = [0, 0, -12];
  p.inventory.add('conveyor', 50);
  p.inventory.add('splitter', 4);
  p.inventory.add('sorter', 4);
  p.inventory.add('merger', 4);
  const place = (kind, x, z, q) => {
    p.pos = [x, 0, z + 2.5];
    const slot = p.inventory.slots.findIndex((s) => s && s.type === kind);
    const r = sim.apply('local', { type: 'place', slot, x, z, q });
    assert.ok(r.ok, `${kind} at ${x},${z}: ${r.error}`);
    return sim.belts.get(r.id);
  };
  const run = (sec, onEv) => { for (let i = 0; i < Math.round(sec * 60); i++) for (const e of sim.tick(DT)) if (onEv) onEv(e); };
  const feed = (b, type, count = 1) => { const it = sim.spawnItem(type, count, [b.x - b.dx * 0.3, CONVEYOR.top, b.z - b.dz * 0.3], [0, 0, 0]); it.rest = true; it.belt = b.id; return it; };
  return { sim, p, place, run, feed };
};
// q: 0 → +z, 1 → +x, 2 → −z, 3 → −x

// ---------------------------------------------------------------- receiving dock → belt → sell corner
{
  const { sim, p, place, run } = mk();
  p.pos = [-7, 0, -6];
  assert.ok(sim.apply('local', { type: 'order', items: { steel_plate: 40, pellets: 20, kit_press: 1 } }).ok);
  let loads = 0;
  run(40, (e) => { if (e.type === 'dockLoad') loads++; });
  assert.equal(sim.dock.reduce((a, s) => a + s.count, 0), 60, 'raw materials went into the dock bin');
  assert.ok(loads >= 3, 'tipped in stack by stack');
  assert.ok([...sim.items.values()].some((it) => it.type === 'kit_press'), 'machine kits still land on the bay');
  // belt from the dock's output cell east into the sell corner
  for (let x = 6; x <= 15; x++) place('conveyor', x, -6, 1);
  const out = [];
  run(30, (e) => { if (e.type === 'dockOut') out.push(e.item); });
  assert.equal(sim.dock.length, 0, 'dock emptied onto the belt');
  const caged = sim.cage.reduce((a, s) => a + s.count, 0);
  assert.equal(caged, 60, 'everything rode the belt into the sell corner');
  console.log(`dock ok: ${loads} stacks tipped in, ${out.length} pushed out onto the belt, ${caged} units reached the chute`);
  // taking from the dock by hand
  sim.dock.push({ type: 'lead', count: 12, owner: null });
  p.pos = [FACTORY.dock.panel[0], 0, FACTORY.dock.panel[2] - 1];
  const tk = sim.apply('local', { type: 'dockTake' });
  assert.ok(tk.ok && tk.moved === 12 && p.inventory.count('lead') === 12);
}

// ---------------------------------------------------------------- splitter deals items round-robin
{
  const { sim, place, run, feed } = mk();
  for (let x = -10; x <= -6; x++) place('conveyor', x, -12, 1);
  const sp = place('splitter', -5, -12, 1);
  const fwd = place('conveyor', -4, -12, 1);
  const left = place('conveyor', -5, -13, 2); // left of +x is −z
  const right = place('conveyor', -5, -11, 0);
  assert.deepEqual([sp.lx, sp.lz], [0, -1]);
  const seen = { [fwd.id]: new Set(), [left.id]: new Set(), [right.id]: new Set() };
  const input = sim.belts.get([...sim.belts.values()].find((b) => b.x === -10 && b.z === -12).id);
  for (let i = 0; i < 30; i++) {
    feed(input, 'bracket');
    for (let k = 0; k < 24; k++) { sim.tick(DT); for (const it of sim.items.values()) if (seen[it.belt]) seen[it.belt].add(it.id); }
  }
  for (let k = 0; k < 60 * 6; k++) { sim.tick(DT); for (const it of sim.items.values()) if (seen[it.belt]) seen[it.belt].add(it.id); }
  const n = [fwd, left, right].map((b) => seen[b.id].size);
  assert.equal(n[0] + n[1] + n[2], 30, `all 30 items went through (${n})`);
  assert.ok(Math.max(...n) - Math.min(...n) <= 1, `even three-way split (${n})`);
  console.log(`splitter ok: 30 items → ${n.join(' / ')} (front / left / right)`);
}

// ---------------------------------------------------------------- item filter sorts one type off to the side
{
  const { sim, p, place, run, feed } = mk();
  for (let x = -10; x <= -6; x++) place('conveyor', x, -16, 1);
  const so = place('sorter', -5, -16, 1);
  const fwd = place('conveyor', -4, -16, 1);
  const left = place('conveyor', -5, -17, 2);
  p.pos = [-5, 0, -15];
  assert.ok(sim.apply('local', { type: 'setFilter', id: so.id, item: 'pellets', side: 'left' }).ok);
  const input = [...sim.belts.values()].find((b) => b.x === -10 && b.z === -16);
  const got = { fwd: [], left: [] };
  const mark = () => { for (const it of sim.items.values()) { if (it.belt === fwd.id && !got.fwd.includes(it.type + it.id)) got.fwd.push(it.type + it.id); if (it.belt === left.id && !got.left.includes(it.type + it.id)) got.left.push(it.type + it.id); } };
  for (let i = 0; i < 16; i++) { feed(input, i % 2 ? 'pellets' : 'steel_plate', 5); for (let k = 0; k < 30; k++) { sim.tick(DT); mark(); } }
  for (let k = 0; k < 60 * 5; k++) { sim.tick(DT); mark(); }
  assert.ok(got.left.length === 8 && got.left.every((t) => t.startsWith('pellets')), `pellets turned left (${got.left.length})`);
  assert.ok(got.fwd.length === 8 && got.fwd.every((t) => t.startsWith('steel_plate')), `everything else straight on (${got.fwd.length})`);
  // switch side: now pellets go right; with nothing on the right they carry straight on (no jam)
  assert.ok(sim.apply('local', { type: 'setFilter', id: so.id, side: 'right' }).ok);
  const it = feed(input, 'pellets');
  run(8);
  assert.ok(!sim.items.has(it.id) || sim.items.get(it.id).belt !== so.id, 'no jam when the filter side has no belt');
  console.log('filter ok: 8 pellets → left, 8 steel → straight on; unconnected side falls back to straight');
}

// ---------------------------------------------------------------- merger joins two lines fairly
{
  const { sim, place, run, feed } = mk();
  const back = place('conveyor', 4, -20, 1);
  place('conveyor', 3, -20, 1);
  const side = place('conveyor', 5, -21, 0); // points +z into the merger's left side
  place('conveyor', 5, -22, 0);
  const mg = place('merger', 5, -20, 1);
  const out = place('conveyor', 6, -20, 1);
  for (let x = 7; x <= 9; x++) place('conveyor', x, -20, 1);
  const a = [], b = [];
  const inA = [...sim.belts.values()].find((t) => t.x === 3 && t.z === -20);
  const inB = [...sim.belts.values()].find((t) => t.x === 5 && t.z === -22);
  const order = [];
  const tick = () => { sim.tick(DT); for (const it of sim.items.values()) if (it.belt === out.id && !order.includes(it.id)) order.push(it.id); };
  for (let i = 0; i < 6; i++) { a.push(feed(inA, 'housing').id); b.push(feed(inB, 'bracket').id); for (let k = 0; k < 27; k++) tick(); }
  for (let k = 0; k < 60 * 14; k++) tick();
  assert.equal(order.length, 12, `all 12 items merged (${order.length})`);
  const firstHalf = order.slice(0, 6);
  assert.ok(firstHalf.some((id) => a.includes(id)) && firstHalf.some((id) => b.includes(id)), 'both inputs take turns');
  // a belt pointing at the merger's front is refused (items don't enter backwards)
  assert.equal(sim._enterNode(mg, { id: 999, type: 'bracket' }, [-1, 0]), false);
  console.log(`merger ok: ${order.map((id) => (a.includes(id) ? 'A' : 'B')).join('')}`);
}

// ---------------------------------------------------------------- dock straight onto a splitter + saves
{
  const { sim, p, place, run } = mk();
  const sp = place('splitter', 6, -6, 3); // at the dock output, facing west (−x)
  place('conveyor', 5, -6, 3);
  place('conveyor', 6, -7, 2);
  sim.dock.push({ type: 'steel_plate', count: 20, owner: null }, { type: 'copper_wire', count: 10, owner: null }, { type: 'pellets', count: 10, owner: null });
  run(4);
  assert.equal(sim.dock.length, 0, 'dock pushes onto a splitter too');
  const so = place('sorter', -8, -24, 0);
  p.pos = [-8, 0, -23];
  sim.apply('local', { type: 'setFilter', id: so.id, item: 'motor', side: 'right' });
  sim.dock.push({ type: 'lead', count: 5, owner: null });
  const data = JSON.parse(JSON.stringify(sim.serialize()));
  const s2 = new FactorySim(new World(), { seed: 9, fresh: false });
  s2.load(data);
  const kinds = [...s2.belts.values()].map((b) => b.kind).sort();
  assert.deepEqual(kinds.filter((k) => k !== 'belt'), ['sorter', 'splitter']);
  const so2 = [...s2.belts.values()].find((b) => b.kind === 'sorter');
  assert.equal(so2.filter, 'motor');
  assert.equal(so2.side, 'right');
  assert.equal(s2.dock[0].type, 'lead');
  // pick a splitter back up → the splitter item, not a conveyor
  p.pos = [sp.x, 0, sp.z + 1];
  const before = p.inventory.count('splitter');
  assert.ok(sim.apply('local', { type: 'packBelt', id: sp.id }).ok);
  assert.equal(p.inventory.count('splitter'), before + 1);
  console.log('saves ok: splitter/filter settings and dock contents survive a reload');
}

// ---------------------------------------------------------------- two belts pointing at each other don't ping-pong
{
  const { sim, place, run, feed } = mk();
  const a = place('conveyor', -12, -8, 1);
  place('conveyor', -11, -8, 3);
  const it = feed(a, 'bracket');
  run(3);
  const now = sim.items.get(it.id);
  assert.ok(now && now.belt === a.id && Math.abs(now.x - -11.5) < 0.05, 'goods stop where two belts meet head-on (no ping-pong)');
}

// ---------------------------------------------------------------- co-op replicas see pieces, settings and the dock
{
  const { sim, p, place } = mk();
  place('conveyor', -12, -12, 1);
  const so = place('sorter', -11, -12, 1);
  sim.dock.push({ type: 'brass', count: 7, owner: null });
  sim.tick(DT);
  const rep = new FactorySim(new World(), { fresh: false, replica: true });
  applyFull(rep, JSON.parse(JSON.stringify(encodeFull(sim))));
  assert.equal(rep.belts.get(so.id).kind, 'sorter');
  assert.equal(rep.dock[0].type, 'brass');
  p.pos = [-11, 0, -11];
  sim.apply('local', { type: 'setFilter', id: so.id, item: 'lead', side: 'right' });
  const sp = place('splitter', -10, -12, 1);
  for (const e of sim.tick(DT)) applyEvent(rep, JSON.parse(JSON.stringify(e)));
  applySlow(rep, JSON.parse(JSON.stringify(encodeSlow(sim))));
  assert.equal(rep.belts.get(so.id).filter, 'lead');
  assert.equal(rep.belts.get(so.id).side, 'right');
  assert.equal(rep.belts.get(sp.id).kind, 'splitter');
  console.log('replica ok: routing pieces, filter settings and dock contents reach co-op clients');
}

console.log('ALL LOGISTICS TESTS PASSED');
