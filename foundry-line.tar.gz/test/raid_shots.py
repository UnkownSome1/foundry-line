# Solo raid walkthrough in a headless browser (build 0.5): places defences, forces a raid
# from the east, and screenshots the warning, the fight, turret fire, climbing, the
# downed screen and the new panels. Starts the real server (serves the page + local three.js).
import asyncio, subprocess, os, sys, time, json
from playwright.async_api import async_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SP = os.environ.get("FOUNDRY_SHOTS", os.path.join(ROOT, "test-output"))
os.makedirs(SP, exist_ok=True)
PORT = 8878
ARGS = ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]

SETUP = """(async () => {
  const g = window.__game; window.G = g;
  g.audio.start = () => {}; g.manual = true; g.deploy = () => {};
  g.settings.name = 'Ethan'; g.saveSettings();
  const meta = g.saves.create('Ross Industries', 0x2fb5c9);
  const tmp = new (g.session.constructor)(g.world, null);
  const data = tmp.serialize(); tmp.dispose();
  data.funds = 6000; data.progress = { xp: 400, goals: [] };
  g.saves.write(meta.id, data);
  g.playSolo(meta.id); g.debugStart();
  const sim = g.factory, me = sim.players.get('local');
  me.inventory.add('kit_turret', 2); me.inventory.add('kit_wall', 10); me.inventory.add('kit_gate', 1); me.inventory.add('ammo_box', 12);
  window.place = (kit, x, z, q) => { const slot = me.inventory.slots.findIndex((s) => s && s.type === kit); const p = g.player; p.x = x; p.z = z + (q & 1 ? 0 : 1.6); p.y = 0; if (q & 1) p.x = x - 1.6; return JSON.stringify(g.factoryCommand({ type: 'place', slot, x, z, q })); };
  return 'ok';
})()"""

def run_js(secs, dt=1/30):
    return f"(() => {{ for (let i = 0; i < {int(secs / dt)}; i++) G.step({dt}, false); G.step(1/60); return 1; }})()"

def look_at(x, y, z, tp=False):
    return f"""(() => {{ const g = G, p = g.player;
      const ex = p.x, ey = p.y + 1.62, ez = p.z; const dx = {x} - ex, dy = {y} - ey, dz = {z} - ez;
      g.yaw = Math.atan2(-dx, -dz); g.pitch = Math.atan2(dy, Math.hypot(dx, dz)); g.view = {'"tp"' if tp else '"fp"'}; return 1; }})()"""

def stand(x, z):
    return f"(() => {{ const p = G.player; p.x = {x}; p.z = {z}; p.y = G.world.heightAt({x}, {z}); Object.assign(G.prev, p); return 1; }})()"

async def main():
    env = dict(os.environ, PORT=str(PORT), FOUNDRY_LOCAL_THREE="1")
    srv = subprocess.Popen(["node", "server/server.js"], cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    time.sleep(1.0)
    logs = []
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(args=ARGS)
            pg = await (await b.new_context(viewport={"width": 1180, "height": 660})).new_page()
            pg.on("console", lambda m: logs.append(f"[{m.type}] {m.text}"))
            pg.on("pageerror", lambda e: logs.append(f"[pageerror] {e}"))
            await pg.goto(f"http://localhost:{PORT}/")
            await pg.wait_for_function("window.__game !== undefined", timeout=60000)
            print(await pg.evaluate(SETUP))
            ev = pg.evaluate
            # defences between the east gap and the pickup cage
            for kit, x, z, q in [("kit_turret", 35.5, 1.5, 0), ("kit_turret", 30.5, -14.5, 0),
                                 ("kit_wall", 40, 6, 1), ("kit_wall", 40.5, 8, 1), ("kit_wall", 40, 10, 1), ("kit_wall", 40, 16, 1), ("kit_wall", 40, 18, 1), ("kit_gate", 40, 13, 1)]:
                print(kit, x, z, await ev(f"place('{kit}', {x}, {z}, {q})"))
            # ammo into both turrets
            print(await ev("""(() => { const g = G, sim = g.factory; const out = [];
              for (const m of sim.machines.values()) if (m.def.defence === 'turret') { g.player.x = m.x; g.player.z = m.z + 1; out.push(JSON.stringify(g.factoryCommand({ type: 'loadTurret', machine: m.id, count: 5 }))); }
              sim.cage.push({ type: 'motor', count: 5, owner: 'local' }, { type: 'control_unit', count: 4, owner: 'local' }, { type: 'bracket', count: 30, owner: 'local' }, { type: 'harness', count: 6, owner: 'local' });
              return out.join(' '); })()"""))
            await ev(stand(31, 7))
            await ev(look_at(50, 1.5, 12.5))
            await ev(run_js(0.5))
            await pg.screenshot(path=f"{SP}/raid_01_defences.png")

            # force a raid from the east with a proper mix
            print(await ev("""(() => { const R = G.factory.raids; R.no = 4;
              // same as the director's own warning, but from the east with a fixed mix
              R._warn = function () { this.phase = 'warning'; this.dir = 'east';
                this.plan = { units: ['scav', 'scav', 'scav', 'merc', 'merc', 'drone'], kinds: { scav: 3, merc: 2, drone: 1 }, size: 'medium' };
                this.nav.ensure(); this.emit({ type: 'raidWarning', dir: 'east', eta: Math.round(this.timer), count: 6, kinds: this.plan.kinds, size: 'medium', no: 5 }); };
              R.forceRaid(40); return R.phase + ' ' + R.dir; })()"""))
            await ev(run_js(1.2))
            await pg.screenshot(path=f"{SP}/raid_02_warning.png")
            # look back toward the hall so the inbound marker sits off-screen at the edge
            await ev(look_at(0, 2, -16))
            await ev(run_js(0.2))
            await pg.screenshot(path=f"{SP}/raid_03_warning_marker.png")

            # arrival: watch the gap
            await ev(look_at(55, 1.2, 12.5))
            await ev(run_js(40, 1/30))
            print("phase:", await ev("G.factory.raids.phase + ' raiders=' + G.factory.raids.raiders.size"))
            await ev(run_js(9))
            print(await ev("JSON.stringify([...G.factory.raids.raiders.values()].map(r => [r.kind, r.state, +r.x.toFixed(1), +r.z.toFixed(1), r.hp, r.alive]))"))
            await pg.screenshot(path=f"{SP}/raid_04_contact.png")
            # third person over the shoulder toward the fight
            await ev(look_at(45, 1.2, 10, tp=True))
            await ev(run_js(2.5))
            await pg.screenshot(path=f"{SP}/raid_05_fight_tp.png")
            await ev(run_js(6))
            print(await ev("JSON.stringify([...G.factory.raids.raiders.values()].map(r => [r.kind, r.state, +r.x.toFixed(1), +r.z.toFixed(1), r.hp, r.alive, !!r.climb]))"))
            await ev(look_at(40, 1.2, 12, tp=False))
            await ev(run_js(0.3))
            await pg.screenshot(path=f"{SP}/raid_06_later.png")
            # the player's own shots at the nearest raider (aim + fire)
            print(await ev("""(() => { const g = G; const rs = g.session.raiderStates(1).filter(r => !r.dead && r.kind !== 'drone');
              if (!rs.length) return 'no raider';
              const p = g.player; rs.sort((a, b) => Math.hypot(a.x - p.x, a.z - p.z) - Math.hypot(b.x - p.x, b.z - p.z));
              const r = rs[0]; const ex = p.x, ey = p.y + 1.62, ez = p.z;
              const dx = r.x - ex, dy = r.y + 1.2 - ey, dz = r.z - ez; g.yaw = Math.atan2(-dx, -dz); g.pitch = Math.atan2(dy, Math.hypot(dx, dz));
              g.input.mouse.right = true; return 'target ' + r.kind + ' at ' + Math.hypot(dx, dz).toFixed(1) + ' m'; })()"""))
            await ev(run_js(0.3))
            for i in range(3):
                await ev("(() => { G.input.mouse.left = true; G.step(1/30, false); G.input.mouse.left = false; for (let k = 0; k < 6; k++) G.step(1/30, false); return 1; })()")
            await ev("G.step(1/60)")
            await pg.screenshot(path=f"{SP}/raid_07_shooting.png")
            await ev("(() => { G.input.mouse.right = false; return 1; })()")
            # downed
            await ev("(() => { const g = G; g.factory.raids.damagePlayer(g.factory.players.get('local'), 500, { x: g.player.x + 8, z: g.player.z }); return 1; })()")
            await ev(run_js(1.5))
            await pg.screenshot(path=f"{SP}/raid_08_downed.png")
            await ev(run_js(10))
            print("after respawn:", await ev("JSON.stringify({x: G.player.x.toFixed(1), z: G.player.z.toFixed(1), hp: G.factory.players.get('local').hp})"))
            # let the raid finish, then the summary banner
            await ev(run_js(60))
            print("end:", await ev("G.factory.raids.phase + ' ' + JSON.stringify(G.factory.raids.stats)"))
            await ev(stand(24, -2))
            await ev(look_at(30.5, 1.5, -14.5))
            await ev(run_js(0.3))
            await pg.screenshot(path=f"{SP}/raid_09_after.png")
            # turret panel
            print(await ev("""(() => { const g = G; const m = [...g.factory.machines.values()].find(m => m.def.defence === 'turret'); g.player.x = m.x; g.player.z = m.z + 1.2; g.panels.show('machine', m.id); g.step(1/60); return m.id; })()"""))
            await pg.screenshot(path=f"{SP}/raid_10_turret_panel.png")
            await ev("(() => { G.panels.close(); G.panels.show('terminal', 'company'); G.step(1/60); const st = document.querySelector('#panel-root .sec-stats'); if (st) st.previousElementSibling.previousElementSibling.scrollIntoView({ block: 'start' }); G.step(1/60); return 1; })()")
            await pg.screenshot(path=f"{SP}/raid_11_security_tab.png")
            await ev("(() => { G.panels.close(); G.step(1/60); return 1; })()")
            # line-up: one of each raider kind standing still in front of the camera
            print(await ev("""(() => { const g = G, R = g.factory.raids; R.dir = 'west';
              const mk = (kind, x, z, carry) => { const r = R._spawn(kind, 0); r.x = r.px = x; r.z = r.pz = z; r.y = r.py = kind === 'drone' ? 2.2 : 0; r.dummy = true; r.yaw = r.pyaw = 0.4; if (carry) r.carry.push({ type: 'motor', count: 2, owner: null }); return r.id; };
              mk('scav', -28.8, 13, true); mk('merc', -27.2, 12.6, false); mk('drone', -25.6, 13.4, true);
              const p = g.player; p.x = -27.4; p.z = 17.2; p.y = 0; Object.assign(g.prev, p); g.yaw = 0.05; g.pitch = -0.08; g.view = 'fp';
              for (let i = 0; i < 10; i++) g.step(1 / 30, false); g.step(1 / 60); return 'lineup'; })()"""))
            await pg.screenshot(path=f"{SP}/raid_12_lineup.png")
            await b.close()
    finally:
        srv.terminate()
        errs = [l for l in logs if ("error" in l.lower() or "pageerror" in l) and "ERR_TUNNEL" not in l and "fonts" not in l]
        print(f"--- page errors ({len(errs)}) ---")
        for l in errs[:20]: print(l)

asyncio.run(main())
