# Solo walkthrough of the 0.5 logistics: the truck tips raw materials into the receiving
# dock, a belt carries them to an item filter that splits pellets off to the moulder and
# sends steel on to the press, and the press output runs through a splitter.
import asyncio, subprocess, os, time
from playwright.async_api import async_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SP = os.environ.get("FOUNDRY_SHOTS", os.path.join(ROOT, "test-output"))
os.makedirs(SP, exist_ok=True)
PORT = 8876
ARGS = ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]

SETUP = """(async () => {
  const g = window.__game; window.G = g;
  g.audio.start = () => {}; g.manual = true; g.deploy = () => {};
  g.settings.name = 'Ethan'; g.saveSettings();
  const meta = g.saves.create('Ross Industries', 0x2fb5c9);
  const tmp = new (g.session.constructor)(g.world, null);
  const data = tmp.serialize(); tmp.dispose();
  data.funds = 9000; g.saves.write(meta.id, data);
  g.playSolo(meta.id); g.debugStart();
  const sim = g.factory, me = sim.players.get('local');
  for (const [k, n] of [['conveyor', 40], ['splitter', 2], ['sorter', 2], ['merger', 1], ['kit_press', 1], ['kit_moulder', 1]]) me.inventory.add(k, n);
  const place = (kind, x, z, q) => { const p = g.player; p.x = x; p.z = z + 4; me.pos = [p.x, 0, p.z]; const slot = me.inventory.slots.findIndex((s) => s && s.type === kind); const r = g.factoryCommand({ type: 'place', slot, x, z, q }); if (!r.ok) throw new Error(kind + ' ' + r.error); return r.id; };
  const press = place('kit_press', 6, -12.5, 1), moul = place('kit_moulder', 0, -9.5, 2);
  for (const z of [-6, -7, -8]) place('conveyor', 6, z, 2);
  const so = place('sorter', 6, -9, 2);
  place('conveyor', 6, -10, 2);
  for (const x of [5, 4, 3]) place('conveyor', x, -9, 3);
  place('conveyor', 6.5, -15, 2); place('splitter', 6.5, -16, 2);
  place('conveyor', 6.5, -17, 2); place('conveyor', 5.5, -16, 3); place('conveyor', 7.5, -16, 1);
  const at = (x, z) => { g.player.x = x; g.player.z = z; me.pos = [x, 0, z]; };
  at(6, -8); g.factoryCommand({ type: 'setFilter', id: so, item: 'pellets', side: 'left' });
  const m = sim.machines.get(press), mo = sim.machines.get(moul);
  at(m.geo.panel[0], m.geo.panel[2]); g.factoryCommand({ type: 'auto', machine: press, recipe: 'brackets' }); g.factoryCommand({ type: 'output', machine: press, mode: 'belt' });
  at(mo.geo.panel[0], mo.geo.panel[2]); g.factoryCommand({ type: 'auto', machine: moul, recipe: 'housing' });
  at(-7, -6); g.factoryCommand({ type: 'order', items: { steel_plate: 80, pellets: 40 } });
  window.SO = so;
  return 'ok';
})()"""

def run_js(secs, dt=1/30):
    return f"(() => {{ for (let i = 0; i < {int(secs / dt)}; i++) G.step({dt}, false); G.step(1/60); return 1; }})()"

def cam(px, py, pz, lx, ly, lz):
    # stand the player at (px, pz) (eye ≈ py) and look at (lx, ly, lz)
    return f"""(() => {{ const g = G, p = g.player; p.x = {px}; p.z = {pz}; p.y = {py} - 1.62; Object.assign(g.prev, p);
      const dx = {lx} - {px}, dy = {ly} - {py}, dz = {lz} - {pz}; g.yaw = Math.atan2(-dx, -dz); g.pitch = Math.atan2(dy, Math.hypot(dx, dz)); g.view = 'fp'; return 1; }})()"""

async def main():
    env = dict(os.environ, PORT=str(PORT), FOUNDRY_LOCAL_THREE="1")
    srv = subprocess.Popen(["node", "server/server.js"], cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    time.sleep(1.0)
    logs = []
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(args=ARGS)
            pg = await (await b.new_context(viewport={"width": 1180, "height": 660})).new_page()
            pg.on("console", lambda m: logs.append(f"[{m.type}] {m.text}"))
            pg.on("pageerror", lambda e: logs.append(f"[pageerror] {e}"))
            await pg.goto(f"http://localhost:{PORT}/")
            await pg.wait_for_function("window.__game !== undefined", timeout=60000)
            ev = pg.evaluate
            print(await ev(SETUP))
            # outside: the truck backs up and tips steel + pellets into the dock hopper
            await ev(cam(12, 3.2, 7, 5, 0.8, -2.5))
            await ev("(async () => { for (let i = 0; i < 2400 && G.factory.truck.phase !== 'dumping'; i++) G.step(1/30, false); for (let i = 0; i < 40; i++) G.step(1/30, false); G.step(1/60); return G.factory.truck.phase; })()")
            print("truck:", await ev("G.factory.truck.phase"), "dock:", await ev("G.factory.dock.length"))
            await pg.screenshot(path=f"{SP}/log_01_truck_tipping.png")
            await ev(run_js(2.5))
            # inside: dock → belt → item filter → press / moulder, press → splitter
            await ev(cam(11.5, 3.6, -5.2, 4.2, 0.2, -12.5))
            await ev(run_js(0.4))
            await pg.screenshot(path=f"{SP}/log_02_dock_filter.png")
            await ev(cam(8.6, 2.6, -4.9, 5.2, 0.2, -9.6))
            await ev(run_js(1.2))
            await pg.screenshot(path=f"{SP}/log_02b_flow_close.png")
            await ev(run_js(20))
            print("dock left:", await ev("G.factory.dock.length"), "produced:", await ev("G.factory.stats.produced"))
            await ev(cam(10.5, 3.0, -13.5, 6.2, 0.3, -16.3))
            await ev(run_js(0.4))
            await pg.screenshot(path=f"{SP}/log_03_splitter.png")
            # filter panel + dock panel
            await ev("(() => { G.player.x = 6; G.player.z = -8.2; G.panels.show('node', SO); G.step(1/60); return 1; })()")
            await pg.screenshot(path=f"{SP}/log_04_filter_panel.png")
            await ev("(() => { G.panels.close(); G.factory.dock.push({ type: 'copper_wire', count: 10, owner: null }, { type: 'circuit', count: 4, owner: null }); G.panels.show('dock'); G.step(1/60); return 1; })()")
            await pg.screenshot(path=f"{SP}/log_05_dock_panel.png")
            await ev("(() => { G.panels.close(); G.step(1/60); return 1; })()")
            await ev("(() => { G.panels.show('terminal', 'machines'); G.step(1/60); const sc = document.querySelector('#panel-root .scroll'); if (sc) sc.scrollTop = sc.scrollHeight; G.step(1/60); return 1; })()")
            await pg.screenshot(path=f"{SP}/log_07_terminal_equipment.png")
            await ev("(() => { G.panels.close(); G.step(1/60); return 1; })()")
            # build-mode ghost of a merger
            await ev("(() => { const g = G; g.player.x = 0; g.player.z = -14; g.yaw = 0; g.pitch = -0.6; g.build.start(g.me.inventory.slots.findIndex(s => s && s.type === 'merger')); for (let i = 0; i < 3; i++) g.step(1/30, false); g.step(1/60); return 1; })()")
            await pg.screenshot(path=f"{SP}/log_06_merger_ghost.png")
            await b.close()
    finally:
        srv.terminate()
        errs = [l for l in logs if ("error" in l.lower() or "pageerror" in l) and "ERR_TUNNEL" not in l and "fonts" not in l]
        print(f"--- page errors ({len(errs)}) ---")
        for l in errs[:20]: print(l)

asyncio.run(main())
