// Node tests for raids + defences (build 0.5): director timing, raiders stealing from the
// cage, loot drops, lag-compensated player shots, turrets, walls/gates + nav, player
// health (down / revive / respawn), saves mid-raid, placement rules and CPU cost.
import assert from 'node:assert/strict';
import { World } from '../src/shared/World.js';
import { FactorySim } from '../src/shared/factory/FactorySim.js';
import { RAID, RAIDERS, TURRET, HEALTH } from '../src/shared/raid/raidDefs.js';
import { FREE, WALL, GATE } from '../src/shared/raid/nav.js';
import { FACTORY } from '../src/shared/factory/layout.js';
import { levelFor } from '../src/shared/factory/progression.js';

const DT = 1 / 60;
const mk = (seed = 3) => {
  const sim = new FactorySim(new World(), { seed }); // own world: placed colliders don't leak between tests
  const p = sim.addPlayer('local');
  p.pos = [0, 0, 17];
  return { sim, p };
};
const runUntil = (sim, pred, maxSec, onEv = null) => {
  for (let i = 0; i < maxSec * 60; i++) {
    for (const e of sim.tick(DT)) if (onEv) onEv(e);
    if (pred()) return true;
  }
  return false;
};

// ---------------------------------------------------------------- director
{
  const { sim } = mk();
  runUntil(sim, () => false, 5);
  assert.equal(sim.raids.phase, 'off', 'no raids at level 1');
  sim.progress.xp = 400;
  assert.equal(levelFor(400).level, 2);
  const ev = [];
  runUntil(sim, () => sim.raids.phase === 'calm', 1, (e) => ev.push(e));
  assert.ok(ev.some((e) => e.type === 'raidIntro'), 'intro event');
  const t = sim.raids.timer;
  assert.ok(t >= RAID.firstDelay[0] - 1 && t <= RAID.firstDelay[1], `first raid in ${t}s`);
  let warn = null, start = null;
  runUntil(sim, () => sim.raids.phase === 'active', 300, (e) => { if (e.type === 'raidWarning') warn = { ...e, at: sim.time }; if (e.type === 'raidStart') start = { ...e, at: sim.time }; });
  assert.ok(warn && start, 'warning then start');
  assert.ok(Math.abs(start.at - warn.at - RAID.warning) < 0.1, 'warning is 90 s ahead');
  assert.equal(warn.count, 2, 'first raid is the small tutorial raid');
  assert.equal(warn.kinds.scav, 2);
  // after it ends: 15–25 min until the next one
  runUntil(sim, () => sim.raids.phase === 'calm', 240);
  assert.equal(sim.raids.phase, 'calm');
  assert.ok(sim.raids.timer >= RAID.cooldown[0] - 1 && sim.raids.timer <= RAID.cooldown[1], `cooldown ${sim.raids.timer}`);
  console.log(`director ok: warned ${warn.dir}, cooldown ${(sim.raids.timer / 60).toFixed(1)} min`);
}

// ---------------------------------------------------------------- stealing + escape
{
  const { sim, p } = mk(5);
  p.pos = [-40, 0, 30]; // out of the way
  sim.progress.xp = 400;
  sim.cage.push({ type: 'motor', count: 5, owner: 'local' }, { type: 'bracket', count: 30, owner: 'local' });
  sim.raids.forceRaid(1);
  const got = [];
  let end = null;
  runUntil(sim, () => !!end, 200, (e) => { if (e.type === 'raiderLoot') got.push(e); if (e.type === 'raidEnd') end = e; });
  assert.ok(got.length >= 1, 'raiders took something from the cage');
  assert.ok(end && !end.repelled && end.stolen > 0, 'goods escaped');
  assert.equal(sim.raids.stats.stolenValue, end.stolen);
  console.log(`steal ok: ${got.map((g) => g.item).join(', ')} stolen ($${end.stolen})`);
}

// ---------------------------------------------------------------- lag-compensated shots, bounties, loot drops
{
  const { sim, p } = mk(7);
  sim.progress.xp = 400;
  sim.cage.push({ type: 'control_unit', count: 4, owner: 'local' });
  sim.raids.forceRaid(1);
  let loot = null;
  p.online = false; // keep out of the fight until the shooting test
  runUntil(sim, () => !!loot, 120, (e) => { if (e.type === 'raiderLoot') loot = e; });
  p.online = true;
  assert.ok(loot, 'raider grabbed the control units');
  const r = sim.raids.raiders.get(loot.id);
  // stand 8 m from the raider and shoot where it was 0.2 s ago (what a lagged client saw)
  runUntil(sim, () => false, 0.25);
  const [hx, hy, hz] = sim.raids.rewind(r, sim.time - 0.2);
  const nowGap = Math.hypot(r.x - hx, r.z - hz);
  p.pos = [hx + 8, hy, hz];
  const o = [p.pos[0], p.pos[1] + 1.5, p.pos[2]];
  const aim = [hx - o[0], hy + 1.1 - o[1], hz - o[2]];
  const noLag = sim.apply('local', { type: 'shoot', o, d: aim, lag: 0 });
  assert.ok(noLag.ok, noLag.error + ' down=' + p.down);
  if (nowGap > 0.5) assert.equal(noLag.hit, null, 'without rewinding the moving raider is missed');
  let hits = 0, killed = false;
  const wallet0 = p.wallet;
  for (let i = 0; i < 6 && !killed; i++) {
    for (let k = 0; k < 9; k++) sim.tick(DT); // respect the fire-rate check
    const [x, y, z] = sim.raids.rewind(r, sim.time - 0.2);
    p.pos = [x + 8, y, z];
    const o2 = [p.pos[0], p.pos[1] + 1.5, p.pos[2]];
    const res = sim.apply('local', { type: 'shoot', o: o2, d: [x - o2[0], y + 1.1 - o2[1], z - o2[2]], lag: 0.2 });
    if (res.hit === r.id) hits++;
    killed = !!res.killed;
  }
  assert.ok(killed, `killed the carrier with rewound shots (${hits} hits, raider moved ${nowGap.toFixed(2)} m in 0.2 s)`);
  assert.equal(p.wallet - wallet0, RAIDERS[r.kind].bounty, 'bounty to the shooter');
  runUntil(sim, () => false, 1.5);
  const dropped = [...sim.items.values()].filter((it) => it.type === 'control_unit');
  assert.equal(dropped.reduce((a, it) => a + it.count, 0), 4, 'loot dropped where the raider fell');
  // spoofed origin + fire-rate cap
  p.pos = [0, 0, 0];
  assert.equal(sim.apply('local', { type: 'shoot', o: [20, 1.5, 20], d: [1, 0, 0] }).ok, false, 'shot origin must be at the player');
  for (let k = 0; k < 9; k++) sim.tick(DT);
  assert.ok(sim.apply('local', { type: 'shoot', o: [0, 1.5, 0], d: [1, 0, 0] }).ok);
  assert.equal(sim.apply('local', { type: 'shoot', o: [0, 1.5, 0], d: [1, 0, 0] }).ok, false, 'fire rate capped');
  console.log(`shots ok: kill with lag compensation, $${RAIDERS[r.kind].bounty} bounty, loot recovered`);
}

// ---------------------------------------------------------------- turrets
{
  const { sim, p } = mk(11);
  p.pos = [-40, 0, 30];
  sim.progress.xp = 400;
  // a kit in hand, placed in the yard between the west gap and the cage
  p.inventory.add('kit_turret', 1);
  p.inventory.add('ammo_box', 4);
  p.pos = [30, 0, -14];
  const slot = p.inventory.slots.findIndex((s) => s && s.type === 'kit_turret');
  const pl = sim.apply('local', { type: 'place', slot, x: 26.5, z: -17.5, q: 0 });
  assert.ok(pl.ok, pl.error);
  const tur = sim.machines.get(pl.id);
  assert.equal(tur.def.defence, 'turret');
  p.pos = [26.5, 0, -16.5];
  const ld = sim.apply('local', { type: 'loadTurret', machine: tur.id, count: 'all' });
  assert.ok(ld.ok && tur.ammo === 4 * TURRET.roundsPerBox, 'loaded 4 boxes');
  p.pos = [-40, 0, 30];
  sim.cage.push({ type: 'motor', count: 5, owner: 'local' });
  sim.raids.lastDir = 'north'; // not from north → comes from east/south/west
  sim.raids.forceRaid(1);
  let shots = 0, end = null;
  runUntil(sim, () => !!end, 240, (e) => { if (e.type === 'turretFire') shots++; if (e.type === 'raidEnd') end = e; });
  assert.ok(shots > 0, 'turret fired');
  assert.equal(tur.ammo, 4 * TURRET.roundsPerBox - shots, 'one round per shot');
  assert.ok(tur.kills >= 1, `turret killed ${tur.kills}`);
  console.log(`turret ok: ${shots} rounds, ${tur.kills} kills, raid ${end.repelled ? 'repelled' : 'not repelled'} (from ${sim.raids.lastDir})`);
  // belt-fed ammo: an ammo box riding a belt into the turret's back port
  const before = tur.ammo;
  p.inventory.add('conveyor', 2);
  // belts can't go outside the hall, so test accepts() directly
  assert.ok(sim.accepts(tur, 'ammo_box', 1));
  assert.equal(sim.accepts(tur, 'motor', 1), false);
  // unload + pack gives the boxes back
  p.pos = [26.5, 0, -16.5];
  tur.ammo = before + 65;
  const un = sim.apply('local', { type: 'unloadTurret', machine: tur.id });
  assert.ok(un.ok && tur.ammo === (before + 65) % TURRET.roundsPerBox);
}

// ---------------------------------------------------------------- placement rules
{
  const { sim, p } = mk(13);
  p.inventory.add('kit_wall', 10);
  p.inventory.add('kit_press', 1);
  p.inventory.add('kit_gate', 2);
  const at = (x, z) => { p.pos = [x, 0, z + 3]; };
  const slotOf = (t) => p.inventory.slots.findIndex((s) => s && s.type === t);
  at(-30, 10);
  assert.ok(sim.canPlace('wall', -30, 10, 0).ok, 'wall in the open yard');
  assert.equal(sim.canPlace('press', -30, 10, 0).ok, false, 'machines stay in the hall');
  assert.match(sim.canPlace('wall', 0, 30, 0).why, /route/, 'truck road kept clear');
  assert.match(sim.canPlace('wall', 0, 0, 0).why, /bay/, 'delivery bay kept clear');
  assert.match(sim.canPlace('wall', 22, -6, 0).why, /cage/, 'cage kept clear');
  assert.equal(sim.canPlace('wall', 60, 0, 0).ok, false, 'outside the fence');
  assert.ok(sim.canPlace('wall', -10, -15, 0).ok, 'defences inside the hall too');
  const w = sim.apply('local', { type: 'place', slot: slotOf('kit_wall'), x: -30, z: 10, q: 0 });
  assert.ok(w.ok, w.error);
  assert.equal(p.inventory.count('kit_wall'), 9, 'walls stack in the inventory');
  assert.equal(sim.raids.nav.kindAt(-30, 10), WALL, 'nav sees a climbable wall');
  at(-30, 20);
  const g = sim.apply('local', { type: 'place', slot: slotOf('kit_gate'), x: -30.5, z: 20, q: 0 });
  assert.ok(g.ok, g.error);
  assert.equal(sim.raids.nav.kindAt(-30.5, 20), GATE, 'nav sees the gate');
  assert.equal(sim.productionCount(), 1, 'walls and gates are not "machines" for goals');
  // players walk through gates, raiders don't
  const gate = sim.machines.get(g.id);
  assert.ok(gate.leaf && gate.leaf.mask === 4, 'gate leaf blocks raiders only');
  // pack it back up
  p.pos = [gate.geo.panel[0], 0, gate.geo.panel[2] + 0.5];
  const pk = sim.apply('local', { type: 'pack', id: g.id });
  assert.ok(pk.ok, pk.error);
  assert.equal(sim.raids.nav.kindAt(-30.5, 20), FREE, 'nav freed after packing');
  console.log('placement ok: yard rules, route/bay/cage kept clear, nav updates');
}

// ---------------------------------------------------------------- walls get climbed, gates stop scavengers, mercs breach
{
  const { sim, p } = mk(17);
  p.pos = [-40, 0, 30];
  p.inventory.add('kit_wall', 10);
  p.inventory.add('kit_gate', 4);
  sim.progress.xp = 400;
  const slotOf = (t) => p.inventory.slots.findIndex((s) => s && s.type === t);
  // a free-standing wall line: raiders walk round the end of it
  for (const z of [-20.5, -18.5]) {
    p.pos = [-40, 0, z];
    assert.ok(sim.apply('local', { type: 'place', slot: slotOf('kit_wall'), x: -38, z, q: 1 }).ok);
  }
  const nav = sim.raids.nav;
  const round = nav.findPath(-42, -19.5, -34, -19.5);
  assert.ok(round.every((i) => nav.kind[i] === FREE), 'short detour beats climbing');
  // wall off the west gap completely (just inside the fence) → they have to climb
  for (const z of [-11, -9, -7, -5, -3]) {
    p.pos = [-47, 0, z];
    const r = sim.apply('local', { type: 'place', slot: slotOf('kit_wall'), x: -49, z, q: 1 });
    assert.ok(r.ok, r.error);
  }
  const direct = nav.findPath(-65, -7.5, -40, -7.5);
  assert.ok(direct.some((i) => nav.kind[i] === WALL), 'path climbs the barricade instead of the fence');
  sim.raids.lastDir = null;
  sim.raids.dir = 'west';
  sim.raids._warn = function () { this.phase = 'warning'; this.dir = 'west'; this.plan = { units: ['scav', 'scav'], kinds: { scav: 2, merc: 0, drone: 0 }, size: 'small' }; };
  sim.cage.push({ type: 'motor', count: 5, owner: 'local' });
  sim.raids.forceRaid(1);
  let climbs = 0;
  runUntil(sim, () => climbs > 0 || sim.raids.phase === 'calm', 120, (e) => { if (e.type === 'raiderClimb') climbs++; });
  assert.ok(climbs > 0, 'a raider climbed a barricade');
  console.log(`walls ok: ${climbs} climb(s)`);

  // gates: scavengers can't path through; mercs can breach
  const { sim: s2, p: p2 } = mk(19);
  p2.inventory.add('kit_gate', 4);
  const slot2 = () => p2.inventory.slots.findIndex((s) => s && s.type === 'kit_gate');
  // a corridor: a gate between two containers? simpler: gate-only ring test on the nav
  p2.pos = [-30, 0, 12];
  const gr = s2.apply('local', { type: 'place', slot: slot2(), x: -30.5, z: 10, q: 0 });
  assert.ok(gr.ok, gr.error);
  const n2 = s2.raids.nav;
  const through = (breach) => { const pth = n2.findPath(-30.5, 8, -30.5, 12, { breach }); return pth && pth.some((i) => n2.kind[i] === GATE); };
  assert.equal(through(false), false, 'scavengers go round a gate');
  s2.raids.breachGate(gr.id);
  assert.equal(s2.machines.get(gr.id).leaf.mask, 0, 'breached gate lets raiders through');
  assert.equal(n2.kindAt(-30.5, 10), FREE);
  s2.raids._repairGates();
  assert.equal(s2.machines.get(gr.id).leaf.mask, 4, 'repaired after the raid');
}

// ---------------------------------------------------------------- player health: down, revive, respawn
{
  const { sim, p } = mk(23);
  const b = sim.addPlayer('guest:Gus');
  p.pos = [0, 0, 10]; b.pos = [1, 0, 10];
  const ev = [];
  const run = (sec) => runUntil(sim, () => false, sec, (e) => ev.push(e));
  sim.raids.damagePlayer(p, 40, { x: 5, z: 5 });
  assert.equal(p.hp, 60);
  run(HEALTH.regenDelay + 3);
  assert.ok(p.hp > 90, 'regenerates after a few seconds');
  sim.raids.damagePlayer(p, 200, null);
  run(0.05);
  assert.ok(p.down && ev.some((e) => e.type === 'playerDown'));
  // shots can't be fired while down
  assert.equal(sim.apply('local', { type: 'shoot', o: [0, 1.5, 10], d: [1, 0, 0] }).ok, false);
  // partner holds E for 3 s
  assert.ok(sim.apply('guest:Gus', { type: 'revive', target: 'local' }).ok);
  run(HEALTH.reviveTime - 0.5);
  assert.ok(p.down, 'not yet');
  run(0.7);
  assert.ok(!p.down && p.hp === HEALTH.reviveHp, 'revived');
  // down again, nobody helps → respawn at the terminal after 10 s, nothing lost
  const wallet = p.wallet = 123;
  p.inventory.add('motor', 2);
  sim.raids.damagePlayer(p, 500, null);
  run(HEALTH.bleedout + 0.2);
  const rs = ev.find((e) => e.type === 'respawn');
  assert.ok(rs && !p.down && p.hp === HEALTH.max, 'respawned');
  assert.deepEqual([rs.x, rs.z], [FACTORY.respawn.x, FACTORY.respawn.z]);
  assert.equal(p.wallet, wallet);
  assert.equal(p.inventory.count('motor'), 2, 'kept everything');
  // walking away cancels a revive
  sim.raids.damagePlayer(p, 500, null);
  sim.apply('guest:Gus', { type: 'revive', target: 'local' });
  b.pos = [9, 0, 10];
  run(1);
  assert.equal(p.reviver, null, 'revive cancelled when the partner walks off');
  console.log('health ok: regen, down, revive (3 s), respawn at terminal with everything kept');
}

// ---------------------------------------------------------------- saves mid-raid
{
  const { sim, p } = mk(29);
  p.pos = [-40, 0, 30];
  sim.progress.xp = 400;
  sim.cage.push({ type: 'harness', count: 6, owner: 'local' }, { type: 'motor', count: 2, owner: 'local' });
  sim.raids.forceRaid(1);
  let loot = null;
  runUntil(sim, () => !!loot, 120, (e) => { if (e.type === 'raiderLoot') loot = e; });
  assert.ok(loot);
  const data = JSON.parse(JSON.stringify(sim.serialize()));
  const total = (cage) => cage.reduce((a, s) => a + s.count, 0);
  assert.equal(total(data.cage), 8, 'goods being carried off are saved back in the cage');
  assert.equal(data.raids.phase, 'calm');
  assert.equal(data.raids.timer, RAID.resumeDelay, 'raid comes back soon after loading');
  const w2 = new World();
  const s2 = new FactorySim(w2, { seed: 29, fresh: false });
  s2.load(data);
  assert.equal(s2.raids.phase, 'calm');
  assert.equal(s2.raids.no, 1);
  assert.equal(s2.raids.raiders.size, 0);
  s2.dispose();
  console.log('save ok: carried loot back in the cage, raid resumes 2 min after loading');
}

// ---------------------------------------------------------------- reset clears raids
{
  const { sim } = mk(31);
  sim.progress.xp = 400;
  sim.raids.forceRaid(1);
  runUntil(sim, () => sim.raids.raiders.size > 0, 30);
  sim.reset();
  assert.equal(sim.raids.phase, 'off');
  assert.equal(sim.raids.raiders.size, 0);
}

// ---------------------------------------------------------------- CPU: a big raid against a defended plant
{
  const { sim, p } = mk(37);
  p.pos = [-10, 0, -15];
  sim.progress.xp = 20000;
  sim.raids.no = 9;
  p.inventory.add('kit_turret', 3);
  p.inventory.add('ammo_box', 20);
  for (const [x, z] of [[30.5, -14.5], [-24.5, 8.5], [18.5, 28.5]]) {
    p.pos = [x, 0, z + 2];
    const r = sim.apply('local', { type: 'place', slot: p.inventory.slots.findIndex((s) => s && s.type === 'kit_turret'), x, z, q: 0 });
    assert.ok(r.ok, r.error);
    sim.apply('local', { type: 'loadTurret', machine: r.id, count: 6 });
  }
  p.pos = [-10, 0, -15];
  for (let i = 0; i < 12; i++) sim.cage.push({ type: 'motor', count: 3, owner: 'local' });
  sim.raids.forceRaid(1);
  runUntil(sim, () => sim.raids.phase === 'active', 5);
  let maxAlive = 0, ticks = 0, worst = 0;
  const t1 = performance.now();
  while (sim.raids.phase === 'active' && ticks < 60 * 300) {
    const a = performance.now();
    sim.tick(DT);
    worst = Math.max(worst, performance.now() - a);
    ticks++;
    let alive = 0; for (const r of sim.raids.raiders.values()) if (r.alive) alive++;
    maxAlive = Math.max(maxAlive, alive);
  }
  const per = (performance.now() - t1) / ticks;
  assert.ok(maxAlive >= 6, `big raid (${maxAlive} alive at once)`);
  assert.ok(maxAlive <= RAID.maxAlive);
  assert.ok(per < 0.5, `raid tick ${per.toFixed(3)} ms`);
  console.log(`cpu ok: large raid vs 3 turrets, ${maxAlive} alive at once, ${per.toFixed(3)} ms/tick avg, worst ${worst.toFixed(1)} ms`);
}

console.log('ALL RAID TESTS PASSED');
